 
<?php $__env->startSection('content'); ?>


    <h4 class="font-weight-bold text-right">تعليقات الشحنات <?php echo e($comments->total()); ?></h4>


	<div class="row pt-4 mb-5 text-right">

		<!--    Start search box     -->
		<aside class="col-lg-4 col-xl-3 mb-5">
			<form action="<?php echo e(Request::url()); ?>">
                
                <input type="hidden" name="search" value="1" />
                
                <div class="form-group">
					<label>الحالة</label>
					<select name="state" class="form-control setValue" value="<?php echo e(Request::get('state')); ?>" >
                        <option value="" selected>الكل</option>
                        <?php $__currentLoopData = trans('shipmentComments.status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
                </div>
                
                <div class="form-group">
                    <label>رقم الشحنة</label>
                    <input type="number" min="1" value="<?php echo e(Request::get('shipment_id')); ?>" name="shipment_id" class="form-control" />
                </div>
                
                <div class="form-group">
                    <label>رقم العضوية</label>
                    <input type="number" min="1" value="<?php echo e(Request::get('code')); ?>" name="code" class="form-control" />
                </div>
                
                <div class="form-group">
					<label>المستخدم</label>
					<select name="user" class="form-control setValue" value="<?php echo e(Request::get('user')); ?>" >
                        <option value="" selected>الكل</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
                </div>

				<div class="form-group">
					<label>التعليق</label>
					<input type="search" maxlength="32" value="<?php echo e(Request::get('comment')); ?>" name="comment" class="form-control" />
                </div>
                
				<div class="form-group">
					<label>من</label>
				<input type="date" value="<?php echo e(Request::get('from')); ?>" max="<?php echo e(date('Y-m-d')); ?>" name="from" class="form-control" />
				</div>
                
                <div class="form-group">
					<label>إلى</label>
					<input type="date" value="<?php echo e(Request::get('to')); ?>" max="<?php echo e(date('Y-m-d')); ?>" name="to" class="form-control" />
				</div>
                
                <button type="submit" class="btn btn-primary btn-block mt-2">بحث</button>
            
            </form>
		</aside>
		<!--    End search box     -->


        
		<section class="col-lg-8 col-xl-9">

			<div id="shipmentCommentsCollapsible" class="d-flex flex-column" role="tablist">

				<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="bg-white shadow box-list mb-1" id="<?php echo e($comment->id); ?>">

                        
                        <div class="px-4 border-bottom-0 py-3" role="tab" id="heading<?php echo e($comment->id); ?>">
                            
                            <h5 class="mb-1 d-flex f-18px align-items-start">
                                <?php if(!$comment->userCanEditComment() && $comment->unread): ?>
                                    <span class="label-state col-auto ml-1 text-white d-inline-block bg-danger"><?php echo e($comment->getState()); ?></span> 
                                <?php endif; ?>
                                <a data-toggle="collapse" class="text-dark text-truncate collapsed" href="#collapse<?php echo e($comment->id); ?>"
                                    aria-expanded="false" aria-controls="collapse<?php echo e($comment->id); ?>"><?php echo e($comment->comment); ?></a>
                            </h5>
                            
                            <span class="text-muted f-15px d-inline-block">
                                <i class="fa fa-user mx-1"></i>
                                <span><?php echo e($comment->getCommenter()); ?></span>
                                <a href="<?php echo e(url("cp/shipping-invoices/$comment->shipment_id#$comment->id")); ?>" class="text-muted">
                                    <i class="fa fa-cubes ml-1 mr-3"></i>
                                    <bdi><?php echo e($comment->shipment_id); ?></bdi>
                                </a>
                                <i class="far fa-clock ml-1 mr-3"></i>
                                <bdi><?php echo e($comment->created_at()); ?></bdi>
                            </span>

                        </div>
                        
                        
                        
                        <div id="collapse<?php echo e($comment->id); ?>" class="collapse border-top text-right" role="tabpanel" aria-labelledby="heading<?php echo e($comment->id); ?>" data-parent="#shipmentCommentsCollapsible">
                            <div class="px-4 pt-3 text-secondary">

                                <div class="row">

                                    
                                    <div class="col">
                                        <p class="comment-content pre-wrap pb-4"><?php echo e($comment->comment); ?></p>
                                    </div>
                                    

                                    
                                    <div class="col-auto">
                                        
                                        <?php if(hasRole('shipment_comments_edit') && !$comment->userCanEditComment()): ?>
                                            
                                            <?php if($comment->unread): ?>
                                                <a href="<?php echo e(url('/cp/shipment-comments/update/state',$comment->id)); ?>" class="btn btn-dark btn-sm text-white">
                                                    <i class="fas fa-check fa-fx"></i>
                                                </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(url('/cp/shipment-comments/update/state',$comment->id)); ?>" class="btn btn-secondary btn-sm text-white">
                                                    <i class="fas fa-times fa-fx"></i>
                                                </a>
                                            <?php endif; ?>

                                        <?php endif; ?>

                                        
                                        <?php if(hasRole('shipment_comments_delete')): ?>

                                            <button type="button" class="btn btn-danger btn-sm btnDeleteComment" data-toggle="modal" data-target="#deleteCommentModal">
                                                <i class="fas fa-trash fa-fx"></i>
                                            </button>

                                        <?php endif; ?>
                                        
                                    </div>
                                    

                                </div>

                            </div>
                        </div>
                        
                        
                    </div>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>

			<div class="pagination-center mt-4"> <?php echo e($comments->links()); ?></div>

		</section>
        

	</div>


    
    <?php if(hasRole('shipment_comments_delete')): ?>
    
        <!--    Start Modal deleteCommentModal -->
        <div class="modal fade" id="deleteCommentModal" tabindex="-1" role="dialog" aria-labelledby="deleteCommentModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteCommentModalLabel">حذف تعليق</h5>
                        <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <form class='formSendAjaxRequest' refresh-seconds='2' action="<?php echo e(url('/cp/shipment-comments')); ?>"
                        method="post">
                        <div class="modal-body text-right">
                            <div class="formResult text-center"></div>
                            <?php echo method_field('DELETE'); ?>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" />
                            هل أنت متأكد أنك تريد حذف التعليق ؟
                            <hr/>
                            <p></p>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger">حذف</button>
                            <button type="button" class="btn btn-secondary mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--    End Modal deleteCommentModal -->
        
    <?php endif; ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra-js'); ?>
    <script>
    
        
        $('.btnDeleteComment').click(function(){
            var commentBox = $(this).closest('.box-list');
            $('#deleteCommentModal form input[name="id"]').val($(commentBox).attr('id'));
            $('#deleteCommentModal form p').html($(commentBox).find('.comment-content').html());
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/shipment_comments.blade.php ENDPATH**/ ?>