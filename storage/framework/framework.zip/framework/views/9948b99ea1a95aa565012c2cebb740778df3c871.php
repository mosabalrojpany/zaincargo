<?php $__env->startSection('content'); ?>


    <!--    Start header    -->
    <div class="d-flex justify-content-between">
        <h4 class="font-weight-bold">الأسئلة الشائعة <?php echo e($faqs->total()); ?></h4>
        <a class="btn btn-primary w-100px" href="<?php echo e(url('cp/faqs/create')); ?>">
            <i class="fas fa-plus mx-1"></i>أضف
        </a>
    </div>
    <!--    End header    -->

    

    <div class="row mt-5 text-right">

        <!--    Start search box     -->
        <aside class="col-lg-4 col-xl-3 mb-5">
            <form action="<?php echo e(Request::url()); ?>">
                <input type="hidden" name="search" value="1" />
                <div class="form-group">
                    <label>السؤال</label>
                    <input type="search" value="<?php echo e(Request::get('question')); ?>" name="question" maxlength="32" class="form-control" />
                </div>
                <div class="form-group">
                    <label>الإجابة</label>
                    <input type="search" value="<?php echo e(Request::get('answer')); ?>" name="answer" maxlength="32" class="form-control" />
                </div>
                <div class="form-group">
                    <label>الحالة</label>
                    <select name="state" class="form-control setValue" value="<?php echo e(Request::get('state')); ?>">
                        <option value="" selected>الكل</option>  
                        <option value="1">فعال</option>  
                        <option value="0">غير فعال</option>  
                    </select>
                </div>
                <button type="submit" class="btn btn-primary btn-block mt-2">بحث</button>
            </form>
        </aside>
        <!--    End search box     -->


        <!--    Start show data  -->
        <section class="col-lg-8 col-xl-9">

            <!-- Start print FAQs -->
            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="card border-0 mb-3 <?php echo e($faq->active ? 'border-state-active' : 'border-state-disable'); ?>">
                    
                    
                    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center" role="tab" id="heading<?php echo e($faq->id); ?>">
                        
                        <h6 class="mb-0 py-1 pl-2 text-truncate"><?php echo e($faq->question); ?></h6>
                        
                        <div class="no-wrap">
                            <a class="btn btn-sm btn-primary ml-2" href="<?php echo e(url('cp/faqs/edit',$faq->id)); ?>" >
                                <i class="fas fa-pen"></i>
                            </a>
                            <a data-toggle="collapse" class="text-dark" href="#collapse<?php echo e($faq->id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($faq->id); ?>">
                                <i class="fa fa-chevron-down"></i>
                            </a>
                        </div>
                    
                    </div>
                    

                    
                    <div id="collapse<?php echo e($faq->id); ?>" class="collapsing" role="tabpanel" aria-labelledby="heading<?php echo e($faq->id); ?>">

                        <div class="card-body text-right">

                            <p class="text-primary font-weight-bold"><?php echo e($faq->question); ?></p>
                            
                            <hr/>
                            
                            <div class="editor-content"><?php echo $faq->answer; ?></div>
                        
                        </div>

                    </div>
                    

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End print FAQs -->

             <div class="pagination-center mt-2"><?php echo e($faqs->links()); ?></div>  

        </section>
        <!--    End show data  -->


    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/faqs/index.blade.php ENDPATH**/ ?>