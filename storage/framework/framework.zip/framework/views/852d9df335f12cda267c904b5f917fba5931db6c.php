<?php $__env->startSection('content'); ?>


<!--  Start path  -->
<div class="d-flex align-items-center bg-white mb-3 d-print-none">

    <nav class="col pr-0" aria-label="breadcrumb" role="navigation">
        <ol class="breadcrumb bg-white mb-0">
            <li class="breadcrumb-item"> 
                <a href="<?php echo e(url('cp/money-transfers')); ?>">حوالات مالية</a> 
            </li>
            <li class="breadcrumb-item active text-truncate col pr-0 text-right" aria-current="page">
                <span class="mr-1"><?php echo e($transfer->id); ?></span>
            </li>
        </ol>
    </nav>

    <div class="col-auto">
        <?php if(hasRole('money_transfers_edit')): ?>
            <a href="<?php echo e(url('cp/money-transfers/edit',$transfer->id)); ?>" class="btn btn-primary btn-sm">
                <i class="fas fa-pen"></i>
            </a>        
        <?php endif; ?>

        <?php if(hasRole('money_transfers_delete')): ?>
            <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteModal">
                <i class="fas fa-trash"></i>
            </button>      
        <?php endif; ?>
    </div>
    
</div>
<!--  End path  -->



<div class="card card-shadow">

    
    <div class="card-header bg-white pt-4 text-right">

        
        <div class="row">

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">رقم الحوالة</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->id); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
            
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">رقم العضوية</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->customer->code); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
            
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">اسم الزبون</label>
                    <div class="col text-secondary">
                        <a href="<?php echo e(url('cp/customers',$transfer->customer_id)); ?>"><?php echo e($transfer->customer->name); ?></a>
                    </div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">الحالة</label>
                    <div class="col text-secondary"><?php echo e($transfer->getState()); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">البلد</label>
                    <div class="col text-secondary"><?php echo e($transfer->country->name); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">المدينة</label>
                    <div class="col text-secondary"><?php echo e($transfer->city->name); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

        </div>
        

        <hr/>

        
        <div class="row">
            
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">اسم المستلم</label>
                    <div class="col text-secondary"><?php echo e($transfer->recipient); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">رقم الهاتف</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->phone); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">رقم الهاتف 2</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->phone2); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
        
        </div>
        

        <hr/>

        
        <div class="row">

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">نوع المستلم</label>
                    <div class="col text-secondary"><?php echo e($transfer->getRecipientType()); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">ملف</label>
                    <div class="col text-secondary">
                        <?php if($transfer->file): ?>
                            <a href="<?php echo e($transfer->getFile()); ?>" target="_blank">عرض الملف</a>
                        <?php else: ?>
                            لا يوجد ملف
                        <?php endif; ?>
                    </div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

        </div>
        

        <hr/>
        
        
        <div class="row">
            
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">العمولة على</label>
                    <div class="col text-secondary"><b><?php echo e($transfer->getFeeOn()); ?></b></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
            
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px pl-0">طريقة الاستلام</label>
                    <div class="col text-secondary"><?php echo e($transfer->getRecevingMethod()); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">العملة</label>
                    <div class="col text-secondary"><?php echo e($transfer->currency->name); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">المبلغ</label>
                    <div class="col text-secondary"><b><?php echo e($transfer->amount); ?></b></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">العمولة</label>
                    <div class="col text-secondary"><b><?php echo e($transfer->fee); ?></b></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">الإجمالي</label>
                    <div class="col text-secondary"><b><?php echo e($transfer->getTotalByCurrency()); ?></b></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
            
        </div>
        

        <hr/>

        
        <div class="row">
                
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">رقم الحساب</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->account_number); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
            
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px pl-0">رقم الحساب 2</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->account_number2); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
            
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px pl-0">رقم الحساب 3</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->account_number3); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

        </div>
        

        <hr/>

        
        <div class="row">
            
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">تاريخ الإضافة</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->created_at()); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">تاريخ التحويل</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->converted_at()); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
            
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">تاريخ الاستلام</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->received_at()); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px pl-0">أضيفة بواسطة</label>
                    <div class="col text-secondary"><?php echo e($transfer->addedBy()); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
    
        </div>
        

        <hr/>

        
        <div class="row">

            <div class="col-md-6 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">ملاحظة</label>
                    <div class="col text-secondary"><?php echo e($transfer->note); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 mb-3">
                <div class="row">
                    <label class="col-auto w-125px pl-0">معلومات أخرى</label>
                    <div class="col text-secondary"><?php echo e($transfer->extra); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

        </div>
        
    
    </div>
    

</div>



    <?php if(hasRole('money_transfers_delete')): ?>

        <!--    Start Modal deleteModal -->
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">حذف حوالة</h5>
                        <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <form class='formSendAjaxRequest' redirect-to='<?php echo e(url('/cp/money-transfers')); ?>' refresh-seconds='2' action="<?php echo e(url('/cp/money-transfers')); ?>"
                        method="post">
                        <div class="modal-body text-right">
                            <div class="formResult text-center"></div>
                            <?php echo method_field('DELETE'); ?>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($transfer->id); ?>" />
                            هل أنت متأكد أنك تريد حذف الحوالة ؟
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger">حذف</button>
                            <button type="button" class="btn btn-secondary mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--    End Modal deleteModal -->

    <?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/money_transfers/show.blade.php ENDPATH**/ ?>