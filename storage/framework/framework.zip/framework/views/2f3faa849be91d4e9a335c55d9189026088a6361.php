<?php $__env->startSection('extra-meta'); ?>

    <?php ($shortDesc=mb_substr(strip_tags($post->content),0,250)); ?>

    <meta property="og:title"                   content="<?php echo e($post->title); ?>" />
    <meta property="og:description"             content="<?php echo e($shortDesc); ?>" />
    <meta property="og:image"                   content="<?php echo e($post->getImage()); ?>" />
    <meta property="og:image:secure_url"        content="<?php echo e($post->getImage()); ?>" />
    <meta property="og:type"                    content="article" />
    <meta property="article:section "           content="الأخبار">
    <meta property="article:published_time"     content="<?php echo e($post->created_at); ?>">
    
    <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <meta property="article:tag"            content="<?php echo e($tag->name); ?>" />
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <meta name="twitter:card"                   content="summary_large_image" />
    <meta name="twitter:title"                  content="<?php echo e($post->title); ?>" />
    <meta name="twitter:description"            content="<?php echo e($shortDesc); ?>" />
    <meta name="twitter:image"                  content="<?php echo e($post->getImage()); ?>" />

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



    <!--  breadcrumb area start  -->
    <div class="breadcrumb-area blog-breadcrumb-bg home-3">
        <div class="container">
            <div class="breadcrumb-txt">
                <span>أخبارنا</span>
                <h1><?php echo e($post->title); ?></h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">الرئيسية</a></li>
                        <li class="breadcrumb-item active" aria-current="page">أخبارنا</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="breadcrumb-overlay"></div>
    </div>
    <!--  breadcrumb area end  -->


    
    <!--    blog details section start   -->
    <div class="blog-details-section section-padding">
        <div class="container">
            <div class="row">

                <div class="col-lg-8">
                    <div class="blog-details">
                        
                        <img class="blog-details-img-1" src="<?php echo e($post->getImage()); ?>" alt="<?php echo e($post->title); ?>">
                        
                        <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url("news?tag=$tag->name")); ?>" class="tag ml-1">
                                <i class="fa fa-tag" style="vertical-align: middle"></i>
                                <?php echo e($tag->name); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        |
                        <small class="date mr-1">
                            <i class="far fa-clock" style="vertical-align: middle"></i>
                            <bdi><?php echo e($post->getDate()); ?></bdi>
                        </small>

                        <h2 class="blog-details-title"><?php echo e($post->title); ?></h2>
                        
                        <div class="blog-details-body editor-content">
                            <?php echo $post->content; ?>

                        </div>
                    </div>
                    <div class="blog-share">
                        <ul>
                            <li>
                                <a href="http://www.facebook.com/sharer.php?u=<?php echo e(Request::url()); ?>" target="_blank" class="facebook-share">
                                    <i class="fab fa-facebook-f"></i> Share
                                </a>
                            </li>
                            <li>
                                <a href="https://twitter.com/share?url=<?php echo e(Request::url().'&text='.$post->title); ?>" target="_blank" class="twitter-share">
                                    <i class="fab fa-twitter"></i> Tweet
                                </a>
                            </li>
                            <li>
                                <a href="https://pinterest.com/pin/create/button/?url=<?php echo e(Request::url()); ?>" target="_blank" class="pinterest-share">
                                    <i class="fab fa-pinterest-p"></i> Pinterest
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

                <!--    blog sidebar section start   -->
                <div class="col-lg-4">
                    <div class="sidebar">
                        <?php echo $__env->make('main.posts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <!--    blog sidebar section end   -->

            </div>
        </div>
    </div>
    <!--    blog details section end   -->
    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/main/posts/show.blade.php ENDPATH**/ ?>