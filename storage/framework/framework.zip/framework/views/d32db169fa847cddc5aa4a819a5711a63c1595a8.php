<!doctype html>
<html lang="ar">

<head>
    <title><?php echo $__env->yieldContent('title',config('app.name')); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Tajawal&display=swap" rel="stylesheet">
</head>

<body
    style="box-sizing: border-box; padding: 0; margin: 0; direction: rtl; text-align: right; font-family: 'Tajawal', sans-serif; font-size: 16px; background-color: #1F415F;">


    
    <div style="max-width: 720px; min-width: fit-content; padding: 10px; margin: 10px auto;">

        
        <h1 style="margin: 15px 0;">
            <a href="<?php echo e(url('/')); ?>" title="<?php echo e(config('app.name')); ?>" style="max-height: 62px; display: block;">
                <img src="<?php echo e(url('images/logo-with-title.png')); ?>" style="max-height: 60px;" />
            </a>
        </h1>
        


        
        <div
            style="background-color: #fff; border-radius: 5px; box-shadow: 0 .5rem 1rem rgba(0,0,0,.15); padding: 20px;">

            <h2 style="text-align: center;  margin:0; font-size: 1.35em;"><?php echo $__env->yieldContent('subject'); ?></h2>

            <div style="border-bottom:1px solid #999; margin: 20px auto;"></div>


            
            <div style="margin: 30px 0;">

                <p>أهلاً بك سيد/ة <b><bdi><?php echo e($customer->name); ?></bdi></b>...</p>

                <?php echo $__env->yieldContent('content'); ?>

            </div>
            


            
            <h4 style="margin-bottom: 10px;">لاي استفسار يمكنك مراسلتنا على</h4>

            <div style="direction: ltr; text-align: right;">

                <div><?php echo e(app_settings()->email); ?></div>

                <a style="color:inherit;" href="<?php echo e(url('/contact')); ?>"><?php echo e(url('/contact')); ?></a>

            </div>

            <div style="margin-top: 20px; margin-bottom: 10px;">شكرا لك<br/><?php echo e(config('app.name')); ?></div>
            


        </div>
        


        
        <div style="margin-top: 10px; text-align: center; color: #eee;">
            <a style="color:inherit;" href="<?php echo e(url('/')); ?>"><?php echo e(url('/')); ?></a>
        </div>
        


    </div>
    



</body>

</html>
<?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/emails/layouts/app.blade.php ENDPATH**/ ?>