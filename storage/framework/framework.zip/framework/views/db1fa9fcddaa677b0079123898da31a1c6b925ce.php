<?php $__env->startSection('content'); ?>



    <!--  Start path  -->
    <div class="d-flex align-items-center bg-white mb-3 d-print-none">

        <nav class="col pr-0" aria-label="breadcrumb" role="navigation">
            <ol class="breadcrumb bg-white mb-0">
                <li class="breadcrumb-item">
                    <a href="">محفظة</a>
                </li>
                <li class="breadcrumb-item active text-truncate col pr-0 text-right" aria-current="page">
                    <span class="mr-1"></span>
                </li>
            </ol>
        </nav>

        <div class="col-auto">



                <?php if(hasRole('user_wallet_add','user_wallet_show','user_wallet_index')): ?>
                <a href="" id="deposity" class="btn btn-primary btn-sm"  data-toggle="modal"  data-target="#Modal">
                   ايداع
                </a>
                <a href="" id="Withdrawal" class="btn btn-primary btn-sm"  data-toggle="modal"  data-target="#Modal1">
                    سحب
                 </a>
                 <?php endif; ?>
                 <?php if(hasRole('user_wallet_statement','user_wallet_show','user_wallet_index')): ?>
                 <a href="<?php echo e(url('/cp/wallet/print2',$data->id)); ?>" class="btn btn-primary btn-sm">
                    كشف حساب
                 </a>
                 <?php endif; ?>
        </div>

    </div>
    <!--  End path  -->



    <div class="card card-shadow">
        <?php echo $__env->make('CP.elerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('CP.elerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="card-header text-right bg-white pt-4">

            <div class="row">

                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">اسم الزبون</label>
                        <div class="col text-secondary">
                            <a href="<?php echo e(url('cp/customers',$data->customer->id)); ?>"><?php echo e($data->customer->name); ?></a>
                        </div>

                    </div>
                    <div class="border-b mb-1"></div>
                </div>

                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">رقم العضوية</label>
                        <div class="col text-secondary"><bdi><?php echo e($data->customer->code); ?></bdi></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px"> حالة المحفظة</label>
                        <div class="col text-secondary">
                        <label class="col-auto w-125px"> <?php echo e($data->getState()); ?></label>
                        </div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">الفرع</label>
                    <div class="col text-secondary"><bdi><label class="col-auto w-125px"><?php echo e($data->customer->branches->city); ?></label></bdi></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>




            </div>

            <div class="row">

                <div class="col-md-6 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">ملاحظة</label>
                        <div class="col text-secondary"></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

                <div class="col-md-6 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px pl-0">معلومات أخرى</label>
                        <div class="col text-secondary"></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

            </div>

        </div>
        


                
                <div class="card-body">


                    <table class="table table-center table-bordered text-center">
                        <thead>
                            <tr>

                                <th>LY طرابلس</th>
                                <th>$ طرابلس</th>
                                <th>LY بنغازي</th>
                                <th>$ بنغازي</th>
                                <th>LY مصراته</th>
                                <th>$ مصراته</th>
                            </tr>
                        </thead>
                        <tbody>




                            <tr>
                                <td><?php echo e($data->money_denar_t); ?></td>
                                <td><?php echo e($data->money_dolar_t); ?></td>
                                <td><?php echo e($data->money_denar_b); ?></td>
                                <td><?php echo e($data->money_dolar_b); ?></td>
                                <td><?php echo e($data->money_denar_m); ?></td>
                                <td><?php echo e($data->money_dolar_m); ?></td>
                            </tr>

                        </tbody>
                    </table>

                </div>
                

                
                <div class="card-body">


                    <table class="table table-center table-bordered text-center">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>الرقم</th>
                                <th>النوع</th>
                                <th>القيمة</th>
                                <th>العملة</th>
                                <th>التاريخ</th>
                                <th>الفرع</th>
                                <th>اسم الموظف</th>
                                <th class="">ملاحظة</th>
                                <?php if(hasRole('user_wallet_depoprint') or hasRole('user_wallet_edit') or hasRole('user_wallet_delete')): ?>
                                <th class="">عمليات</th>
                                <?php endif; ?>

                            </tr>
                        </thead>
                        <tbody>



                            <?php $__currentLoopData = $data->business; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $change): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id='<?php echo e($change->id); ?>' data-depotype='<?php echo e($change->type); ?>' data-price='<?php echo e($change->price); ?>' data-currencytype="<?php echo e($change->currencytype->id); ?>" data-branchess='<?php echo e($change->branchess->id); ?>' data-note='<?php echo e($change->note); ?>'>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($change->id); ?></td>
                                <td data="depotype"><?php echo e($change->depositytypee()); ?></td>
                                <td data="price"><?php echo e($change->price); ?></td>
                                <td><?php echo e($change->currencytype->name); ?></td>
                                <td><?php echo e($change->created_at); ?></td>
                                <td><?php echo e($change->branchess->city); ?></td>
                                <td><?php echo e($change->employe_name); ?></td>
                                <td data="note"><?php echo e($change->note); ?></td>
                                <?php if(hasRole('user_wallet_depoprint') or hasRole('user_wallet_edit') or hasRole('user_wallet_delete')): ?>
                                <td>
                                <?php if(hasRole('user_wallet_depoprint','user_wallet_show','user_wallet_index')): ?>
                                <a href="<?php echo e(url('/cp/wallet/print',$change->id)); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-print"></i></a>
                                <?php endif; ?>
                                <?php if(hasRole('user_wallet_edit','user_wallet_show','user_wallet_index')): ?>
                                <a href="" class="btn btn-primary btn-sm btnEdit" id="btnEdit" data-toggle="modal"  data-target="#Modal2" > <i class="fas fa-pen"> </i> </a>
                                <?php endif; ?>
                                <?php if(hasRole('user_wallet_delete','user_wallet_show','user_wallet_index')): ?>
                                <button class="btn btn-danger btn-sm btndelete" data-toggle="modal" data-target="#deleteModal">
                                    <i class="fas fa-trash"></i>
                                </button>
                                <?php endif; ?>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                        </tbody>
                    </table>


                </div>
                




    </div>
        <!--    Start Modal deleteModal -->
        <?php if(hasRole('user_wallet_delete','user_wallet_show','user_wallet_index')): ?>
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">حذف الطلب</h5>
                        <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <form class="formSendAjaxRequest" refresh-seconds='2' action="<?php echo e(url('/cp/wallet/delete')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                    <div class="alert-danger">
                        <small class="text-danger" id="error4_error2"></small>
                        <small  id="errors_error" style="display: block;font-size: 16px;font-family: 'PhpDebugbarFontAwesome';text-align:center;"></small>
                        </div>

                        <div class="modal-body text-right">
                            <div class="formResult text-center"></div>
                            <input type="hidden" name="id" id="id6"/>
                            <input type="hidden" name="type" id="type6"/>
                            هل أنت متأكد أنك تريد حذف الطلب ؟
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger">حذف</button>
                            <button type="button" class="btn btn-secondary mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <!--    End Modal deleteModal -->
<!--    Start Modal Modal -->

<div class="modal fade" id="Modal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ModalLabel">ايداع فالحساب</h5>
                <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="formSendAjaxRequest" action="<?php echo e(url('/cp/wallet/create')); ?>" method="POST" refresh-seconds='2'>
                <?php echo csrf_field(); ?>
                <div class="alert-danger">
                    <small class="text-danger" id="wallet_id_error"></small>
                    <small  id="errors_error" style="display: block;font-size: 16px;font-family: 'PhpDebugbarFontAwesome';text-align:center;"></small>
                    </div>
                <div class="modal-body px-sm-5">
                        <div class="formResult text-center"></div>
                    <input type="hidden" name="wallet_id" id="wallet_id" value="<?php echo e($data->id); ?>"/>
                    <input type="hidden" name="type" id="type" value="1"/>
                        <div class="form-group row">
                            <label for="curance_type_id" class="col-sm-auto w-125px col-form-label text-right">نوع العملة</label>
                            <div class="col-sm">
                                <select id="curance_type_id" name="curance_type_id" class="form-control" >
                                    <option value="" selected>اختر...</option>
                                <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <small class="text-danger" id="curance_type_id_error" style="display: flex;"></small>
                            </div>
                            <small class="text-danger" id="carancytype_error"></small>
                        </div>
                        <div class="form-group row">
                            <label for="price" class="col-sm-auto w-125px col-form-label text-right">القيمة</label>
                            <div class="col-sm">
                                <input type="text" name="price" class="form-control" id="price" placeholder="القيمة">
                                <small class="text-danger" id="price_error" style="display: flex;" ></small>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="note" class="col-sm-auto w-125px pl-0 col-form-label text-right">ملاحظة</label>
                            <div class="col-sm">
                                <input type="text" name="note" class="form-control" id="note" placeholder="ملاحظة">
                                <small class="text-danger" id="note_error" style="display: flex;"></small>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="branches" class="col-sm-auto w-125px col-form-label text-right">الفرع</label>
                            <div class="col-sm">
                                <select id="branches_id" name="branches_id" class="form-control" >
                                    <option value="" selected>اختر...</option>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->city); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <small class="text-danger" id="branches_id_error" style="display: flex;"></small>
                            </div>
                        </div>


                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary submit">تحديث</button>
                        <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!--    End Modal Modal -->

<!--    Start Modal Modal 2 -->
<div class="modal fade" id="Modal1" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ModalLabel">سحب من الحساب</h5>
                <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="formSendAjaxRequest" refresh-seconds='2'  method="POST" action="<?php echo e(url('/cp/wallet/create')); ?>">
                <?php echo csrf_field(); ?>
                <div class="alert-danger">
                    <small class="text-danger" id="wallet_id_error2"></small>
                    <small  id="errors_error" style="display: block;font-size: 16px;font-family: 'PhpDebugbarFontAwesome';text-align:center;"></small>
                    </div>
                     <div class="modal-body px-sm-5">
                            <div class="formResult text-center"></div>
                             <input type="hidden" name="wallet_id" id="wallet_id1" value="<?php echo e($data->id); ?>"/>
                             <input type="hidden" name="type" id="type1" value="2"/>
                            <div class="form-group row">
                                <label for="curance_type_id" class="col-sm-auto w-125px col-form-label text-right">نوع العملة</label>
                                <div class="col-sm">
                                    <select id="curance_type_id1" name="curance_type_id" class="form-control" >
                                        <option value="" selected>اختر...</option>
                                    <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <small class="text-danger" id="curance_type_id_error2" style="display: flex;"></small>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="price" class="col-sm-auto w-125px col-form-label text-right">القيمة</label>
                                <div class="col-sm">
                                    <input type="text" name="price" class="form-control" id="price1" placeholder="القيمة">
                                    <small class="text-danger" id="price_error2" style="display: flex;" ></small>
                                    <small class="text-danger" id="error2_error2" style="display: flex;font-size: 16px;font-family: 'PhpDebugbarFontAwesome';"></small>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="note" class="col-sm-auto w-125px pl-0 col-form-label text-right">ملاحظة</label>
                                <div class="col-sm">
                                    <input type="text" name="note" class="form-control" id="note1" placeholder="ملاحظة">
                                    <small class="text-danger" id="note_error2" style="display: flex;"></small>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="branches" class="col-sm-auto w-125px col-form-label text-right">الفرع</label>
                                <div class="col-sm">
                                    <select id="branches_id1" name="branches_id" class="form-control" >
                                        <option value="" selected>اختر...</option>
                                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->city); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <small class="text-danger" id="branches_id_error2" style="display: flex;"></small>
                                </div>
                            </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary submit">تحديث</button>
                            <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </div>
            </form>
        </div>
    </div>
</div>
<!--    End Modal Modal 2 -->

<!--    Start Modal Modal 3-->
<div class="modal fade" id="Modal2" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ModalLabel">تعديل</h5>
                <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="alert-danger">
            <small  id="error3_error2" style="display: block;font-size: 16px;font-family: 'PhpDebugbarFontAwesome';margin-left: 150px;"></small>
            </div>
            <form class="formSendAjaxRequest"  id="form3" refresh-seconds='2'  method="POST" action="<?php echo e(url('/cp/wallet/update')); ?>">
                <?php echo csrf_field(); ?>
                <div class="alert-danger">
                    <small class="text-danger" id="wallet_id_error"></small>
                    <small  id="errors_error" style="display: block;font-size: 16px;font-family: 'PhpDebugbarFontAwesome';text-align:center;"></small>
                    </div>
                <div class="modal-body px-sm-5">
                    <div class="formResult text-center"></div>
                    <input type="hidden" readonly name="id" id="id3"/>
                    <input type="hidden"  readonly name="wallet_id" id="wallet_id3" value="<?php echo e($data->id); ?>"/>
                    <input type="hidden"  readonly name="type" id="type3"/>
                    <input type="hidden"  readonly name="branches_id" id="branches_id3"/>
                    <input type="hidden"  readonly name="curance_type_id" id="curance_type_id3"/>
                        <div class="form-group row">
                            <label for="price" class="col-sm-auto w-125px col-form-label text-right">القيمة</label>
                            <div class="col-sm">
                                <input type="text" name="price" class="form-control" id="price3" placeholder="القيمة">
                                <small class="text-danger" id="price_error" style="display: flex;" ></small>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="note" class="col-sm-auto w-125px pl-0 col-form-label text-right">ملاحظة</label>
                            <div class="col-sm">
                                <input type="text" name="note" class="form-control" id="note3" placeholder="ملاحظة">
                                <small class="text-danger" id="note_error" style="display: flex;"></small>
                            </div>
                        </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary submit">تحديث</button>
                        <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!--    End Modal Modal 3-->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra-js'); ?>
    <script>
        var form = $('#Modal form')[0];
        var form2 = $('#Modal1 form')[0];
        var form3 = $('#Modal2 form')[0];
        var form4 = $('#deleteModal form')[0];
        let change1;
        let change2;
        // ###################
        let destroyid;
        let destroytype;
        $('#deposity').click(function(){
            $(form)[0].reset('');
            $('#curance_type_id_error').text('');
            $('#price_error').text('');
            $('#branches_id_error').text('');
            $('#branches_id_error').text('');
            $('#wallet_id_error').text('');
            $('#note_error').text('');
            wallet_id_error2
        });
        $('#Withdrawal').click(function(){
            $(form2)[0].reset();
            $('#curance_type_id_error2').text('');
            $('#price_error2').text('');
            $('#error2_error2').text('');
            $('#branches_id_error2').text('');
            $('#branches_id_error2').text('');
            $('#wallet_id_error2').text('');
            $('#note_error2').text('');
        });
            $('.btnEdit').click(function() {
                        var tr = $(this).closest('tr');
                        $('#ModalLabel').html('تعديل');
                        $(form3).find('input[name="id"]').val(tr.attr('id'));
                        $(form3).find('input[name="curance_type_id"]').val(tr.data('currencytype'));
                        $(form3).find('input[name="price"]').val(tr.find('td[data="price"]').html());
                        $(form3).find('input[name="note"]').val(tr.find('td[data="note"]').html());
                        $(form3).find('input[name="type"]').val(tr.data('depotype'));
                        $(form3).find('input[name="branches_id"]').val(tr.data('branchess'));
                        change1 = $('#type3').val();
                        change2 =  $('#id3').val();
                        change3 = $('#wallet_id3').val();
                        change4 = $('#curance_type_id3').val();
                        change5 = $('#branches_id3').val();
        });
        $('.btndelete').click(function() {
                var tr = $(this).closest('tr');
                $('#deleteModalLabel').html('حدف');
                $(form4).find('input[name="id"]').val(tr.attr('id'));
                $(form4).find('input[name="type"]').val(tr.data('depotype'));
                change1=$('#id6').val();
                change2=$('#type6').val();
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/customer_wallet/show.blade.php ENDPATH**/ ?>