<?php $__env->startSection('content'); ?>



<div class="d-flex justify-content-between">
    <h4 class="font-weight-bold">الحوالات المالية <?php echo e($transfers->total()); ?></h4>
    
    <?php if(hasRole('money_transfers_add')): ?>
        <a class="btn btn-primary w-100px" href="<?php echo e(url('cp/money-transfers/create')); ?>">
            <i class="fas fa-plus mx-1"></i>أضف
        </a>
    <?php endif; ?>

</div>





<div class="card card-shadow my-4 text-center">
        
    <!-- Start search  -->
    <div class="card-header bg-primary text-white"> 
        <form class="justify-content-between" action="<?php echo e(Request::url()); ?>" method="get">
            <input type="hidden" name="search" value="1">

            <div class="form-inline">
                <span class="ml-2"><i class="fa fa-filter"></i></span>
                <div class="form-group">
                    <label class="d-none" for="inputTransferIdSearch">رقم الحوالة</label>
                    <input type="number" min="1" name="id" value="<?php echo e(Request::get('id')); ?>" placeholder="رقم الحوالة" id="inputTransferIdSearch" class="form-control mx-sm-2">
                </div>
                <div class="form-group">
                    <label class="d-none" for="inputCodeSearch">رقم العضوية</label>
                    <input type="number" min="1" name="code" value="<?php echo e(Request::get('code')); ?>" placeholder="رقم العضوية" id="inputCodeSearch" class="form-control mx-sm-2">
                </div>
                <div class="form-group">
                    <label class="d-none" for="inputRecipientSearch">اسم المستلم</label>
                    <input type="search" maxlength="32" name="recipient" value="<?php echo e(Request::get('recipient')); ?>" placeholder="اسم المستلم" id="inputRecipientSearch" class="form-control mx-sm-2">
                </div>
                <div class="form-group">
                    <label class="d-none" for="inputPhoneSearch">رقم الهاتف</label>
                    <input type="search" maxlength="32" name="phone" value="<?php echo e(Request::get('phone')); ?>" placeholder="رقم الهاتف" id="inputPhoneSearch" class="form-control mx-sm-2">
                </div>
                <div class="form-group">
                    <label class="d-none" for="inputStateSearch">الحالة</label>
                    <select id="inputStateSearch" class="form-control mx-sm-2 setValue" style="width: 220px;" name="state" value="<?php echo e(Request::get('state')); ?>">
                        <option value="">كل الحالات</option>
                        <?php $__currentLoopData = trans('moneyTransfer.status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
            </div>

        </form>  
    </div>  
    <!-- End search  -->


    <?php
        $canEdit =  hasRole('money_transfers_edit')        
    ?>

    <!--    Start show Transfers   -->
    <div class="card-body p-0">
        <table class="table table-center table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col" class="no-wrap">رقم الحوالة</th>
                    <th scope="col">الزبون</th>
                    <th scope="col" class="no-wrap">رقم الهاتف</th>
                    <th scope="col">اسم المستلم</th>
                    <th scope="col">الحالة</th>
                    <th scope="col">المبلغ</th>
                    <th scope="col">تاريخ الإضافة</th>

                    <?php if($canEdit): ?>
                        <th scope="col">تعديل</th>
                    <?php endif; ?>
                
                </tr>
            </thead>
            <tbody>

                <!-- Start print Transfers -->
                <?php $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><a target="_blank" href="<?php echo e(url('cp/money-transfers',$transfer->id)); ?>"><?php echo e($transfer->id); ?></a></td> 
                        <td>
                            <a href="<?php echo e(url('cp/customers',$transfer->customer_id)); ?>">
                                <bdi><?php echo e($transfer->customer->code); ?></bdi>-<?php echo e($transfer->customer->name); ?>

                            </a>
                        </td> 
                        <td><bdi><?php echo e($transfer->phone); ?></bdi></td> 
                        <td><bdi><?php echo e($transfer->recipient); ?></bdi></td> 
                        <td class="no-wrap"><?php echo e($transfer->getState()); ?></td> 
                        <td class="no-wrap"><b><?php echo e($transfer->amount.$transfer->currency->sign); ?></b></td> 
                        <td><bdi><?php echo e($transfer->created_at()); ?></bdi></td>
                        
                        <?php if($canEdit): ?>
                            <td>
                                <a href="<?php echo e(url('cp/money-transfers/edit',$transfer->id)); ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-pen"></i>
                                </a>
                            </td>
                        <?php endif; ?>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- End print Transfers -->

            </tbody>
        </table>
    </div>
    <!--    End show Transfers   -->

</div>





<div class="pagination-center"><?php echo e($transfers->links()); ?></div>  



<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/money_transfers/index.blade.php ENDPATH**/ ?>