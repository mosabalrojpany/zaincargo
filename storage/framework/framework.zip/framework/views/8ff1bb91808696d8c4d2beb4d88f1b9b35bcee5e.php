<?php $__env->startSection('content'); ?>
    

    <!--    Start header    -->
    <div class="d-flex justify-content-between">
        <h4 class="font-weight-bold">الأخبار <?php echo e($posts->total()); ?></h4>
        
        <?php if(hasRole('posts_add')): ?>
            <a href="<?php echo e(url('cp/posts/create')); ?>" class="btn btn-primary w-100px">
                <i class="fas fa-plus mx-1"></i>أضف
            </a>
        <?php endif; ?>

    </div>
    <!--    End header    -->




    <div class="row pt-4 mb-5 text-right">


        <!--    Start search box     -->
        <aside class="col-lg-4 col-xl-3">

            <form action="<?php echo e(Request::url()); ?>">

                <input type="hidden" name="search" value="1" />

                <div class="form-group">
                    <label>التصنيف</label>
                    <select name="tag" class="form-control setValue" value="<?php echo e(Request::get('tag')); ?>">
                        <option value="" selected>الكل</option> 
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($t->id); ?>"><?php echo e($t->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>  
                <div class="form-group">
                    <label>الناشر</label>
                    <select name="user" class="form-control setValue" value="<?php echo e(Request::get('user')); ?>">
                        <option value="" selected>الكل</option> 
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($u->id); ?>"><?php echo e($u->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>  
                <div class="form-group">
                    <label>الحالة</label>
                    <select name="state" class="form-control setValue" value="<?php echo e(Request::get('state')); ?>">
                        <option value="" selected>الكل</option> 
                        <option value="0">غير منشور</option> 
                        <option value="1">منشور</option> 
                    </select>
                </div> 
                <div class="form-group">
                    <label>أضيف من</label>
                    <input type="date" value="<?php echo e(Request::get('from')); ?>" max="<?php echo e(date('Y-m-d')); ?>" name="from" class="form-control" />
                </div>
                <div class="form-group">
                    <label>أضيف إلى</label>
                    <input type="date" value="<?php echo e(Request::get('to')); ?>" max="<?php echo e(date('Y-m-d')); ?>" name="to" class="form-control" />
                </div> 
                <button type="submit" class="btn btn-primary btn-block mt-2 mb-5">بحث</button>

            </form>

        </aside>
        <!--    End search box     -->



        <!--    Start show data  -->
        <section class="col-lg-8 col-xl-9">

            <?php if(count($posts) > 0): ?>
                
                <div class="bg-white p-4 shadow">

                    <div class="row"> 

                        
                        <?php
                            $canEdit = hasRole('posts_edit')        
                        ?>

                        <!-- Start print posts -->
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <div class="box-posts col-md-6 mb-3">

                                <div class="post-img">
                                    <a href="<?php echo e(url('cp/posts',$post->id)); ?>">
                                        <img src="<?php echo e($post->getImageAvatar()); ?>" />
                                        <span class="overly"></span>
                                    </a>
                                    <label class="post-date">
                                        <bdi><?php echo e($post->created_at()); ?></bdi>
                                    </label>

                                    <?php if($canEdit): ?>
                                        <a href="<?php echo e(url('cp/posts/edit',$post->id)); ?>" class="btn btn-primary post-edit">
                                            <i class="fa fa-pen"></i>
                                        </a>
                                    <?php endif; ?>

                                </div>

                                <?php if(!$post->active): ?>
                                    <label class="post-flag text-white px-2 mt-4 bg-danger">غير فعالة</label>
                                <?php endif; ?>
                                
                                <div class="px-1">
                                    <h5 class="post-title my-2">
                                        <a href="<?php echo e(url('cp/posts',$post->id)); ?>"><?php echo e($post->title); ?></a>
                                    </h5>
                                    <span class="text-muted d-inline-block mb-2 f-15px"> 
                                        <i class="fas fa-user mx-1"></i><?php echo e($post->user->name); ?>

                                        <i class="fa fa-tags fa-sm mr-2"></i>
                                        <bdi><?php echo e(collect($post->tags->pluck('name'))->implode(' , ')); ?></bdi>  
                                    </span>
                                </div>
                            </div>
    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <!-- End print posts -->

                    </div>

                </div>
            
            <?php else: ?>
                
                <h1 class="text-secondary py-5 my-5 text-center">لايوجد نتائج</h1>
            
            <?php endif; ?> 

             <div class="pagination-center mt-4"><?php echo e($posts->links()); ?></div>  

        </section>
        <!--    End show data  -->


    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/posts/index.blade.php ENDPATH**/ ?>