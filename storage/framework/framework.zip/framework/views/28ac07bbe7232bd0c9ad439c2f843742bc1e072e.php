<?php $__env->startSection('content'); ?>
    


    
    <!--    show errors if there is error    -->
    <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    
    <!--    Start header    -->
    <div class="d-flex justify-content-between">
        <h4 class="font-weight-bold">الزبائن <?php echo e($customers->total()); ?></h4>

        <?php if(hasRole('customers_add')): ?>
            <button class="btn btn-primary w-100px" data-toggle="modal" data-active="0" data-target="#addModal">
                <i class="fas fa-plus mx-1"></i>أضف
            </button>
        <?php endif; ?>
        
    </div>
    <!--    End header    -->





    <div class="row pt-4 mb-5 text-right">


        <!--    Start search box     -->
        <aside class="col-lg-4 col-xl-3 mb-5">
            <form action="<?php echo e(Request::url()); ?>">
                <input type="hidden" name="search" value="1" /> 
                <div class="form-group">
                    <label>رقم العضوية</label>
                    <input type="number" value="<?php echo e(Request::get('code')); ?>" min="1" name="code" class="form-control" />
                </div>
                <div class="form-group">
                    <label>الاسم</label>
                    <input type="search" value="<?php echo e(Request::get('name')); ?>" name="name" maxlength="32" class="form-control" />
                </div>
                <div class="form-group">
                    <label>رقم الهاتف</label>
                    <input type="search" value="<?php echo e(Request::get('phone')); ?>" name="phone" maxlength="32" class="form-control" />
                </div>
                <div class="form-group">
                    <label>البريد الإلكتروني</label>
                    <input type="search" value="<?php echo e(Request::get('email')); ?>" name="email" maxlength="32" class="form-control" />
                </div>
                <div class="form-group">
                    <label>العنوان</label>
                    <input type="search" value="<?php echo e(Request::get('address')); ?>" name="address" maxlength="32" class="form-control" />
                </div>
                <div class="form-group">
                    <label>استلام في</label>
                    <select name="receive_in" id="inputReceiveInSearch" class="form-control setValue" value="<?php echo e(Request::get('receive_in')); ?>">
                        
                    </select>
                </div> 
                <div class="form-group">
                    <label>الحالة</label>
                    <select name="state" class="form-control setValue" value="<?php echo e(Request::get('state')); ?>">
                        <option value="0" selected>الكل</option>  
                        <?php $__currentLoopData = $STATE; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_DB => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <option value="<?php echo e($key_DB); ?>" ><?php echo e($value); ?></option>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>   
                <div class="form-group">
                    <label>معلومات أخرى</label>
                    <input type="search" value="<?php echo e(Request::get('extra')); ?>" name="extra" maxlength="32" class="form-control" />
                </div> 
                <div class="form-group">
                    <label>سجل من</label>
                    <input type="date" value="<?php echo e(Request::get('from')); ?>" max="<?php echo e(date('Y-m-d')); ?>" name="from" class="form-control" />
                </div>
                <div class="form-group">
                    <label>سجل إلى</label>
                    <input type="date" value="<?php echo e(Request::get('to')); ?>" max="<?php echo e(date('Y-m-d')); ?>" name="to" class="form-control" />
                </div> 
                <div class="form-group">
                    <label>فعل من</label>
                    <input type="date" value="<?php echo e(Request::get('activated_from')); ?>" max="<?php echo e(date('Y-m-d')); ?>" name="activated_from" class="form-control" />
                </div>
                <div class="form-group">
                    <label>فعل إلى</label>
                    <input type="date" value="<?php echo e(Request::get('activated_to')); ?>" max="<?php echo e(date('Y-m-d')); ?>" name="activated_to" class="form-control" />
                </div> 
                <button type="submit" class="btn btn-primary btn-block mt-2">بحث</button>
            </form>
        </aside>
        <!--    End search box     -->



        <!--    Start show data  -->
        <section class="col-lg-8 col-xl-9">

            <div class="row">

                <?php if(count($customers) > 0): ?>
                    <!-- Start print customers -->
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <div class="col-md-6 col-lg-4 mb-5"> 
                            <div class="card customer-card <?php echo e($customer->getStateColor()); ?>">
                                <div class="flip-card">
                                    <div class="flip-card-inner">
                                        <div class="flip-card-front"> 
                                            <img src="<?php echo e($customer->getImageAvatar()); ?>" class="customer-img">
                                        </div>
                                        <div class="flip-card-back">
                                            <ul class="list-with-icon p-3">
                                                <li>
                                                    <span class="item-icon text-secondary">
                                                        <i class="fa fa-phone"></i>
                                                    </span>
                                                    <bdi><?php echo e($customer->phone); ?></bdi>
                                                </li>
                                                <li>
                                                    <span class="item-icon text-secondary">
                                                        <i class="fa fa-envelope"></i>
                                                    </span>
                                                    <bdi><?php echo e($customer->email); ?></bdi>
                                                </li>
                                                <li>
                                                    <span class="item-icon text-secondary">
                                                        <i class="fa fa-map-marker-alt"></i>
                                                    </span>
                                                    <bdi><?php echo e($customer->address); ?></bdi>
                                                </li>
                                                <li title="<?php echo e($customer->created_at->format('Y-m-d g:ia')); ?>">
                                                    <span class="item-icon text-secondary">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                    <bdi><?php echo e($customer->created_at->diffForHumans()); ?></bdi>
                                                </li>
                                                <?php if($customer->last_access): ?>
                                                    <li title="<?php echo e($customer->last_access->format('Y-m-d g:ia')); ?>">
                                                        <span class="item-icon text-secondary">
                                                            <i class="far fa-clock"></i>
                                                        </span>
                                                        <bdi><?php echo e($customer->last_access->diffForHumans()); ?></bdi>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body text-center">
                                    <h4 class="mb-1">
                                        <a href="<?php echo e(url('cp/customers',$customer->id)); ?>"><bdi><?php echo e($customer->code); ?></bdi></a>
                                    </h4> 
                                    <a class="d-block text-dark" href="<?php echo e(url('cp/customers',$customer->id)); ?>">
                                        <bdi><?php echo e($customer->name); ?></bdi>
                                    </a> 
                                </div>
                            </div>  
                        </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- End print customers --> 
                <?php else: ?>
                    <h1 class="text-secondary py-5 my-5 text-center w-100">لايوجد نتائج</h1>
                <?php endif; ?> 
            </div>
             <div class="pagination-center mt-2"> <?php echo e($customers->links()); ?></div>  
        </section>
        <!--    End show data  -->


    </div>



       
    <?php if(hasRole('customers_add')): ?> 
        
        <!--    Start Modal addModal -->
        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addModalLabel">إضافة زبون</h5>
                        <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form class='formSendAjaxRequest was-validated' refresh-seconds='2' upload-files='true' focus-on='#addModalLabel' action="<?php echo e(Request::url()); ?>" enctype="multipart/form-data" method="post">
                        <div class="modal-body px-5">

                            <div class="formResult text-center"></div>

                            <div class="row"> 
                                <?php echo e(csrf_field()); ?>

                                <div class="col-lg-6 text-center pb-2">
                                    <div class="image-upload">
                                        <label class="m-0 img-box avatar-customer">
                                            <img src="<?php echo e(url('images/no-image-user.svg')); ?>" default-img="<?php echo e(url('images/no-image-user.svg')); ?>" class="w-100 h-100 rounded-circle">
                                        </label>
                                        <input class="form-control img-input" type="file" name="img" accept=".png,.jpg,.jpeg,.gif">
                                        <div class="invalid-feedback text-center"><?php echo app('translator')->get("validation.mimes",[ "attribute"=>"","values" => "png,jpg,jpeg,gif"]); ?></div>        
                                    </div>
                                </div>
                                <div class="col-lg-6 pt-3">
                                    <div class="form-group row">
                                        <label for="inputName" class="col-auto w-150px col-form-label text-right">الاسم</label>
                                        <div class="col pr-md-0">
                                            <input type="text" name="name" id="inputName" class="form-control" pattern="\s*([^\s]\s*){3,32}" required>
                                            <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'الاسم','min'=> 3 ,'max'=>32]); ?></div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPhone" class="col-auto w-150px col-form-label text-right">رقم الهاتف</label>
                                        <div class="col pr-md-0">
                                            <input type="text" name="phone" id="inputPhone" class="form-control text-right" dir='ltr' pattern="\s*([0-9\-\+]\s*){3,14}" placeholder="XXX-XXXXXXX" required>
                                            <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.digits_between',['attribute'=>'رقم الهاتف','min'=> 3 ,'max'=>14]); ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        <label for="inputAddress" class="col-auto w-150px col-form-label text-right">العنوان</label>
                                        <div class="col pr-md-0">
                                            <input type="text" name="address" id="inputAddress" class="form-control" pattern="\s*([^\s]\s*){3,64}" required>
                                            <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'العنوان','min'=> 3 ,'max'=>64]); ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        <label for="inputReceiveIn" class="col-auto w-150px col-form-label text-right">استلام في</label>
                                        <div class="col pr-md-0">
                                            <select id="inputReceiveIn" class="form-control" name="receive_in" required>
                                                <option value="">...</option>
                                                <?php $__currentLoopData = $receivingPlaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($place->id); ?>"><?php echo e($place->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                            </select>
                                            <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.required',['attribute'=>'المكان']); ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        <label for="inputEmail" class="col-auto w-150px col-form-label text-right">البريد الإلكتروني</label>
                                        <div class="col pr-md-0">
                                            <input id="inputEmail" type="email" class="form-control" name="email" required>
                                            <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.required',['attribute'=>'البريد الإلكتروني']); ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        <label for="inputState" class="col-auto w-150px col-form-label text-right">الحالة</label>
                                        <div class="col pr-md-0">
                                            <select id="inputState" name="state" class="form-control setValue" required>
                                                <option value="3">تفعيل</option>
                                                <option value="2">إيقاف</option>
                                            </select>
                                            <div class="invalid-feedback text-center">يجب تحديد الحالة</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        <label for="inputPassword" class="col-auto w-150px col-form-label text-right">كلمة المرور</label>
                                        <div class="col pr-md-0">
                                            <input id="inputPassword" type="password" minlength="6" maxlength="32" class="form-control" name="password" placeholder="كلمة المرور الجديدة" required>
                                            <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'كلمة المرور','min'=> 6 ,'max'=>32]); ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        <label for="inputPasswordConfirmation" class="col-auto w-150px col-form-label text-right">تأكيد كلمة المرور</label>
                                        <div class="col pr-md-0">
                                            <input id="inputPasswordConfirmation" type="password" minlength="6" maxlength="32" class="form-control" placeholder="تأكيد كلمة المرور الجديدة" name="password_confirmation"
                                                required>
                                            <div class="invalid-feedback text-center">يجب أن تكون كلمات المرور متساوية</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        <label class="col-auto w-150px col-form-label text-right">ملف التحقق</label>
                                        <div class="col pr-md-0">
                                            <div class="custom-file">
                                                <input type="file" name="verification_file" class="custom-file-input" id="customFileInput" accept=".jpeg, .png, .jpg, .gif, .pdf" required>
                                                <label class="custom-file-label" for="customFileInput">اختر ملف</label>
                                                <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.mimes',[ 'attribute'=>'ملف التحقق','values' => 'jpeg,png,jpg,gif,pdf']); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group row">
                                        <label for="inputExtra" class="col-auto w-150px col-form-label text-right">أخرى</label>
                                        <div class="col pr-md-0">
                                            <textarea name="extra" id="inputExtra" maxlength="500" rows="4" class="form-control"></textarea>
                                            <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.max.string',['attribute'=>'معلومات أخرى','max'=>500]); ?></div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">حفظ</button>
                            <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--    End Modal addModal -->
    
    <?php endif; ?>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('extra-js'); ?>
    <script> 

            /*  */
            var inputReceiveInSearch = $('#inputReceiveInSearch');
            $(inputReceiveInSearch).html($('#inputReceiveIn').html());
            $(inputReceiveInSearch).val($(inputReceiveInSearch).attr('value'));
            $(inputReceiveInSearch).find('option[value=""]').html('الكل');

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/customers/index.blade.php ENDPATH**/ ?>