<?php $__env->startSection('content'); ?>


<!--  Start path  -->
<div class="d-flex align-items-center bg-white mb-3 d-print-none">

    <nav class="col pr-0" aria-label="breadcrumb" role="navigation">
        <ol class="breadcrumb bg-white mb-0">
            <li class="breadcrumb-item">
                <a href="<?php echo e(url('cp/trips')); ?>">الرحلات</a>
            </li>
            <li class="breadcrumb-item active text-truncate col pr-0 text-right" aria-current="page">
                <span class="mr-1"><?php echo e($trip->id); ?></span>
            </li>
        </ol>
    </nav>

    <div class="col-auto">

        <?php if(hasRole('trips_edit')): ?>
            <a href="<?php echo e(url('cp/trips/edit',$trip->id)); ?>" class="btn btn-primary btn-sm">
                <i class="fas fa-pen"></i>
            </a>
        <?php endif; ?>

        <?php if(hasRole('trips_delete')): ?>
            <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteModal">
                <i class="fas fa-trash"></i>
            </button>
        <?php endif; ?>
    </div>

</div>
<!--  End path  -->



<div class="card card-shadow">

    
    <div class="card-header text-right bg-white pt-4">

        <div class="row">

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">رقم الرحلة</label>
                    <div class="col text-secondary"><bdi><?php echo e($trip->trip_number); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">رقم التتبع</label>
                    <div class="col text-secondary"><bdi><?php echo e($trip->tracking_number); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">الحالة</label>
                    <div class="col text-secondary"><b><?php echo e($trip->getState()); ?></b></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">الشركة</label>
                    <div class="col text-secondary"><bdi><?php echo e($trip->company->name); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">العنوان</label>
                    <div class="col text-secondary"><?php echo e($trip->address->name); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">تاريخ الإضافة</label>
                    <div class="col text-secondary"><bdi><?php echo e($trip->created_at()); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">تاريخ الخروج</label>
                    <div class="col text-secondary"><bdi><?php echo e($trip->exit_at()); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">تاريخ الوصول المتوقع</label>
                    <div class="col text-secondary"><bdi><?php echo e($trip->estimated_arrive_at()); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">تاريخ الوصول الفعلي</label>
                    <div class="col text-secondary"><bdi><?php echo e($trip->arrived_at()); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px pl-0">العملة</label>
                    <div class="col text-secondary"><b><?php echo e($trip->currency->name); ?></b></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <?php if (! ($trip->isCurrencyEqualsMain())): ?>

                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px pl-0">سعر الصرف</label>
                        <div class="col text-secondary"><b><?php echo e($trip->exchange_rate); ?></b></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

            <?php endif; ?>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">التكلفة</label>
                    <div class="col"><b><?php echo $trip->cost(); ?></b></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">الوزن الفعلي</label>
                    <div class="col text-secondary"><bdi><?php echo e($trip->weight); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <?php if (! ($trip->isCurrencyEqualsMain())): ?>
                <div class="col-md-6 col-lg-4 mb-3"></div>
            <?php endif; ?>

            <div class="col-md-6 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">وصف الحالة</label>
                    <div class="col text-secondary"><b><?php echo e($trip->state_desc); ?></b></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 mb-3">
                <div class="row">
                    <label class="col-auto w-125px pl-0">معلومات أخرى</label>
                    <div class="col text-secondary"><?php echo e($trip->extra); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

        </div>

        <hr/>

        <div class="row">

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px pl-0">إجمالي التكاليف</label>
                    <div class="col text-secondary"><bdi><?php echo e($trip->total_cost); ?></bdi> <?php echo e(app_settings()->currency->sign); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px pl-0">إجمالي التكاليف الإضافية</label>
                    <div class="col text-secondary"><bdi><?php echo e($trip->total_additional_cost); ?></bdi> <?php echo e(app_settings()->currency->sign); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px pl-0">إجمالي المدفوع</label>
                    <div class="col text-secondary"><bdi><?php echo e($trip->total_paid); ?></bdi> <?php echo e(app_settings()->currency->sign); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px pl-0">إجمالي الوزن</label>
                    <div class="col text-secondary">kg<bdi><?php echo e($trip->invoices->sum('weight')); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px pl-0">إجمالي الوزن الحجمي</label>
                    <div class="col text-secondary">kg<bdi><?php echo e($trip->invoices->sum('volumetric_weight')); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px pl-0">إجمالي الحجم (CBM)</label>
                    <div class="col text-secondary">CBM<bdi><?php echo e($trip->invoices->sum('cubic_meter')); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

        </div>

    </div>
    


    
    <div class="card-body">


        
        <h4 class="p-3 bg-secondary text-white text-right mb-0 rounded-top">إجمالي التكلفة</h4>

        <table class="table table-center table-bordered text-center">
            <thead>
                <tr>
                    <th>#</th>
                    <th>التكلفة</th>
                    <th>العملة</th>
                    <th>عدد الشحنات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data->total_cost_by_currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($cost['amount']); ?></td>
                    <td><?php echo e($cost['currency']); ?></td>
                    <td><?php echo e($cost['count']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        


        
        <h4 class="p-3 bg-secondary text-white text-right mb-0 rounded-top">المبلغ المستلم</h4>

        <table class="table table-center table-bordered text-center">
            <thead>
                <tr>
                    <th>#</th>
                    <th>المدفوع</th>
                    <th>العملة</th>
                    <th>عدد الشحنات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data->total_paid_by_currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($paid['amount']); ?></td>
                    <td><?php echo e($paid['currency']); ?></td>
                    <td><?php echo e($paid['count']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        



        <?php $__currentLoopData = $data->receive_in; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <h4 class="p-3 bg-primary text-white text-right mb-0 rounded-top">مكان الاستلام : <?php echo e($data->shipments[$place][0]->receivingPlace->name); ?></h4>

        <table class="table table-center table-bordered text-center">
            <thead>
                <tr>
                    <th>#</th>
                    <th>رقم الفاتورة</th>
                    <th>رمز الشحنة</th>
                    <th>رقم العضوية</th>
                    <th>الوزن</th>
                    <th>الوزن الحجمي</th>
                    <th>الحجم(CBM)</th>
                    <th>تكلفة الشحن</th>
                    <th>المدفوع</th>
                    <th>الحالة</th>
                </tr>
            </thead>
            <tbody>

                
                <?php $__currentLoopData = $data->shipments[$place]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><a href="<?php echo e(url('cp/shipping-invoices',$invoice->id)); ?>" target="_blank"><?php echo e($invoice->id); ?></a></td>
                        <td><bdi><?php echo e($invoice->shipment_code); ?></bdi></td>
                        <td>
                            <a target="_blank" href="<?php echo e(url('cp/customers',$invoice->customer_id)); ?>">
                                <?php echo e($invoice->customer->code); ?>

                            </a>
                        </td>
                        <td>kg<bdi><?php echo e($invoice->weight); ?></bdi></td>
                        <td>kg<bdi><?php echo e($invoice->volumetric_weight); ?></bdi></td>
                        <td>CBM<bdi><?php echo e($invoice->cubic_meter); ?></bdi></td>
                        <td><?php echo $invoice->total_cost(); ?></td>
                        <td><?php echo $invoice->paid(); ?></td>
                        <td><bdi><?php echo e($invoice->getState()); ?></bdi></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                


                
                <?php $__currentLoopData = $data->cost_by_currencies[$place]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="3">
                            <h5 class="mb-0">التكلفة : <b><?php echo e($cost['amount']); ?></b></h5>
                        </td>
                        <td colspan="4">
                            <h5 class="mb-0">العملة : <b><?php echo e($cost['currency']); ?></b></h5>
                        </td>
                        <td colspan="3">
                            <h5 class="mb-0">عدد الشحنات : <b><?php echo e($cost['count']); ?></b></h5>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td colspan="10">
                        <h5 class="mb-0">إجمالي التكلفة بالعملة الرئيسية : <b><?php echo e($data->cost[$place]); ?> <bdi><?php echo e(app_settings()->currency->name); ?></bdi></b></h5>
                    </td>
                </tr>
                


                
                <?php $__currentLoopData = $data->paid_by_currencies[$place]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="3">
                            <h5 class="mb-0">المدفوع : <b><?php echo e($paid['amount']); ?></b></h5>
                        </td>
                        <td colspan="4">
                            <h5 class="mb-0">العملة : <b><?php echo e($paid['currency']); ?></b></h5>
                        </td>
                        <td colspan="3">
                            <h5 class="mb-0">عدد الشحنات : <b><?php echo e($paid['count']); ?></b></h5>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td colspan="10">
                        <h5 class="mb-0">إجمالي المدفوع بالعملة الرئيسية : <b><?php echo e($data->paid[$place]); ?> <bdi><?php echo e(app_settings()->currency->name); ?></bdi></b></h5>
                    </td>
                </tr>
                


                </tbody>
            </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </div>
    



</div>



    <?php if(hasRole('trips_delete')): ?>

        <!--    Start Modal deleteModal -->
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">حذف رحلة</h5>
                        <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <form class='formSendAjaxRequest' redirect-to='<?php echo e(url('/cp/trips')); ?>' refresh-seconds='2' action="<?php echo e(url('/cp/trips')); ?>"
                        method="post">
                        <div class="modal-body text-right">
                            <div class="formResult text-center"></div>
                            <?php echo method_field('DELETE'); ?>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($trip->id); ?>" />
                            هل أنت متأكد أنك تريد حذف الرحلة ؟
                            <br/>
                            <b>ملاحظة</b> سيتم إلغاء ربط الشحنات بالرحلة في حالة حذفها
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger">حذف</button>
                            <button type="button" class="btn btn-secondary mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--    End Modal deleteModal -->

    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/trips/show.blade.php ENDPATH**/ ?>