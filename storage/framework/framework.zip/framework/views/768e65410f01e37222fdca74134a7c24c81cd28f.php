<?php if(Session::has('error')): ?>
<div class="alert alert-danger" role="alert" style="margin-top: 10PX;text-align: center;">
  <?php echo e((Session::get('error'))); ?>  
  </div>
<?php endif; ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/elerts/errors.blade.php ENDPATH**/ ?>