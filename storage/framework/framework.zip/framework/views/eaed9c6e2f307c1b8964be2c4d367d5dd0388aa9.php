<?php $__env->startSection('content'); ?>



    <!--    Start header    -->
    <div class="d-flex justify-content-between">
        <h4 class="font-weight-bold">النسخ الاحتياطية <?php echo e(count($files)); ?></h4>
        <?php if(hasRole('backups_add')): ?>
            <button class="btn btn-primary btnAdd" data-toggle="modal" data-active="0" data-target="#Modal">
                <i class="fas fa-plus mx-1"></i>أحذ تسخة احتياطية
            </button>
        <?php endif; ?>
    </div>
    <!--    End header    -->




    
    <div class="card card-shadow my-4 text-center">

        <!--    Start show backups   -->
        <div class="card-body p-0">

            <table class="table table-striped text-center">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">الملف</th>
                        <th scope="col">التاريخ</th>
                        <th scope="col">الحجم</th>
                        <th scope="col">خيارات</th>
                    </tr>
                </thead>
                <tbody>

                    <!-- Start print backups -->
                    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><bdi><?php echo e($file['name']); ?></bdi></td>
                            <td><bdi><?php echo e($file['date']); ?></bdi></td>
                            <td><bdi><?php echo e($file['size']); ?></bdi></td>
                            <td>
                                <?php if(hasRole('backups_download')): ?>
                                    <a class="btn btn-secondary btn-sm" href="<?php echo e(url('cp/backups',$file['name'])); ?>" >
                                        <i class="fa fa-download"></i>
                                    </a>
                                    <?php endif; ?>

                                <?php if(hasRole('backups_delete')): ?>
                                    <button type="button" class="btn btn-danger btn-sm btnDelete" data-toggle="modal" data-target="#deleteModel" data-id="<?php echo e($file['name']); ?>">
                                        <i class="fas fa-trash fa-fx"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- End print backups -->

                </tbody>
            </table>

        </div>
        <!--    End show backups   -->


    </div>
    




<?php if(hasRole('backups_delete')): ?>

    
    <div class="modal fade" id="deleteModel" tabindex="-1" role="dialog" aria-labelledby="deleteModelLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModelLabel">حذف نسخة احتياطية</h5>
                    <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form class='formSendAjaxRequest' redirect-to="<?php echo e(Request::url()); ?>" refresh-seconds='2' action="<?php echo e(url('cp/backups')); ?>" method="post">

                    <div class="modal-body text-right">
                        <div class="formResult text-center"></div>
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" />
                        هل أنت متأكد أنك تريد حذف الملف ؟
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-danger">حذف</button>
                        <button type="button" class="btn btn-secondary mr-2" data-dismiss="modal">إلغاء</button>
                    </div>

                </form>

            </div>
        </div>
    </div>
    

<?php endif; ?>



<?php if(hasRole('backups_add')): ?>

    <!--    Start Add Modal  -->
    <div class="modal fade" id="Modal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ModalLabel">أخذ نسخة احتياطية</h5>
                    <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class='formSendAjaxRequest was-validated' refresh-seconds='2' action="<?php echo e(url('/cp/backups')); ?>" method="post"
                        msgSuccess="سيتم إرسال إليك رسالة على البريد الإلكتروني عندما يتم الإنتهاء من أخذ النسحة الاحتياطية">

                    <div class="modal-body px-sm-5">
                        <div class="formResult text-center"></div>
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group row">
                            <label for="inputType" class="col-sm-auto w-75px col-form-label text-right">النوع</label>
                            <div class="col-sm">
                                <select id="inputType" name="type" class="form-control" required>
                                    <option value="0" selected>الكل</option>
                                    <option value="1">قاعدة البيانات</option>
                                    <option value="2">الملفات</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">أخذ</button>
                        <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--    End Add Modal  -->

<?php endif; ?>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra-js'); ?>
    <script>

        <?php if(hasRole('backups_add')): ?>
            var form = $('#Modal form')[0];

            $('.btnAdd').click(function() {
                form.reset();
                $(form).find('.formResult').html('');
            });
        <?php endif; ?>

        <?php if(hasRole('backups_delete')): ?>
            
            $('.btnDelete').click(function () {
                $('#deleteModel form input[name="id"]').val($(this).data('id'));
            });
        <?php endif; ?>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/backups.blade.php ENDPATH**/ ?>