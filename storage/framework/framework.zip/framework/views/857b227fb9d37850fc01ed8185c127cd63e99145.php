<?php $__env->startSection('content'); ?>


    <!--  hero area start  -->
    <div class="hero-area hero-bg-3 home-3">
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-lg-9">
                    <div class="hero-txt">
                        <h1 class="wow fadeInUp" data-wow-duration="1.5s">شركة إلكتروليبيا<br/> للشحن وخدمات التسوق</h1>

                        <?php if (! (authClient()->check())): ?>

                            <a class="wow fadeInUp boxed-btn mr-2" data-wow-duration="1.5s" href="<?php echo e(url('client/register')); ?>">
                                <span>سجل الأن</span>
                            </a>

                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="hero-overlay"></div>
    </div>
    <!--  hero area end  -->


    <!--  service section start  -->
    <div class="service-section home-3">
        <div class="container">
            <span class="title">خدمتنا</span>
            <h2 class="subtitle">خدمات نقدمها</h2>
            <div class="services">
                <div class="row">

                    <div class="col-lg-6 mb-3">
                        <div class="single-service wow fadeInUp" data-wow-duration="1.5s">
                            <div class="icon-wrapper"><i class="flaticon-airplane"></i></div>
                            <div class="service-txt">
                                <h4 class="service-title">الشحن الجوي</h4>
                                <p class="service-para">نقدم خدمة الشحن الجوي من البلدان التجارية المعروفة التي يكون عليها الشحن الجوي بإستمرار وعلى مدار السنين مثل (الصين , الولايات المتحدة ) كما نقوم بتطوير الخدمة لتصبح أفضل وأسرع كما نطمح أن يكون الشحن الجوي من وإلى جميع بلدان العالم .</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 mb-3">
                        <div class="single-service wow fadeInUp" data-wow-duration="1.5s" data-wow-delay=".2s">
                            <div class="icon-wrapper"><i class="flaticon-ferry"></i></div>
                            <div class="service-txt">
                                <h4 class="service-title">الشحن البحري</h4>
                                <p class="service-para">ان خدمة الشحن البحري هيا خدمة رئيسية في مجال الشحن لانها تكون ارخص عادة وبكميات كبيرة لدلك تسعى شركة الكترو ليبيا الي تقديم افضل الخدمات في الشحن البحري من جميع بلدان العالم لتكون البداية من اكبر دولة تجارية (الصين) وكدلك بلدان اخرى .</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 mb-3">
                        <div class="single-service wow fadeInUp" data-wow-duration="1.5s" data-wow-delay=".4s">
                            <div class="icon-wrapper"><i class="flaticon-email"></i></div>
                            <div class="service-txt">
                                <h4 class="service-title">تخليص فواتير</h4>
                                <p class="service-para">تسعى شركة الكترو ليبيا لتقديم افضل الخدمات لزبائنها الكرام ومن هذه الخدمات خدمة تخليص الفواتير في حالة كان لدى الزبون فاتورة خارج دولة ليبيا لا يستطيع تخليصها نحن بدورنا نقدم هذه الخدمة للتسهيل على زبائننا عملية شراء البضائع من الخارج .</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 mb-3">
                        <div class="single-service wow fadeInUp" data-wow-duration="1.5s" data-wow-delay=".6s">
                            <div class="icon-wrapper"><i class="flaticon-worldwide"></i></div>
                            <div class="service-txt">
                                <h4 class="service-title">حوالات خارجية</h4>
                                <p class="service-para">من الخدمات التي تقدمها شركة إلكتروليبيا خدمة إرسال الأموال من دولة ليبيا إلى جميع بلدان العالم سواء كانت قيمة المبلغ صغيرة أو كبيرة فبإمكاننا إرسال أموالك إلي خارج دولة ليبيا بعمولة بسيطة سواء اكانت حوالة إلي بنك أو استلام نقدا مباشرا .</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--  service section end  -->


    <!--  about section start  -->
    <div class="about-section home-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 offset-lg-2">
                    <img class="ceo-pic" src="<?php echo e(url('assets/img/about-us-img.png')); ?>" alt="حولنا">
                </div>
                <div class="col-lg-6">
                    <div class="comment-content">
                        <span class="title">حولنا</span>
                        <h2 class="subtitle">من نحن</h2>
                        <p>شركة إلكتروليبيا للشحن وخدمات التسوق..نوفر لك منتجاتك الى ليبيا ونتسوق لك من اي مكان</p>
                        <p>تأسست الشركة في عام 2016 بشكل تجاري حر , وفي عام 2019 تأسست بشكل قانوني كامل تحت اسم شركة إلكتروليبيا لخدمات الشحن والتسوق االلكتروني ذ.م.م- مقرها الرئيسي بنغازي - الفويهات, برأس مال أولي 50000 دينار ليبي .</p>
                        <p>تم فتح فرع في طرابلس وفرع في مصراته .وتطمح الشركة بأن تكون هي الرائدة في مجال الشحن والتسوق الإلكتروني في ليبيا وفي جميع أنحاء العالم.</p>

                        <a class="readmore" href="<?php echo e(url('about')); ?>">اقرأ المزيد</a>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--  about section end  -->


    <!--  features section start  -->
    <div class="features-section home-2 border-top border-top-lg-0">
        <div class="container">
            <div class="row feature-content">
                <div class="col-xl-5 col-lg-6 mr-auto pl-0">
                    <div class="features">
                        <span class="title">مميزاتنا</span>
                        <h2 class="subtitle">لماذا تختارنا</h2>

                        <div class="feature-lists">

                            <div class="single-feature wow fadeInUp" data-wow-duration="1s">
                                <div class="icon-wrapper"><i class="flaticon-customer-service"></i></div>
                                <div class="feature-details">
                                    <h4>24/7 دعم فني</h4>
                                    <p>نعمل بجهد وبشكل متواصل لتوفير خدمات دعم فني مميزة لزبائننا والرد على كل الاستفسارات.</p>
                                </div>
                            </div>

                            <div class="single-feature wow fadeInUp" data-wow-duration="1s" data-wow-delay=".2s">
                                <div class="icon-wrapper"><i class="flaticon-email"></i></div>
                                <div class="feature-details">
                                    <h4>الإنجاز السريع</h4>
                                    <p>نحن نسعى لتسريع إنجاز خدماتنا مع توفير إجابات واضحة وشفافة للزبائننا .</p>
                                </div>
                            </div>

                            <div class="single-feature wow fadeInUp" data-wow-duration="1s" data-wow-delay=".4s">
                                <div class="icon-wrapper"><i class="flaticon-worldwide"></i></div>
                                <div class="feature-details">
                                    <h4>خدمات عالمية</h4>
                                    <p>نحن نسعى جاهدين إلى تطوير خدماتنا لكي نكون الأفضل ونقدم خدمات بجودة عالمية عالية جدا.</p>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--  features section end  -->


    <!--  testimonial section start  -->
    <div class="testimonial-section pb-5 mb-5 home-3">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <span class="title">أراء زبائننا</span>
                    <h2 class="subtitle">ماذا يقولون عنا</h2>
                </div>
            </div>
            <div class="row" style="direction: ltr;">
                <div class="col-md-12">
                    <div class="testimonial-carousel-3 owl-carousel owl-theme">

                        <div class="single-testimonial">
                            <div class="img-wrapper">
                                <img src="<?php echo e(url('assets/img/testimonial/Mohamed_Badi.png')); ?>" alt="">
                            </div>
                            <div class="client-desc">
                                <p class="icon-wrapper"><i class="flaticon-quote-left"></i></p>
                                <p class="comment">خدمات ما شاء الله.. الأفضل في ليبيا من جميع النواحي.. الأسعار والخدمات والمعاملة وسرعة الرد.. بالتوفيق إن شاء الله وإلى الأفضل</p>
                                <h5 class="name mb-3">‏‎Mohamed Badi‎</h5>
                            </div>
                        </div>

                        <div class="single-testimonial">
                            <div class="img-wrapper">
                                <img src="<?php echo e(url('assets/img/testimonial/Enaam_Alalem.png')); ?>" alt="">
                            </div>
                            <div class="client-desc">
                                <p class="icon-wrapper"><i class="flaticon-quote-left"></i></p>
                                <p class="comment">ماشاء الله خدمة العملاء ممتازة ، وخدمات الشحن تعتبر جيدة جداً كبداية ودائماً يسعوا للأفضل هذا شيء يحسبلهم وبأذن الله حيكون عندكم مستقبل زاهر وتنافسوا شركات عالمية 🌸</p>
                                <h5 class="name mb-3">Enaam Alalem</h5>
                            </div>
                        </div>

                        <div class="single-testimonial">
                            <div class="img-wrapper">
                                <img src="<?php echo e(url('assets/img/testimonial/Om_Arhoma_Rheel.png')); ?>" alt="">
                            </div>
                            <div class="client-desc">
                                <p class="icon-wrapper"><i class="flaticon-quote-left"></i></p>
                                <p class="comment">الشركة الاولي للشحن في ليبيا من حيث المميزات والاهتمام برضي العملاء فعلا مجهود يذكر فيشكر فلكم منا كل الاحترام والتقدير 🌹🌹🌹</p>
                                <h5 class="name mb-3">Om Arhoma Rheel‎</h5>
                            </div>
                        </div>

                        <div class="single-testimonial">
                            <div class="img-wrapper">
                                <img src="<?php echo e(url('assets/img/testimonial/Mosab_A_Shlimbo.png')); ?>" alt="">
                            </div>
                            <div class="client-desc">
                                <p class="icon-wrapper"><i class="flaticon-quote-left"></i></p>
                                <p class="comment">معامله و سرعة رد اسعار الله يبارك 👍</p>
                                <h5 class="name mb-3">Mosab A Shlimbo‎</h5>
                            </div>
                        </div>

                        <div class="single-testimonial">
                            <div class="img-wrapper">
                                <img src="<?php echo e(url('assets/img/testimonial/Munsir_Megrisi.png')); ?>" alt="">
                            </div>
                            <div class="client-desc">
                                <p class="icon-wrapper"><i class="flaticon-quote-left"></i></p>
                                <p class="comment">معاملة ممتازة ويمتازو بالجدية في العمل</p>
                                <h5 class="name mb-3">‏‎Munsir Megrisi‎‏</h5>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--  testimonial section end  -->



    <!--   quote section start    -->
    <div class="quote-section quote-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-xl-9">
                    <div class="quote-form-section">
                        <h2 class="subtitle">حاسبة الأسعار</h2>
                        <form action="<?php echo e(url('api/calculate-shipping-cost')); ?>" id="formQuoteCost">

                            <div class="errorResult"></div>

                            <div class="row text-white">

                                <div class="col-md-6 col-lg-4">
                                    <div class="form-element">
                                        <label>الطول بالسنتيمتر</label>
                                        <input type="number" min="0.1" max="1500" step="any" name="length" placeholder="الطول" required>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-4">
                                    <div class="form-element">
                                        <label>العرض بالسنتيمتر</label>
                                        <input type="number" min="0.1" max="1500" step="any" name="width" placeholder="العرض" required>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-4">
                                    <div class="form-element">
                                        <label>الارتفاع بالسنتيمتر</label>
                                        <input type="number" min="0.1" max="1500" step="any" name="height" placeholder="الارتفاع" required>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-4">
                                    <div class="form-element">
                                        <label>الوزن بالكيلوجرام</label>
                                        <input type="number" min="0.001" max="1000000" step="any" name="weight" placeholder="الوزن" required>
                                    </div>
                                </div>

                                <div class="col-md-6 col-lg-4">
                                    <div class="form-element">
                                        <label>نوع الشحن</label>
                                        <div class="select-wrapper">
                                            <select name="type" required>
                                                <option value="" selected disabled>نوع الشحن</option>
                                                <?php $__currentLoopData = trans('shippingAddress.types'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6 col-lg-4">
                                    <div class="form-element">
                                        <label>البلد</label>
                                        <div class="select-wrapper">
                                            <select name="country" required>
                                                <option value="" selected disabled>اختر البلد</option>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6 col-lg-4">
                                    <div class="form-element">
                                        <label>العملة</label>
                                        <div class="select-wrapper">
                                            <select name="currency" required>
                                                <option value="" selected disabled>اختر العملة</option>
                                                <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($currency->id); ?>"><?php echo e($currency->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6 col-lg-4">
                                    <div class="form-element">
                                        <label>عنوان الشحن</label>
                                        <div class="select-wrapper">
                                            <select name="address" required>
                                                <option value="" selected disabled>اختر العنوان</option>
                                                <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($address->id); ?>" data-country="<?php echo e($address->country_id); ?>" data-type="<?php echo e($address->type); ?>"><?php echo e($address->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-12 mt-4">
                                    <div class="form-element mb-0">
                                        <button type="submit" class="boxed-btn">
                                            <span>احسب التكلفة</span>
                                        </button>
                                    </div>
                                </div>

                            </div>

                            <div class="costResult mx-n4 mx-md-0"></div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--   quote section end    -->



    <!--   news section start    -->
    <div class="news-section">
        <div class="container">
            <span class="title">أخر الأخبار</span>
            <h2 class="subtitle">كن على إطلاع</h2>
            <div class="row">

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 mb-3">
                        <div class="single-news wow fadeInRight" data-wow-duration="1.5s">

                            <img src="<?php echo e($post->getImageAvatar()); ?>" alt="<?php echo e($post->title); ?>">

                            <div class="news-txt">

                                <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(url("news?tag=$tag->name")); ?>" class="tag ml-1">
                                        <i class="fa fa-tag" style="vertical-align: middle"></i>
                                        <?php echo e($tag->name); ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                |
                                <span class="date">
                                    <i class="far fa-clock" style="vertical-align: middle"></i>
                                    <bdi><?php echo e($post->getDate()); ?></bdi>
                                </span>

                                <a href="<?php echo e(url('news',$post->id)); ?>" class="title">
                                    <h3><?php echo e($post->title); ?></h3>
                                </a>

                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
    <!--   news section end    -->


<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra-js'); ?>

    <script>

        
        $('#formQuoteCost select[name="type"] ,#formQuoteCost select[name="country"]').change(function () {

            var type = $('#formQuoteCost select[name="type"]').val();
            var country = $('#formQuoteCost select[name="country"]').val();

            var addressSelect = $('#formQuoteCost select[name="address"]');
            $(addressSelect).val('');

            if (type || country) {
                $(addressSelect).find('option').hide();
                $(addressSelect).find('option[value=""]').show();
            }
            else {
                $(addressSelect).find('option').show();
                return 0;
            }

            var filter = '';
            if (type) {
                filter += '[data-type="' + type + '"]';
            }
            if (country) {
                filter += '[data-country="' + country + '"]';
            }

            $(addressSelect).find(filter).show();

        });



        
        $('#formQuoteCost').submit(function (e) {

            e.preventDefault(); /* cancel send form */

            var btnSubmit = this;
            $(btnSubmit).attr('disabled', 'disabled');

            var paramters = {
                address: $(this).find('[name="address"]').val(),
                currency: $(this).find('[name="currency"]').val(),
                length: $(this).find('[name="length"]').val(),
                width: $(this).find('[name="width"]').val(),
                height: $(this).find('[name="height"]').val(),
                weight: $(this).find('[name="weight"]').val(),
            };


            var currency = $(this).find('[name="type"]').val() == 1 ? 'دينار ليبي<bdi>(د.ل)</bdi>' : 'دولار<bdi>($)</bdi>';

            var costResult = $('.costResult');
            var errorResult = $('.errorResult');

            $(costResult).html('');
            $(errorResult).html('');

            $.ajax({
                url: "<?php echo e(url('api/calculate-shipping-cost')); ?>",
                dataType: 'json',
                data: paramters,
                method: 'GET',
            })
                .done(function (result) { /* Form seneded success without any error */

                    costResult.html(
                          '<div class="cart-cards checkout pb-0">'
                        + '    <div class="card">'
                        + '        <div class="card-header">'
                        + '            <h5>تكلفة الشحنة</h5>'
                        + '        </div>'
                        + '        <div class="card-body text-dark">'
                        + '            <div class="calculations">'
                        + '                <div class="single-calc">'
                        + '                    <strong>الطول</strong>'
                        + '                    <span><bdi>' + result.length + '</bdi> سنتيمتر<bdi>(cm)</bdi></span>'
                        + '                </div>'
                        + '                <div class="single-calc">'
                        + '                    <strong>العرض</strong>'
                        + '                    <span><bdi>' + result.width + '</bdi> سنتيمتر<bdi>(cm)</bdi></span>'
                        + '                </div>'
                        + '                <div class="single-calc">'
                        + '                    <strong>الارتفاع</strong>'
                        + '                    <span><bdi>' + result.height + '</bdi> سنتيمتر<bdi>(cm)</bdi></span>'
                        + '                </div>'
                        + '                <div class="single-calc">'
                        + '                    <strong>الوزن الفعلي</strong>'
                        + '                    <span><bdi>' + result.weight + '</bdi> كيلوجرام<bdi>(kg)</bdi></span>'
                        + '                </div>'
                        + '                <div class="single-calc">'
                        + '                    <strong>الوزن الحجمي</strong>'
                        + '                    <span><bdi>' + result.volumetric_weight + '</bdi> كيلوجرام<bdi>(kg)</bdi></span>'
                        + '                </div>'
                        + '                <div class="single-calc">'
                        + '                    <strong>الحجم</strong>'
                        + '                    <span><bdi>' + result.size + '</bdi> متر مكعب<bdi>(cbm)</bdi></span>'
                        + '                </div>'
                        + '                <div class="single-calc total">'
                        + '                    <strong>الإجمالي</strong>'
                        + '                    <span><bdi>' + result.cost + '</bdi>' + result.currency_sign + ' <bdi>('+result.currency+')</bdi></span>'
                        + '                </div>'
                        + '            </div>'
                        + '        </div>'
                        + '    </div>'
                        + '</div>'
                    );

                    $("html ,body").animate({
                        scrollTop: $(costResult).offset().top - 50
                    }, 'slow');

                })
                .fail(function (result) { /* There is error in send form or in server-side */

                    console.log(result);

                    try {
                        var errorString = '<div class="alert alert-danger alert-dismissible text-right fade show role="alert"><ul class="mb-0">';
                        var response = JSON.parse(result.responseText);

                        if (response.errors) {
                            $.each(response.errors, function (key, value) {
                                $.each(value, function (k, v) {
                                    errorString += '<li>' + v + '</li>';
                                });
                            });
                        }
                        else {
                            errorString += '<li>حدث خطأ</li>';
                            console.error(response.message);
                        }

                    } catch (e) {
                        errorString += '<li>حدث خطأ يرجى التأكد من اتصالك بالإنترنت وإعادة المحاولة</li>';
                    } finally {
                        errorString += '</ul><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
                        $("html ,body").animate({
                            scrollTop: $(errorResult).offset().top - 120
                        }, 'slow');
                        $(errorResult).html(errorString);
                    }

                })
                .always(function () {

                    $(btnSubmit).removeAttr('disabled');

                });

        });
        

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/main/index.blade.php ENDPATH**/ ?>