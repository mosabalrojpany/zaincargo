<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel="icon" type="image/png"   href="<?php echo e(url('images/logo.png')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/sheets-of-paper.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;400;900&display=swap" rel="stylesheet">
</head>

<body class="document" style="font-family: Cairo">

    <style>

        /* arabic */

        @font-face {
            font-family: 'Tajawal';
            font-style: normal;
            font-weight: 400;
            src: url( <?php echo e(url('fonts/Tajawal/Tajawal-Medium.ttf')); ?> );
        }

        body {
            direction: rtl;
            font-family: Tajawal;
        }

        .header {
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            padding-bottom: 20px;
            border-bottom: 1px solid #000;
            margin-bottom: 20px;
        }

        .header img {
            height: 80px;
        }
        .header .title {
            font-size: 24px;
            text-align: right;
            padding-right: 10px;
            margin: 0;
        }
        .page-title {
            text-align: center;
            font-size: 18px;
            text-decoration: underline;
            text-underline-position: under;
        }
        .info {
            display: flex;
            justify-content: space-between;
        }
        .info ul {
            padding: 0;
            list-style: none;
            max-width: 50%;
        }
        .info ul li {
            line-height: 1.5;
        }
        .table {
            width: 100%;
            text-align: center;
            border-collapse: collapse;
        }
        .table th , .table td {
            padding: 7px;
            border: 1px solid #ddd;
        }
        .footer ul {
            padding: 0;
            list-style: none;
        }
        .footer ul li {
            line-height: 1.5;
        }
        .footer{
            margin-top: 450px;
        }
    </style>
    <div class="page">
        <div class="header">
            <img src="<?php echo e(url('images/logo-with-title-black.png')); ?>" />
        </div>
    <h2 class="page-title"> فاتورة تخليص فواتير شراء </h2>
        <div class="info">
            <ul>
                <li><b>رقم الفاتورة /<?php echo e($invoice->id); ?> </b></li>
                <li><b>رقم العضوية / <?php echo e($invoice->customer->code); ?> </b><bdi></bdi></li>
                <li><b>اسم التاجر /<?php echo e($invoice->customer->name); ?> </b></li>

            </ul>
            <ul>
                <li><b>تاريخ الانشاء / <?php echo e($invoice->created_at->format('Y-m-d')); ?> </b><bdi></bdi></li>
            </ul>
        </div>
                        
                        <div class="card-body" style="margin-bottom: 50px; margin-top: 50px;">


                            <table class="table table-center table-bordered text-center">
                                <thead>
                                    <tr>

                                        <th>عدد الفواتير</th>
                                        <th> اجمالي التكلفة دينار</th>
                                        <th>اجمالي التكلفة دولار</th>
                                    </tr>
                                </thead>
                                <tbody>




                                    <tr>
                                        <td><?php echo e($invoice->invoicec->count()); ?></td>
                                        <td><?php echo e($invoice->price_dener); ?></td>
                                        <td><?php echo e($invoice->price_dolar); ?></td>
                                    </tr>

                                </tbody>
                            </table>

                        </div>
                        

                        
        <div class="card-body" style="margin-top: 50px">
        <div class="details">
            <table class="table">
                <thead>
                    <tr>
                        <th>رقم الفاتورة</th>
                        <th>الفرع</th>
                        <th>العمولة</th>
                        <th>الاجمالي</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $invoice->invoicec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <tr>
                        <td><?php echo e($invoices->id); ?></td>
                        <td><?php if($invoices->branch_id > null): ?><?php echo e($invoices->branche->city); ?> <?php else: ?> لا يوجد <?php endif; ?></td>
                        <td><?php echo e($invoices->getFee()); ?></td>
                        <td><?php echo e($invoices->getTotalCostByCurrency()); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        </div>


    <script>
        print();
        window.onafterprint = function() {
        history.go(-1);}
        window.onafterclose = function() {
            window.close();}
    </script>

</body>

</html>
<?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/marchentinvoice/print.blade.php ENDPATH**/ ?>