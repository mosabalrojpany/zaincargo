<?php $__env->startSection('content'); ?>


    
    <div class="d-flex justify-content-between align-items-center">
        <h4 class="font-weight-bold mb-0">طلبات الشراء <?php echo e($orders->total()); ?></h4>
        <a class="btn btn-primary w-100px" href="<?php echo e(url('client/purchase-orders/create')); ?>">
            <i class="fas fa-plus mx-1"></i>أضف
        </a>
    </div>
    



    
    <div class="card card-shadow my-4 text-center">

        <!-- Start search  -->
        <div class="card-header bg-primary text-white">
            <form class="row justify-content-between" action="<?php echo e(Request::url()); ?>" method="get">

                <input type="hidden" name="search" value="1">

                <div class="form-inline col-auto d-none d-lg-flex">
                    <div class="form-group">
                        <label for="inputShowSearch">عرض</label>
                        <input type="number" id="inputShowSearch" name="show" min="10" max="500" class="form-control mx-sm-2" value="<?php echo e(Request::has('show') ? Request::get('show') : 25); ?>" />
                    </div>
                </div>

                <div class="form-inline">
                    <span class="mx-2"><i class="fa fa-filter"></i></span>
                    <div class="form-group mb-0">
                        <label class="d-none" for="inputIdSearch">رقم الطلب</label>
                        <input type="number" name="id" min="1" value="<?php echo e(Request::get('id')); ?>" placeholder="رقم الطلب" id="inputIdSearch" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group d-none d-sm-flex">
                        <label class="d-none" for="inputStateSearch">الحالة</label>
                        <select id="inputStateSearch" class="form-control mx-sm-2 setValue" style="min-width: 180px;" name="state" value="<?php echo e(Request::get('state')); ?>">
                            <option value="">كل الحالات</option>
                            <?php $__currentLoopData = trans('purchaseOrdersStatus.purchase_order_status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                </div>

            </form>
        </div>
        <!-- End search  -->

        <!--    Start show orders   -->
        <div class="card-body p-0">
            <table class="table table-center table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col" class="d-none d-md-table-cell">#</th>
                        <th scope="col">رقم الطلب</th>
                        <th scope="col">الحالة</th>
                        <th scope="col" class="d-none d-lg-table-cell">عمولة الشراء</th>
                        <th scope="col" class="d-none d-md-table-cell">إجمالي التكلفة</th>
                        <th scope="col" class="d-none d-sm-table-cell">تاريخ الطلب</th>
                    </tr>
                </thead>
                <tbody>

                    <!-- Start print orders -->
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <th scope="row" class="d-none d-md-table-cell"><?php echo e($loop->iteration); ?></th>
                            <td><a href="<?php echo e(url('client/purchase-orders',$order->id)); ?>"><?php echo e($order->id); ?></a></td>
                            <td><?php echo e($order->getState()); ?></td>
                            <td class="d-none d-lg-table-cell"><?php echo e($order->getFee()); ?></td>
                            <td class="d-none d-md-table-cell"><?php echo e($order->getTotalCostByCurrency()); ?></td>
                            <td class="d-none d-sm-table-cell"><bdi><?php echo e($order->created_at()); ?></bdi></td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- End print orders -->

                </tbody>
            </table>
        </div>
        <!--    End show orders   -->

    </div>
    



    
    <div class="pagination-center"><?php echo e($orders->links()); ?></div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/Client/purchase_orders/index.blade.php ENDPATH**/ ?>