<?php $__env->startSection('content'); ?>


    <?php
        $colors = [
            'purchase_orders' => '#F86080',
            'money_transfers' => '#359EE5',
            'trips' => '#F8C854',
            'shipping_invoices' => '#22CECE',
        ]
    ?>


    <div class="statistics text-right">

        
        <section class="row statistics-counts mb-3" >

            <div class="col-md-6 col-lg-3" style="padding: 10px;">
                <div class="card border-0 shadow">
                    <a href="<?php echo e(url('cp/purchase-orders')); ?>" class="card-body">
                        <div class="row">
                            <div class="col">
                                <h6 class="mb-2">طلبات الشراء جديدة</h6>
                                <h3 class="card-text"><?php echo e($newRequests->purchase_orders); ?></h3>
                            </div>
                            <div class="col-auto my-auto">
                                <i class="fa fa-shopping-cart"></i>
                            </div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="col-md-6 col-lg-3" style="padding: 10px;">
                <div class="card border-0 shadow">
                    <a href="<?php echo e(url('cp/money-transfers')); ?>" class="card-body">
                        <div class="row">
                            <div class="col">
                                <h6 class="mb-2">حوالات مالية جديدة</h6>
                                <h3 class="card-text"><?php echo e($newRequests->money_transfers); ?></h3>
                            </div>
                            <div class="col-auto my-auto">
                                <i class="fa fa-exchange-alt"></i>
                            </div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="col-md-6 col-lg-3" style="padding: 10px;">
                <div class="card border-0 shadow">
                    <a href="<?php echo e(url('cp/customers')); ?>" class="card-body">
                        <div class="row">
                            <div class="col">
                                <h6 class="mb-2">زبائن جدد</h6>
                                <h3 class="card-text"><?php echo e($newRequests->customers); ?></h3>
                            </div>
                            <div class="col-auto my-auto">
                                <i class="fa fa-users"></i>
                            </div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="col-md-6 col-lg-3" style="padding: 10px;">
                <div class="card border-0 shadow">
                    <a href="<?php echo e(url('cp/messages')); ?>" class="card-body">
                        <div class="row">
                            <div class="col">
                                <h6 class="mb-2">رسائل جديدة</h6>
                                <h3 class="card-text"><?php echo e($newRequests->messages); ?></h3>
                            </div>
                            <div class="col-auto my-auto">
                                <i class="fa fa-comments"></i>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <?php if(Auth::user()->role->id==1||Auth::user()->role->id==2): ?>
            <?php $__currentLoopData = $wallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-3" style="padding: 10px;">
                <div class="card border-0 shadow">
                    <a href="" class="card-body">
                        <div class="row">
                            <div class="col">
                                <h6 class="mb-2">رصيدالزبائن LY</h6>
                                <h3 class="card-text"><?php echo e($wallets->Customer_balance_denar); ?> <?php echo e($wallets->branches->city); ?></h3>
                            </div>
                            <div class="col-auto my-auto">
                                <i class="fa fa-comments"></i>
                            </div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="col-md-6 col-lg-3" style="padding: 10px;">
                <div class="card border-0 shadow">
                    <a class="card-body">
                        <div class="row">
                            <div class="col">
                                <h6 class="mb-2">رصيدالزبائن $</h6>
                                <h3 class="card-text"><?php echo e($wallets->Customer_balance_dolar); ?> <?php echo e($wallets->branches->city); ?></h3>
                            </div>
                            <div class="col-auto my-auto">
                                <i class="fa fa-comments"></i>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(Auth::user()->role->id>2): ?>
            <div class="col-md-6 col-lg-3" style="padding: 10px;">
                <div class="card border-0 shadow">
                    <a href="" class="card-body">
                        <div class="row">
                            <div class="col">
                                <h6 class="mb-2">رصيدالزبائن LY</h6>
                                <h3 class="card-text"><?php echo e($wallet->firstWhere('branche_id',auth::user()->branches_id)->Customer_balance_denar); ?></h3>
                            </div>
                            <div class="col-auto my-auto">
                                <i class="fa fa-comments"></i>
                            </div>
                        </div>
                    </a>
                </div>
            </div>

            <div class="col-md-6 col-lg-3" style="padding: 10px;">
                <div class="card border-0 shadow">
                    <a class="card-body">
                        <div class="row">
                            <div class="col">
                                <h6 class="mb-2">رصيدالزبائن $</h6>
                                <h3 class="card-text"><?php echo e($wallet->firstWhere('branche_id',auth::user()->branches_id)->Customer_balance_dolar); ?></h3>
                            </div>
                            <div class="col-auto my-auto">
                                <i class="fa fa-comments"></i>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endif; ?>
        </section>
        



        <!--    Start Financial movement Charts     -->
        <section class="row my-4 text-right">

            
            <div class="col-md-8 mb-3">
                <div class="card border-0 shadow rounded-lg overflow-hidden">

                    <div class="card-header bg-white">
                        <h6 class="text-secondary mb-1 mt-2">نظرة عامة</h6>
                        <h5>الحركة المالية لأخر 8 أشهر</h5>

                    </div>

                    <div class="card-body">
                        <canvas id="FinancialMovementLineChart"></canvas>
                    </div>

                </div>
            </div>
            


            
            <div class="col-md-4 mb-3">
                <div class="card h-100 border-0 shadow rounded-lg overflow-hidden">

                    <div class="card-header bg-white">
                        <h6 class="text-secondary mb-1 mt-2">نظرة عامة</h6>
                        <h5>الحركة المالية</h5>
                    </div>

                    <div class="card-body pb-2">

                        <ul class="pr-0 mb-1">
                            <li class="d-flex">
                                <span class="ml-2 text-center text-white w-50px" style="background-color:<?php echo e($colors['purchase_orders']); ?>;"><?php echo e($sum->percentage->purchase_orders_sum); ?>%</span>
                                <span>طلبات الشراء <?php echo e(number_format($sum->purchase_orders_sum)); ?>$</span>
                            </li>
                            <li class="d-flex my-1">
                                <span class="ml-2 text-center text-white w-50px" style="background-color:<?php echo e($colors['money_transfers']); ?>;"><?php echo e($sum->percentage->money_transfers_sum); ?>%</span>
                                <span>الحوالات المالية <?php echo e(number_format($sum->money_transfers_sum)); ?>$</span>
                            </li>
                            <li class="d-flex my-1">
                                <span class="ml-2 text-center text-white w-50px" style="background-color:<?php echo e($colors['trips']); ?>;"><?php echo e($sum->percentage->trips_sum); ?>%</span>
                                <span>الرحلات <?php echo e(number_format($sum->trips_sum)); ?>$</span>
                            </li>
                            <li class="d-flex my-1">
                                <span class="ml-2 text-center text-white w-50px" style="background-color:<?php echo e($colors['shipping_invoices']); ?>;"><?php echo e($sum->percentage->shipping_invoices_sum); ?>%</span>
                                <span>الشحنات <?php echo e(number_format($sum->shipping_invoices_sum)); ?>$</span>
                            </li>
                            <li class="d-flex">
                                <span class="ml-2 text-center text-white bg-secondary w-50px">100%</span>
                                <span>الإجمالي <?php echo e(number_format($sum->total_sum)); ?>$</span>
                            </li>
                        </ul>

                        <canvas id="FinancialMovementPieChart" width="100" height="70"></canvas>

                    </div>

                </div>
            </div>
            

        </section>
        <!--    End Financial movement Charts     -->



        <!--    Start Public movement Charts     -->
        <section class="row my-4 text-right">

            
            <div class="col-md-8 mb-3">
                <div class="card border-0 shadow rounded-lg overflow-hidden">

                    <div class="card-header bg-white">
                        <h6 class="text-secondary mb-1 mt-2">نظرة عامة</h6>
                        <h5>الحركة العامة لأخر 8 أشهر</h5>
                    </div>

                    <div class="card-body">
                        <canvas id="PublicMovementLineChart"></canvas>
                    </div>

                </div>
            </div>
            


            
            <div class="col-md-4 mb-3">
                <div class="card h-100 border-0 shadow rounded-lg overflow-hidden">

                    <div class="card-header bg-white">
                        <h6 class="text-secondary mb-1 mt-2">نظرة عامة</h6>
                        <h5>الحركة العامة</h5>
                    </div>

                    <div class="card-body pb-2">

                        <ul class="pr-0 mb-1">
                            <li class="d-flex">
                                <span class="ml-2 text-center text-white w-50px" style="background-color:<?php echo e($colors['purchase_orders']); ?>;"><?php echo e($sum->percentage->purchase_orders_count); ?>%</span>
                                <span>طلبات الشراء <?php echo e(number_format($sum->purchase_orders_count)); ?></span>
                            </li>
                            <li class="d-flex my-1">
                                <span class="ml-2 text-center text-white w-50px" style="background-color:<?php echo e($colors['money_transfers']); ?>;"><?php echo e($sum->percentage->money_transfers_count); ?>%</span>
                                <span>الحوالات المالية <?php echo e(number_format($sum->money_transfers_count)); ?></span>
                            </li>
                            <li class="d-flex my-1">
                                <span class="ml-2 text-center text-white w-50px" style="background-color:<?php echo e($colors['trips']); ?>;"><?php echo e($sum->percentage->trips_count); ?>%</span>
                                <span>الرحلات <?php echo e(number_format($sum->trips_count)); ?></span>
                            </li>
                            <li class="d-flex my-1">
                                <span class="ml-2 text-center text-white w-50px" style="background-color:<?php echo e($colors['shipping_invoices']); ?>;"><?php echo e($sum->percentage->shipping_invoices_count); ?>%</span>
                                <span>الشحنات <?php echo e(number_format($sum->shipping_invoices_count)); ?></span>
                            </li>
                            <li class="d-flex">
                                <span class="ml-2 text-center text-white bg-secondary w-50px">100%</span>
                                <span>الإجمالي <?php echo e(number_format($sum->total_count)); ?></span>
                            </li>
                        </ul>

                        <canvas id="PublicMovementPieChart" width="100" height="70"></canvas>

                    </div>

                </div>
            </div>
            


        </section>
        <!--    End Public movement Charts     -->

    </div>


<?php $__env->stopSection(); ?>




<?php $__env->startSection('extra-js'); ?>

    <link href="<?php echo e(url('css/Chart.min.css')); ?>" rel="stylesheet" />
    <script src="<?php echo e(url('js/Chart.bundle.min.js')); ?>"></script>
    <script>

        /*  Start plugin to write text in center of Pie     */
        Chart.pluginService.register({
            beforeDraw: function (chart) {

                if (chart.config.options.elements.center) {
                    //Get ctx from string
                    var ctx = chart.chart.ctx;

                    //Get options from the center object in options
                    var centerConfig = chart.config.options.elements.center;
                    var fontStyle = centerConfig.fontStyle || 'Arial';
                    var txt = centerConfig.text;
                    var color = centerConfig.color || '#000';
                    var sidePadding = centerConfig.sidePadding || 20;
                    var sidePaddingCalculated = (sidePadding / 100) * (chart.innerRadius * 2)
                    //Start with a base font of 30px
                    ctx.font = "30px " + fontStyle;

                    //Get the width of the string and also the width of the element minus 10 to give it 5px side padding
                    var stringWidth = ctx.measureText(txt).width;
                    var elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;

                    // Find out how much the font can grow in width.
                    var widthRatio = elementWidth / stringWidth;
                    var newFontSize = Math.floor(30 * widthRatio);
                    var elementHeight = (chart.innerRadius * 2);

                    // Pick a new font size so it will not be larger than the height of label.
                    var fontSizeToUse = Math.min(newFontSize, elementHeight);

                    //Set font settings to draw it correctly.
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
                    var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
                    ctx.font = fontSizeToUse + "px " + fontStyle;
                    ctx.fillStyle = color;

                    //Draw text in center
                    ctx.fillText(txt, centerX, centerY);
                }
            }
        });
        /*  End plugin to write text in center of Pie     */


        /*  Start Data for line chart */
            var months = [];/* months for Line Charts */

            var financial_chart = { /* data for Line financial_chart */
                purchase_orders : [],
                money_transfers : [],
                trips : [],
                shipping_invoices : [],
            }

            var public_chart = { /* data for Line public_chart (chart shows Counts) */
                purchase_orders : [],
                money_transfers : [],
                trips : [],
                shipping_invoices : [],
            }

            var chart_labels = { /* configs for chart labels */
                colors : {
                    purchase_orders: '<?php echo e($colors['purchase_orders']); ?>',
                    money_transfers: '<?php echo e($colors['money_transfers']); ?>',
                    trips: '<?php echo e($colors['trips']); ?>',
                    shipping_invoices: '<?php echo e($colors['shipping_invoices']); ?>',
                },
                names : {
                    purchase_orders: 'طلبات الشراء',
                    money_transfers: 'حوالات مالية',
                    trips: 'الرحلات',
                    shipping_invoices: 'الشحنات',
                }
            };

            
            <?php $__currentLoopData = $chart['purchase_orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                months.push(<?php echo e($p->month); ?>);

                financial_chart.purchase_orders.push(<?php echo e($p->sum); ?>);
                financial_chart.money_transfers.push(<?php echo e($chart['money_transfers'][$loop->index]->sum); ?>);
                financial_chart.trips.push(<?php echo e($chart['trips'][$loop->index]->sum); ?>);
                financial_chart.shipping_invoices.push(<?php echo e($chart['shipping_invoices'][$loop->index]->sum); ?>);

                public_chart.purchase_orders.push(<?php echo e($p->count); ?>);
                public_chart.money_transfers.push(<?php echo e($chart['money_transfers'][$loop->index]->count); ?>);
                public_chart.trips.push(<?php echo e($chart['trips'][$loop->index]->count); ?>);
                public_chart.shipping_invoices.push(<?php echo e($chart['shipping_invoices'][$loop->index]->count); ?>);

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            


            var optionsLineChart = { /* config options for Line Charts */
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true,
                        },
                    }],
                    xAxes: [{
                        gridLines: {
                            display: false,
                        },
                    }],
                },
                legend: {
                    display: true,
                    position: 'top',
                    reverse: true,
                    labels: {
                        fontSize: 14,
                        padding: 15,
                        fontFamily: 'Tajawal'
                    }
                },
            };

        /*  End Data for line chart */



        /*  Start Financial Movement Charts     */

            /*  Start Financial Movement line Chart */
            var financialMovementLineChart = new Chart(document.getElementById('FinancialMovementLineChart'), {
                type: 'line',
                data: {
                    labels: months,
                    datasets: [{
                        data: financial_chart.purchase_orders,
                        backgroundColor: chart_labels.colors.purchase_orders,
                        borderColor: chart_labels.colors.purchase_orders,
                        borderWidth: 4,
                        fill: false,
                        label: chart_labels.names.purchase_orders,
                    }, {
                        data: financial_chart.money_transfers,
                        backgroundColor: chart_labels.colors.money_transfers,
                        borderColor: chart_labels.colors.money_transfers,
                        borderWidth: 4,
                        fill: false,
                        label: chart_labels.names.money_transfers,
                    }, {
                        data: financial_chart.trips,
                        backgroundColor: chart_labels.colors.trips,
                        borderColor: chart_labels.colors.trips,
                        borderWidth: 4,
                        fill: false,
                        label: chart_labels.names.trips,
                    }, {
                        data: financial_chart.shipping_invoices,
                        backgroundColor: chart_labels.colors.shipping_invoices,
                        borderColor: chart_labels.colors.shipping_invoices,
                        borderWidth: 4,
                        fill: false,
                        label: chart_labels.names.shipping_invoices,
                    }]
                },
                options: optionsLineChart,
            });
            /*  End Financial Movement line Chart */


            /*  Start Financial Movement Pie   */
            var FinancialMovementPieChart = new Chart(document.getElementById('FinancialMovementPieChart'), {
                type: 'doughnut',
                data: {
                    labels: Object.values(chart_labels.names),
                    datasets: [{
                        data: [ <?php echo e($sum->purchase_orders_sum); ?>, <?php echo e($sum->money_transfers_sum); ?>, <?php echo e($sum->trips_sum); ?>, <?php echo e($sum->shipping_invoices_sum); ?> ],
                        backgroundColor: Object.values(chart_labels.colors),
                    }],
                },
                options: {
                    responsive: true,
                    legend: {
                        display: false,
                    },
                    tooltips: {
                        enabled: true,
                    },
                    elements: {
                        center: {
                            text: '<?php echo e(number_format($sum->total_sum)); ?>',
                            color: '#6C757D', // Default is #000000
                            fontStyle: 'Arial', // Default is Arial
                            sidePadding: 10 // Defualt is 20 (as a percentage)
                        }
                    }
                },
            });
            /*  End Financial Movement Pie   */

        /*  End Financial Movement  Charts    */




        /*  Start Public Movement Charts     */

            /*  Start Public Movement line Chart */
            var PublicMovementLineChart = new Chart(document.getElementById('PublicMovementLineChart'), {
                type: 'line',
                data: {
                    labels: months,
                    datasets: [{
                        data: public_chart.purchase_orders,
                        backgroundColor: chart_labels.colors.purchase_orders,
                        borderColor: chart_labels.colors.purchase_orders,
                        borderWidth: 4,
                        fill: false,
                        label: chart_labels.names.purchase_orders,
                    }, {
                        data: public_chart.money_transfers,
                        backgroundColor: chart_labels.colors.money_transfers,
                        borderColor: chart_labels.colors.money_transfers,
                        borderWidth: 4,
                        fill: false,
                        label: chart_labels.names.money_transfers,
                    }, {
                        data: public_chart.trips,
                        backgroundColor: chart_labels.colors.trips,
                        borderColor: chart_labels.colors.trips,
                        borderWidth: 4,
                        fill: false,
                        label: chart_labels.names.trips,
                    }, {
                        data: public_chart.shipping_invoices,
                        backgroundColor: chart_labels.colors.shipping_invoices,
                        borderColor: chart_labels.colors.shipping_invoices,
                        borderWidth: 4,
                        fill: false,
                        label: chart_labels.names.shipping_invoices,
                    }]
                },
                options: optionsLineChart,
            });
            /*  End Public Movement line Chart */


            /*  Start Public Movement Pie   */
            var PublicMovementPieChart = new Chart(document.getElementById('PublicMovementPieChart'), {
                type: 'doughnut',
                data: {
                    labels: Object.values(chart_labels.names),
                    datasets: [{
                        data: [ <?php echo e($sum->purchase_orders_count); ?>, <?php echo e($sum->money_transfers_count); ?>, <?php echo e($sum->trips_count); ?>, <?php echo e($sum->shipping_invoices_count); ?> ],
                        backgroundColor: Object.values(chart_labels.colors),
                    }],
                },
                options: {
                    responsive: true,
                    legend: {
                        display: false,
                    },
                    tooltips: {
                        enabled: true,
                    },
                    elements: {
                        center: {
                            text: '<?php echo e(number_format($sum->total_count)); ?>',
                            color: '#6C757D', // Default is #000000
                            fontStyle: 'Arial', // Default is Arial
                            sidePadding: 10 // Defualt is 20 (as a percentage)
                        }
                    }
                },
            });
            /*  End Public Movement Pie   */

        /*  End Public Movement  Charts    */

    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/index.blade.php ENDPATH**/ ?>