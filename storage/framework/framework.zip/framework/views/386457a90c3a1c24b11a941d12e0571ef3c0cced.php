<?php $__env->startSection('content-without-style'); ?>




<div class="py-4 text-center bg-white">

    <a target="_blank" href="<?php echo e($customer->getImage()); ?>">
        <img src="<?php echo e($customer->getImageAvatar()); ?>" alt="image" class="avatar-customer mb-2">
    </a>
    <h3><bdi><?php echo e($customer->name); ?></bdi></h3>
    <div class="text-secondary d-flex align-items-center justify-content-center">
        <i class="fa fa-address-card ml-1 mr-3"></i>
        <bdi><?php echo e($customer->code); ?></bdi>
        <i class="fa fa-phone ml-1 mr-3"></i>
        <bdi><?php echo e($customer->phone); ?></bdi>
    </div>

</div>




<!--    Start menu or header tabs (navs)    -->
<div class="bg-light">
    <div class="container d-flex justify-content-between">
        <ul class="nav nav-tabs my-nav-tabs border-bottom-0 pr-0" role="tablist">
            <li class="nav-item">
                <a class="nav-link py-3 text-dark active" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="true">
                    <i class="fa fa-user-alt fa-sm ml-1"></i><span class="">الملف الشخصي</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link py-3 text-dark" id="shipping-invoices-tab" data-toggle="tab" href="#shipping" role="tab" aria-controls="shipping" aria-selected="false">
                    <i class="fa fa-shipping-fast fa-sm ml-1"></i><span class="">الشحنات</span>
                </a>
            </li>
            <?php if($customer->wallet): ?>
            <li class="nav-item">
                <a class="nav-link py-3 text-dark" id="shipping-invoices-tab" data-toggle="tab" href="#wallet" role="tab" aria-controls="shipping" aria-selected="false">
                    <i class="fa fa-shipping-fast fa-sm ml-1"></i><span class="">المحفظة</span>
                </a>
            </li>
            <?php endif; ?>
            <li class="nav-item">
                <a class="nav-link py-3 text-dark" id="purchase-orders-tab" data-toggle="tab" href="#purchase" role="tab" aria-controls="purchase" aria-selected="false">
                    <i class="fa fa-shopping-cart fa-sm ml-1"></i><span class="">فواتير الشراء</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link py-3 text-dark" id="logins-tab" data-toggle="tab" href="#logins" role="tab" aria-controls="logins" aria-selected="false">
                    <i class="far fa-clock fa-sm ml-1"></i><span class="">حركات الدخول</span>
                </a>
            </li>
        </ul>
        <div class="d-flex align-items-center">

            <?php if(hasRole('customers_edit')): ?>
                <button class="btn btn-primary btn-sm ml-1" data-toggle="modal" data-target="#editModal">
                    <i class="fas fa-pen"></i> تعديل
                </button>
            <?php endif; ?>



            <?php if(hasRole('merchant_from_customer')): ?>
            <button <?php if($customer->merchant_state == 1): ?>class="btn btn-danger btn-sm ml-1"
                 <?php else: ?> class="btn btn-primary btn-sm ml-1"
                  <?php endif; ?>
                   data-toggle="modal" data-target="#merchant">
                   <i class="fas"></i>
                   <?php if($customer->merchant_state == 1): ?> الغاء ميزة التاجر
                    <?php else: ?> اضافة ميزة التاجر
                     <?php endif; ?> </button>
        <?php endif; ?>




            <?php if($customer->state == 1): ?>

                <?php if(hasRole('customers_delete')): ?>
                    <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteModal">
                        <i class="far fa-trash-alt"></i> حذف
                    </button>
                <?php endif; ?>


            <?php else: ?>
                <?php if(hasRole('customers_edit')): ?>
                    <button class="btn btn-secondary btn-sm" data-toggle="modal" data-target="#editPasswordModal">
                        <i class="fas fa-lock"></i> تغير كلمة المرور
                    </button>
                <?php endif; ?>

            <?php endif; ?>

        </div>
    </div>
</div>
<!--    End menu or header tabs (navs)    -->


<!--    Start content tabs (navs)   -->
<div class="container my-5">


    <div class="tab-content">

        <!--    Start profile      -->
        <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">

            <div class="row my-5">

                <div class="col-lg-8">

                    <!--    Start about customer   -->
                    <div class="card border-0">
                        <div class="card-header bg-white py-3 d-flex justify-content-between" role="tab" id="headingProfile">
                            <h5 class="mb-0">
                                معلومات الشخصية
                            </h5>
                            <a data-toggle="collapse" class="text-dark" href="#collapseProfile" aria-expanded="true" aria-controls="collapseProfile">
                                <i class="fa fa-chevron-down"></i>
                            </a>
                        </div>

                        <div id="collapseProfile" class="collapse show" role="tabpanel" aria-labelledby="headingProfile">
                            <div class="card-body">
                                <div class="row text-right bg-white">
                                    <div class="col-sm-6 mb-3">
                                        <div class="row">
                                            <label class="col-auto w-150px">رقم العضوية</label>
                                            <div class="col text-secondary"><bdi><?php echo e($customer->code); ?></bdi></div>
                                        </div>
                                        <div class="border-b mb-1"></div>
                                    </div>
                                    <div class="col-sm-6 mb-3">
                                        <div class="row">
                                            <label class="col-auto w-150px">الاسم</label>
                                            <div class="col text-secondary"><?php echo e($customer->name); ?></div>
                                        </div>
                                        <div class="border-b mb-1"></div>
                                    </div>
                                    <div class="col-sm-6 mb-3">
                                        <div class="row">
                                            <label class="col-auto w-150px">رقم الهاتف</label>
                                            <bdi class="col text-secondary"><?php echo e($customer->phone); ?></bdi>
                                        </div>
                                        <div class="border-b mb-1"></div>
                                    </div>
                                    <div class="col-sm-6 mb-3">
                                        <div class="row">
                                            <label class="col-auto w-150px">البريد الإلكتروني</label>
                                            <div class="col text-secondary"><?php echo e($customer->email); ?></div>
                                        </div>
                                        <div class="border-b mb-1"></div>
                                    </div>

                                    <div class="col-sm-6 mb-3">
                                        <div class="row">
                                            <label class="col-auto w-150px">العنوان</label>
                                            <div class="col text-secondary"><?php echo e($customer->address); ?></div>
                                        </div>
                                        <div class="border-b mb-1"></div>
                                    </div>
                                    <div class="col-sm-6 mb-3">
                                        <div class="row">
                                            <label class="col-auto w-150px">استلام في</label>
                                            <div class="col text-secondary"><?php echo e($customer->recivePlace->name); ?></div>
                                        </div>
                                        <div class="border-b mb-1"></div>
                                    </div>
                                    <div class="col-sm-6 mb-3">
                                        <div class="row">
                                            <label class="col-auto w-150px">ملف التحقق</label>
                                            <div class="col text-secondary">
                                                <a target="_blank" href="<?php echo e($customer->getVerificationFile()); ?>">ملف إتبات الهوية</a>
                                            </div>
                                        </div>
                                        <div class="border-b mb-1"></div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="row">
                                            <label class="col-auto w-150px">معلومات أخرى</label>
                                            <div class="col text-secondary"><?php echo e($customer->extra); ?></div>
                                        </div>
                                        <div class="border-b mb-1"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--    End about customer   -->

                </div>

                <!--    Start info about account     -->
                <div class="col-lg-4 mt-3 mt-lg-0 text-right">
                    <div class="card border-0">
                        <div class="card-header bg-white py-3">
                            <h5 class="mb-0">معلومات الحساب</h5>
                        </div>
                        <div class="p-2">
                            <table class="table table-borderless">
                                <tbody>
                                    <tr>
                                        <td class="text-right">الحالة</td>
                                        <td>
                                            <span class='text-white px-2 py-1 label-state <?php echo e($customer->getStateColor()); ?>'><?php echo e($customer->getState()); ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-right">تاريخ الإنضمام</td>
                                        <td><bdi title="<?php echo e($customer->created_at->format('Y-m-d g:ia')); ?>"><?php echo e($customer->created_at->diffForHumans()); ?></bdi></td>
                                    </tr>
                                    <tr>
                                        <td class="text-right">تاريخ القبول</td>
                                        <td>
                                            <?php if($customer->activated_at): ?>
                                                <bdi title="<?php echo e($customer->activated_at->format('Y-m-d g:ia')); ?>"><?php echo e($customer->activated_at->diffForHumans()); ?></bdi>
                                            <?php else: ?>
                                                <bdi class="bg-secondary text-white px-2 py-1">لم يفعل بعد</bdi>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-right">أخر وصول</td>
                                        <td>
                                            <?php if($customer->last_access): ?>
                                                <bdi title="<?php echo e($customer->last_access->format('Y-m-d g:ia')); ?>"><?php echo e($customer->last_access->diffForHumans()); ?></bdi>
                                            <?php else: ?>
                                            <bdi class="bg-secondary text-white px-2 py-1">لم يدخل بعد</bdi> <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--    End info about account     -->

            </div>

        </div>
        <!--    End profile      -->

        <!--    Start shipping-invoices      -->
        <div class="tab-pane fade" id="shipping" role="tabpanel" aria-labelledby="shipping-tab">

            <div class="row">

                <!--     Start show invoices     -->
                <div class="col-lg-8">

                    <div class="card-header bg-white py-3 text-right">
                        <h5 class="mb-0">أخر (10) فواتير</h5>
                    </div>

                    <?php if($shippingInvoices): ?>

                        <!--    Start show invoices   -->
                        <div class="card-body px-1 pb-1 pt-0 bg-white">
                            <table class="table table-center table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">رقم الفاتورة</th>
                                        <th scope="col">رقم الرحلة</th>
                                        <th scope="col">رمز الشحنة</th>
                                        <th scope="col">تاريخ الإضافة</th>
                                        <th scope="col">إجمالي التكلفة</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <!-- Start print invoices -->
                                    <?php $__currentLoopData = $shippingInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                                            <td><a target="_blank" href="<?php echo e(url('cp/shipping-invoices',$invoice->id)); ?>"><?php echo e($invoice->id); ?></a></td>
                                            <td>
                                                <?php if($invoice->trip_id): ?>
                                                <a href="<?php echo e(url('cp/trips',$invoice->trip_id)); ?>"><?php echo e($invoice->trip_number()); ?></a>
                                                <?php else: ?>
                                                -----
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($invoice->shipment_code); ?></td>
                                            <td title="<?php echo e($invoice->created_at()); ?>">
                                                <bdi><?php echo e($invoice->created_at->diffForHumans()); ?></bdi>
                                            </td>
                                            <td><?php echo $invoice->total_cost(); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!-- End print invoices -->

                                </tbody>
                            </table>
                        </div>
                        <!--    End show invoices   -->

                    <?php else: ?>

                        <h1 class="text-center text-secondary py-5">لا توجد نتائج</h1>

                    <?php endif; ?>

                </div>
                <!--    End show invoices       -->


                <!--    Start info about shipping-invoices     -->
                <div class="col-lg-4 mt-3 mt-lg-0 text-right">
                    <div class="card border-0">
                        <div class="card-header bg-white py-3">
                            <h5 class="mb-0">إحصائيات الشحنات</h5>
                        </div>
                        <div class="p-2">
                            <table class="table table-borderless">
                                <tbody>
                                    <tr>
                                        <td class="text-right">تم الاستلام</td>
                                        <td><?php echo e($shipping_statistics->warehouse); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-right">بانتظار الشحن</td>
                                        <td><?php echo e($shipping_statistics->waitting_shipping); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-right">تم الشحن</td>
                                        <td><?php echo e($shipping_statistics->on_the_way); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-right">وصلت</td>
                                        <td><?php echo e($shipping_statistics->arrived); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-right">تم التسليم</td>
                                        <td><?php echo e($shipping_statistics->received); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-right w-150px">المعاملات المالية</td>
                                        <td class="font-weight-bold"><?php echo e(number_format($shipping_statistics->transactions)); ?> <?php echo e(app_settings()->currency->sign); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--    End info about shipping-invoices       -->

            </div>

        </div>
        <!--    End shipping-invoices      -->
        <?php if($customer->wallet): ?>
        <!--    Start wallet      -->
                <div class="tab-pane fade" id="wallet" role="tabpanel" aria-labelledby="shipping-tab">

                    <div class="row">

                        <!--     Start show invoices     -->
                        <div class="col-lg-8">

                            <div class="card-header bg-white py-3 text-right">
                                <h5 class="mb-0"> المحفظة</h5>
                            </div>


                                <!--    Start show invoices   -->
                                <div class="card-body px-1 pb-1 pt-0 bg-white">
                                    <table class="table table-center table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th scope="col">محفظة الزبون</th>
                                                <th scope="col">طرابلس LY</th>
                                                <th scope="col">طرابلس $ </th>
                                                <th scope="col">بنغازي LY</th>
                                                <th scope="col">بنغازي $</th>
                                                <th scope="col">مصراته LY</th>
                                                <th scope="col">مصراته $</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <!-- Start print invoices -->
                                                <tr>
                                                    <td style="background-color: white;"><a target="_blank" href="<?php echo e(url('cp/wallet/show',$customer->wallet->id)); ?>"><?php echo e($customer->code); ?></a></td>
                                                    <td style="background-color: white;"><?php echo e($customer->wallet->money_denar_t); ?></td>
                                                    <td style="background-color: white;"><?php echo e($customer->wallet->money_dolar_t); ?></td>
                                                    <td style="background-color: white;"><?php echo e($customer->wallet->money_denar_b); ?></td>
                                                    <td style="background-color: white;"><?php echo e($customer->wallet->money_dolar_b); ?></td>
                                                    <td style="background-color: white;"><?php echo e($customer->wallet->money_denar_m); ?></td>
                                                    <td style="background-color: white;"><?php echo e($customer->wallet->money_dolar_m); ?></td>
                                                </tr>
                                            <!-- End print invoices -->

                                        </tbody>
                                    </table>
                                </div>
                                <!--    End show invoices   -->
                        </div>
                        <!--    End show invoices       -->




                    </div>

                </div>
        <!--    End wallet      -->
        <?php endif; ?>

        <!--    Start Purchase-orders      -->
        <div class="tab-pane fade" id="purchase" role="tabpanel" aria-labelledby="purchase-tab">

            <div class="row">

                <!--     Start show Purchase-Orders     -->
                <div class="col-lg-8">

                    <div class="card-header bg-white py-3 text-right">
                        <h5 class="mb-0">أخر (10) طلبات</h5>
                    </div>

                    <?php if($orders): ?>

                        <!--    Start show Purchase-Orders   -->
                        <div class="card-body px-1 pb-1 pt-0 bg-white">
                            <table class="table table-center table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">رقم الطلب</th>
                                        <th scope="col">الحالة</th>
                                        <th scope="col">عمولة الشراء</th>
                                        <th scope="col">إجمالي التكلفة</th>
                                        <th scope="col">تاريخ الطلب</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <!-- Start print Purchase-Orders -->
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                                            <td><a target="_blank" href="<?php echo e(url('cp/purchase-orders',$order->id)); ?>"><?php echo e($order->id); ?></a></td>
                                            <td><?php echo e($order->getState()); ?></td>
                                            <td><?php echo e($order->getFee()); ?></td>
                                            <td><?php echo e($order->getTotalCostByCurrency()); ?></td>
                                            <td title="<?php echo e($order->created_at()); ?>">
                                                <bdi><?php echo e($order->created_at->diffForHumans()); ?></bdi>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!-- End print Purchase-Orders -->

                                </tbody>
                            </table>
                        </div>
                        <!--    End show Purchase-Orders   -->

                    <?php else: ?>

                        <h1 class="text-center text-secondary py-5">لا توجد نتائج</h1>

                    <?php endif; ?>

                </div>
                <!--    End show Purchase-Orders       -->


                <!--    Start info about Purchase-orders     -->
                <div class="col-lg-4 mt-3 mt-lg-0 text-right">
                    <div class="card border-0">
                        <div class="card-header bg-white py-3">
                            <h5 class="mb-0">إحصائيات طلبات الشراء</h5>
                        </div>
                        <div class="p-2">
                            <table class="table table-borderless">
                                <tbody>
                                    <tr>
                                        <td class="text-right">جديد</td>
                                        <td><?php echo e($orders_statistics->new); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-right">قيد المراجعة</td>
                                        <td><?php echo e($orders_statistics->review); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-right">مرفوض</td>
                                        <td><?php echo e($orders_statistics->rejected); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-right">بانتظار الدفع</td>
                                        <td><?php echo e($orders_statistics->waitting_pay); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-right">تم الدفع</td>
                                        <td><?php echo e($orders_statistics->paid); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-right">مكتمل</td>
                                        <td><?php echo e($orders_statistics->done); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-right w-150px">إجمالي العمولة</td>
                                        <td class="font-weight-bold"><?php echo e(number_format($orders_statistics->fee)); ?> <?php echo e(app_settings()->currency->sign); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-right w-150px">المعاملات المالية</td>
                                        <td class="font-weight-bold"><?php echo e(number_format($orders_statistics->total_cost)); ?> <?php echo e(app_settings()->currency->sign); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--    End info about Purchase-orders       -->

            </div>

        </div>
        <!--    End Purchase-orders      -->



        <!--    Start Logins      -->
        <div class="tab-pane fade" id="logins" role="tabpanel" aria-labelledby="logins-tab">

            <div class="card border-0 shadow mt-5">
                <div class="card-header text-right bg-white py-3">
                    <h5 class="mb-0">أخر حركات دخول</h5>
                </div>
                <div class="card-body pt-0 px-0">

                    <?php if(empty($customer->lastLogins)): ?>
                        <h1 class="text-center text-secondary py-5">لا توجد سجلات دخول</h1>
                    <?php else: ?>
                        <table class="table text-center table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">نظام التشغيل</th>
                                    <th scope="col">المتصفح</th>
                                    <th scope="col">البلد</th>
                                    <th scope="col">المدينة</th>
                                    <th scope="col">ip</th>
                                    <th scope="col">الدخول</th>
                                    <th scope="col">أخر وصول</th>
                                </tr>
                            </thead>
                            <tbody>

                                <!-- Start print logins -->
                                <?php $__currentLoopData = $customer->lastLogins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $login): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e(1+$loop->index); ?></th>
                                        <td><?php echo e($login->os); ?></td>
                                        <td><?php echo e($login->browser); ?></td>
                                        <td><?php echo e($login->country); ?></td>
                                        <td><?php echo e($login->city); ?></td>
                                        <td><?php echo e($login->ip); ?></td>
                                        <td class="dateTiemAgo" data-datetime="<?php echo e($login->log_in); ?>"><bdi><?php echo e($login->log_in->format('Y-m-d g:ia')); ?></bdi></td>
                                        <td class="dateTiemAgo" data-datetime="<?php echo e($login->log_out); ?>"><bdi><?php echo e($login->log_out->format('Y-m-d g:ia')); ?></bdi></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- End print logins -->

                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

        </div>
        <!--    End Logins      -->


    </div>

</div>
<!--    End content tabs (navs)   -->



<!--    Start Modal editModal -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">تعديل معلومات زبون</h5>
                <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class='formSendAjaxRequest was-validated' redirect-to="<?php echo e(Request::url()); ?>" refresh-seconds='2' upload-files='true' focus-on='#editModalLabel' action="<?php echo e(url('/cp/customers/edit')); ?>" enctype="multipart/form-data" method="post">
                <div class="modal-body px-5">

                    <div class="alert alert-warning text-right">
                        ملف التحقق اتركه فارغ إذا لاتريد تغيره
                    </div>
                    <div class="formResult text-center"></div>

                    <div class="row">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php echo e($customer->id); ?>" />
                        <div class="col-lg-6 text-center pb-2">
                            <div class="image-upload">
                                <label class="m-0 img-box avatar-customer">
                                    <img src="<?php echo e($customer->getImage()); ?>" default-img="<?php echo e($customer->getImage()); ?>" class="w-100 h-100 rounded-circle">
                                </label>
                                <input class="form-control img-input" type="file" name="img" accept=".png,.jpg,.jpeg,.gif">
                                <div class="invalid-feedback text-center"><?php echo app('translator')->get("validation.mimes",[ "attribute"=>"","values" => "png,jpg,jpeg,gif"]); ?></div>
                            </div>
                        </div>
                        <div class="col-md-6 pt-3">
                            <div class="form-group row">
                                <label for="inputName" class="col-auto w-150px col-form-label text-right">الاسم</label>
                                <div class="col pr-md-0">
                                    <input type="text" name="name" id="inputName" class="form-control" value="<?php echo e($customer->name); ?>" pattern="\s*([^\s]\s*){3,32}" required>
                                    <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'الاسم','min'=> 3 ,'max'=>32]); ?></div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="inputPhone" class="col-auto w-150px col-form-label text-right">رقم الهاتف</label>
                                <div class="col pr-md-0">
                                    <input type="text" name="phone" id="inputPhone" class="form-control text-right" dir='ltr' value="<?php echo e($customer->phone); ?>" pattern="\s*([0-9\-\+]\s*){3,14}" required>
                                    <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.digits_between',['attribute'=>'رقم الهاتف','min'=> 3 ,'max'=>14]); ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group row">
                                <label for="inputAddress" class="col-auto w-150px col-form-label text-right">العنوان</label>
                                <div class="col pr-md-0">
                                    <input type="text" name="address" id="inputAddress" class="form-control" value="<?php echo e($customer->address); ?>" pattern="\s*([^\s]\s*){3,64}" required>
                                    <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'العنوان','min'=> 3 ,'max'=>64]); ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group row">
                                <label for="inputReceiveIn" class="col-auto w-150px col-form-label text-right">استلام في</label>
                                <div class="col pr-md-0">
                                    <select id="inputReceiveIn" class="form-control setValue" value="<?php echo e($customer->receive_in); ?>" name="receive_in" required>
                                        <?php $__currentLoopData = $receivingPlaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($place->id); ?>"><?php echo e($place->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.required',['attribute'=>'المكان']); ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group row">
                                <label for="inputEmail" class="col-auto w-150px col-form-label text-right">البريد الإلكتروني</label>
                                <div class="col pr-md-0">
                                    <input id="inputEmail" type="email" class="form-control" value="<?php echo e($customer->email); ?>" name="email" required>
                                    <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.required',['attribute'=>'البريد الإلكتروني']); ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group row">
                                <label for="inputState" class="col-auto w-150px col-form-label text-right">الحالة</label>
                                <div class="col pr-md-0">
                                    <select id="inputState" name="state" class="form-control setValue" value="<?php echo e($customer->state == 1 ? 2 : $customer->state); ?>" required>
                                            <option value="3">تفعيل</option>
                                            <option value="2">إيقاف</option>
                                        </select>
                                    <div class="invalid-feedback text-center">يجب تحديد الحالة</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group row">
                                <label class="col-auto w-150px col-form-label text-right">ملف التحقق</label>
                                <div class="col pr-md-0">
                                    <div class="custom-file">
                                        <input type="file" name="verification_file" class="custom-file-input" id="customFileInput" accept=".jpeg, .png, .jpg, .gif, .pdf">
                                        <label class="custom-file-label" for="customFileInput">اختر ملف</label>
                                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.mimes',[ 'attribute'=>'ملف التحقق','values' => 'jpeg,png,jpg,gif,pdf']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group row">
                                <label for="inputExtra" class="col-auto w-150px col-form-label text-right">أخرى</label>
                                <div class="col pr-md-0">
                                    <textarea name="extra" id="inputExtra" maxlength="500" rows="4" class="form-control"><?php echo e($customer->extra); ?></textarea>
                                    <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.max.string',['attribute'=>'معلومات أخرى','max'=>500]); ?></div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">تحديث</button>
                    <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!--    End Modal editModal -->

<?php if(hasRole('merchant_from_customer')): ?>
<!--Start Modal Merchant MODAL -->
        <div class="modal fade" id="merchant" tabindex="-1" role="dialog" aria-labelledby="merchantModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <?php if($customer->merchant_state==0): ?>
                        <h5 class="modal-title" id="deleteModalLabel">اضافة ميزة التاجر للزبون</h5>
                        <?php else: ?>
                        <h5 class="modal-title" id="deleteModalLabel">الغاء ميزة التاجر للزبون</h5>
                        <?php endif; ?>
                        <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <form class='formSendAjaxRequest'  refresh-seconds='2' action="<?php echo e(url('/cp/addMerchant')); ?>"
                        method="post">
                        <div class="modal-body text-right">
                            <div class="formResult text-center"></div>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($customer->id); ?>" />
                            <?php if($customer->merchant_state==0): ?>
                            هل أنت متأكد أنك تريد اضافة الميزة لهدا الزبون  ؟
                            <?php else: ?>
                            هل أنت متأكد أنك تريد الغاء الميزة لهدا الزبون  ؟
                            <?php endif; ?>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger">تحديث</button>
                            <button type="button" class="btn btn-secondary mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
<!--    End Modal Merchant MODAL -->
<?php endif; ?>


<?php if($customer->state == 1): ?>

    <?php if(hasRole('customers_delete')): ?>
        <!--    Start Modal deleteModal -->
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">حذف زبون</h5>
                        <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <form class='formSendAjaxRequest' redirect-to='<?php echo e(url('/cp/customers')); ?>' refresh-seconds='2' action="<?php echo e(url('/cp/customers')); ?>"
                        method="post">
                        <div class="modal-body text-right">
                            <div class="formResult text-center"></div>
                            <?php echo method_field('DELETE'); ?>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($customer->id); ?>" />
                            هل أنت متأكد أنك تريد حذف الزبون ؟
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger">حذف</button>
                            <button type="button" class="btn btn-secondary mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--    End Modal deleteModal -->
    <?php endif; ?>

<?php else: ?>


    <?php if(hasRole('customers_edit')): ?>
        <!--    Start Modal editPasswordModal -->
        <div class="modal fade" id="editPasswordModal" tabindex="-1" role="dialog" aria-labelledby="editPasswordModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editPasswordModalLabel">تغير كلمة المرور</h5>
                        <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form class='formSendAjaxRequest was-validated' action="<?php echo e(url('/cp/customers/edit/password')); ?>" method="post">
                        <div class="modal-body">
                            <div class="formResult text-center"></div>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($customer->id); ?>" />

                            <div class="form-group row">
                                <label for="inputPassword" class="col-md-4 col-form-label text-right">كلمة المرور الجديدة</label>
                                <div class="col-md-7 pr-md-0">
                                    <input id="inputPassword" type="password" minlength="6" maxlength="32" class="form-control" name="password" placeholder="كلمة المرور الجديدة" required>
                                    <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'كلمة المرور','min'=> 6 ,'max'=>32]); ?></div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="inputPasswordConfirmation" class="col-md-4 col-form-label text-right">تأكيد كلمة المرور</label>
                                <div class="col-md-7 pr-md-0">
                                    <input id="inputPasswordConfirmation" type="password" minlength="6" maxlength="32" class="form-control" placeholder="تأكيد كلمة المرور الجديدة" name="password_confirmation"
                                        required>
                                    <div class="invalid-feedback text-center">يجب أن تكون كلمات المرور متساوية</div>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">تحديث</button>
                            <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--    End Modal editPasswordModal -->
    <?php endif; ?>

<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/customers/show.blade.php ENDPATH**/ ?>