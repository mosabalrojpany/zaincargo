<?php $__env->startSection('content'); ?>


    
    <div class="d-flex justify-content-between align-items-center">
        <h4 class="font-weight-bold mb-0">الحوالات المالية <?php echo e($transfers->total()); ?></h4>
        <a class="btn btn-primary w-100px" href="<?php echo e(url('client/money-transfers/create')); ?>">
            <i class="fas fa-plus mx-1"></i>أضف
        </a>
    </div>
    



    
    <div class="card card-shadow my-4 text-center">

        <!-- Start search  -->
        <div class="card-header bg-primary text-white"> 
            <form class="row justify-content-between" action="<?php echo e(Request::url()); ?>" method="get">
                
                <input type="hidden" name="search" value="1">

                <div class="form-inline col-auto d-none d-lg-flex">
                    <div class="form-group">
                        <label for="inputShowSearch">عرض</label>
                        <input type="number" id="inputShowSearch" name="show" min="10" max="500" class="form-control mx-sm-2" value="<?php echo e(Request::has('show') ? Request::get('show') : 25); ?>" />
                    </div>
                </div>

                <div class="form-inline">
                    <span class="mx-2"><i class="fa fa-filter"></i></span>
                    <div class="form-group mb-0">
                        <label class="d-none" for="inputTransferIdSearch">رقم الحوالة</label>
                        <input type="number" min="1" name="id" value="<?php echo e(Request::get('id')); ?>" placeholder="رقم الحوالة" id="inputTransferIdSearch" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group d-none d-sm-flex">
                        <label class="d-none" for="inputStateSearch">الحالة</label>
                        <select id="inputStateSearch" class="form-control mx-sm-2 setValue" style="min-width: 180px;" name="state" value="<?php echo e(Request::get('state')); ?>">
                            <option value="">كل الحالات</option>
                            <?php $__currentLoopData = trans('moneyTransfer.status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                </div>

            </form>  
        </div>
        <!-- End search  -->

        <!--    Start show Transfers   -->
        <div class="card-body p-0">
            <table class="table table-center table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col" class="d-none d-md-table-cell">#</th>
                        <th scope="col" class="no-wrap">رقم الحوالة</th>
                        <th scope="col" class="d-none d-lg-table-cell">اسم المستلم</th>
                        <th scope="col" class="d-none d-sm-table-cell">الحالة</th>
                        <th scope="col">المبلغ</th>
                        <th scope="col" class="d-none d-sm-table-cell">تاريخ الطلب</th>
                    </tr>
                </thead>
                <tbody>

                    <!-- Start print Transfers -->
                    <?php $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row" class="d-none d-md-table-cell"><?php echo e($loop->iteration); ?></th>
                            <td>
                                <a href="<?php echo e(url('client/money-transfers',$transfer->id)); ?>"><?php echo e($transfer->id); ?></a>
                            </td> 
                            <td class="d-none d-lg-table-cell"><bdi><?php echo e($transfer->recipient); ?></bdi></td> 
                            <td class="no-wrap d-none d-sm-table-cell"><?php echo e($transfer->getState()); ?></td> 
                            <td class="no-wrap"><b><?php echo e($transfer->amount.$transfer->currency->sign); ?></b></td> 
                            <td class="d-none d-sm-table-cell"><bdi><?php echo e($transfer->created_at()); ?></bdi></td> 
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- End print Transfers -->

                </tbody>
            </table>
        </div>
        <!--    End show Transfers   -->

    </div>
    



    
    <div class="pagination-center"><?php echo e($transfers->links()); ?></div>  



<?php $__env->stopSection(); ?>
<?php echo $__env->make('Client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/Client/money_transfers/index.blade.php ENDPATH**/ ?>