<?php $__env->startSection('content'); ?>


<!--  Start path  -->
<div class="d-flex align-items-center justify-content-between mb-3">

    <nav aria-label="breadcrumb" role="navigation">
        <ol class="breadcrumb mb-0" style="background-color: transparent">
            <li class="breadcrumb-item"> 
                <h4 class="mb-0">
                    <a class="text-decoration-none" href="<?php echo e(url('client/purchase-orders')); ?>">طلبات الشراء</a> 
                </h4> 
            </li>
            <li class="breadcrumb-item active text-truncate col pr-0 text-right" aria-current="page">
                <h4 class="mr-1 mb-0 d-inline-block"><?php echo e($order->id); ?></h4>
            </li>
        </ol>
    </nav>
    
</div>
<!--  End path  -->



<!--    Start header of Order   -->
<form class="formSendAjaxRequest card card-shadow was-validated" id="form-order" focus-on="#form-order"
     refresh-seconds="1" action="<?php echo e(url('client/purchase-orders/edit')); ?>" method="POST">

    <?php echo csrf_field(); ?>

    <input type="hidden" name="id" value="<?php echo e($order->id); ?>" />

    
    <div class="card-header bg-white">
        
        <div class="formResult my-3 text-center"></div>

        <div class="row"> 

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label class="col-auto w-125px col-form-label text-right">رقم الطلب</label>
                    <div class="col pr-md-0">
                        <input type="text" value="<?php echo e($order->id); ?>" class="form-control" readonly>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label class="col-auto w-125px col-form-label text-right">الحالة</label>
                    <div class="col pr-md-0">
                        <input type="text" value="<?php echo e($order->getState()); ?>" class="form-control" readonly>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label class="col-auto w-125px col-form-label text-right">تاريخ الطلب</label>
                    <div class="col pr-md-0">
                        <input type="text" value="<?php echo e($order->created_at()); ?>" dir="ltr" class="form-control text-right" readonly>
                    </div>
                </div>
            </div>

        </div>

    </div>
    


    
    <div class="card-body px-0"> 

        <table class="table table-striped text-center">
            <thead>
                <tr>
                    <th>#</th>
                    <th>الوصف</th>
                    <th>الرابط</th>
                    <th class="w-150px">العدد</th>
                    <th class="w-150px">اللون</th>
                    <th>خيارات</th>
                </tr>
            </thead>
            <tbody>

                

            </tbody>
        </table>

    </div>
    

    
    
    <!--    Start footer    -->
    <div class="card-footer d-flex align-items-center justify-content-between">
        <div class="form-group mb-0 pr-5">
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="customControlIamSure" required>
                <label class="custom-control-label" for="customControlIamSure">أنا متأكد</label>
            </div>
        </div> 
        <button type="submit" class="btn btn-primary w-125px">حفظ</button>
    </div>
    <!--    End footer    -->


</form>
<!--    End header of Order   -->



<?php $__env->stopSection(); ?>



<?php $__env->startSection('extra-js'); ?>

    <?php echo $__env->make('Client.purchase_orders.create-edit-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script> 

        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            addRowInput(
                "<?php echo e($item->link); ?>",
                "<?php echo e($item->count); ?>",
                "<?php echo e($item->color); ?>",
                <?php echo json_encode($item->desc); ?>,
                "<?php echo e($item->id); ?>"
            );
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        $(form).on('change', 'input:not([type=hidden]) , textarea', function () {
            var tr = $(this).closest('tr');
            var state = $(tr).find('[name="items[row_state][]"]');
            if (state.val() === 'default') {
                
                $(state).val('updated');
            }
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/Client/purchase_orders/edit.blade.php ENDPATH**/ ?>