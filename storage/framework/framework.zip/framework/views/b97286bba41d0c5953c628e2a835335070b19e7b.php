<?php $__env->startSection('content'); ?>



    <!--  breadcrumb area start  -->
    <div class="breadcrumb-area blog-breadcrumb-bg home-3">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="breadcrumb-txt">
                        <span>أخبارنا</span>
                        <h1>ما أخر أخبارنا ؟</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">الرئيسية</a></li>
                                <li class="breadcrumb-item active" aria-current="page">أخبارنا</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="breadcrumb-overlay"></div>
    </div>
    <!--  breadcrumb area end  -->



    
    <!--    blog lists start   -->
    <div class="news-section blog-grid-sidebar">
        <div class="container">
            <div class="row">
            
                <div class="col-xl-7 offset-xl-1 col-lg-8">
                    <div class="row">

                        <?php if(Request::get('tag')): ?>

                            <div class="col-lg-12">
                                <span class="title">الأخبار</span>
                                <h2 class="subtitle"><?php echo e(Request::get('tag')); ?></h2>
                            </div>

                        <?php elseif(Request::get('search')): ?>

                            <div class="col-lg-12">
                                <span class="title">الأخبار</span>
                                <h2 class="subtitle">نتائج البحث "<?php echo e(Request::get('search')); ?>"</h2>
                            </div>

                        <?php endif; ?>


                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 mb-3">
                                <div class="single-news wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="<?php echo e($loop->iteration * .1); ?>s">
                                    
                                    <img src="<?php echo e($post->getImageAvatar()); ?>" alt="<?php echo e($post->title); ?>">
                                    
                                    <div class="news-txt">
                                        
                                        <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(url("news?tag=$tag->name")); ?>" class="tag ml-1">
                                                <i class="fa fa-tag" style="vertical-align: middle"></i>
                                                <?php echo e($tag->name); ?>

                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        |
                                        <span class="date mr-1">
                                            <i class="far fa-clock" style="vertical-align: middle"></i>
                                            <bdi><?php echo e($post->getDate()); ?></bdi>
                                        </span>

                                        <a href="<?php echo e(url('news',$post->id)); ?>" class="title">
                                            <h3><?php echo e($post->title); ?></h3>
                                        </a>
                                        
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    
                    <div class="row">
                        <div class="col-lg-12">
                            <?php echo e($posts->links('vendor.pagination.main-pages')); ?>

                        </div>
                    </div>
                
                </div>

                <!--    blog sidebar section start   -->
                <div class="col-lg-4">
                    <?php echo $__env->make('main.posts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <!--    blog sidebar section end   -->
            
            </div>
        </div>
    </div>
    <!--    blog lists end   -->
    
    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/main/posts/index.blade.php ENDPATH**/ ?>