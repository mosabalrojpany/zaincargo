<?php $__env->startSection('content'); ?>


<!--  Start path  -->
<div class="d-flex align-items-center justify-content-between mb-3">

    <nav aria-label="breadcrumb" role="navigation">
        <ol class="breadcrumb mb-0" style="background-color: transparent">
            <li class="breadcrumb-item"> 
                <h4 class="mb-0">
                    <a class="text-decoration-none" href="<?php echo e(url('client/purchase-orders')); ?>">طلبات الشراء</a> 
                </h4> 
            </li>
            <li class="breadcrumb-item active text-truncate col pr-0 text-right" aria-current="page">
                <h4 class="mr-1 mb-0 d-inline-block">طلب جديد</h4>
            </li>
        </ol>
    </nav>
    
</div>
<!--  End path  -->


<!--    Start header of Order   -->
<form class="formSendAjaxRequest card card-shadow was-validated" id="form-order" focus-on="#form-order"
     refresh-seconds="1" msgClasses="my-3" action="<?php echo e(url('client/purchase-orders')); ?>" method="POST">

    <?php echo csrf_field(); ?>

    <div class="card-header bg-primary text-white rounded-top">
        <h5 class="text-center my-1">محتويات الطلب</h5>
    </div>
    
    <div class="formResult text-center"></div>

    
    <div class="card-body p-0"> 

        <table class="table text-center">
            <thead>
                <tr>
                    <th>#</th>
                    <th>الوصف</th>
                    <th>الرابط</th>
                    <th class="w-150px">العدد</th>
                    <th class="w-150px">اللون</th>
                    <th>خيارات</th>
                </tr>
            </thead>
            <tbody>

                

            </tbody>
        </table>
    
    </div>
        
    

    <!--    Start footer    -->
    <div class="card-footer d-flex align-items-center justify-content-between">
        <div class="form-group mb-0 pr-5">
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="customControlIamSure" required>
                <label class="custom-control-label" for="customControlIamSure">أنا متأكد</label>
            </div>
        </div> 
        <button type="submit" class="btn btn-primary w-125px">حفظ</button>
    </div>
    <!--    End footer    -->


</form>
<!--    End header of Order   -->



<?php $__env->stopSection(); ?>



<?php $__env->startSection('extra-js'); ?>

    <?php echo $__env->make('Client.purchase_orders.create-edit-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script> 

            
            addRowInputEmptyWithStatusAdded();

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/Client/purchase_orders/create.blade.php ENDPATH**/ ?>