<?php echo e($slot); ?>

<?php /**PATH /home3/eletroli/projects/shipping_company/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>