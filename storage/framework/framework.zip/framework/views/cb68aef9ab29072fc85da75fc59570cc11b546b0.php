<?php $__env->startSection('content'); ?>



<!--    Start header    -->
<div class="d-flex justify-content-between">
    <h4 class="font-weight-bold">المستخدمين <?php echo e(count($users)); ?></h4>
    <button class="btn btn-primary w-100px btnAdd" data-toggle="modal" data-active="0" data-target="#Modal">
        <i class="fas fa-plus mx-1"></i>أضف
    </button>
</div>
<!--    End header    -->





<div class="card card-shadow my-4 text-center">

    <!-- Start search  -->
    <div class="card-header bg-primary text-white">
        <form class="justify-content-between" action="<?php echo e(Request::url()); ?>" method="get">
            <input type="hidden" name="search" value="1">

            <div class="form-inline">
                <span class="ml-2"><i class="fa fa-filter"></i></span>
                    <div class="form-group">
                        <label class="d-none" for="inputNameSearch">الاسم</label>
                        <input type="search" maxlength="32" name="name" value="<?php echo e(Request::get('name')); ?>" placeholder="الاسم" id="inputNameSearch" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group">
                        <label class="d-none" for="inputUserNameSearch">اسم المستخدم</label>
                        <input type="search" maxlength="32" name="username" value="<?php echo e(Request::get('username')); ?>" placeholder="اسم المستخدم" id="inputUserNameSearch" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group">
                        <label class="d-none" for="inputPhoneSearch">رقم الهاتف</label>
                        <input type="search" maxlength="32" name="phone" value="<?php echo e(Request::get('phone')); ?>" placeholder="رقم الهاتف" id="inputPhoneSearch" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group">
                        <label class="d-none" for="inputRoleSearch">الدور</label>
                        <select id="inputRoleSearch" class="form-control mx-sm-2 setValue" style="width: 200px;" name="role" value="<?php echo e(Request::get('role')); ?>">
                           
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="d-none" for="inputStateSearch">الحالة</label>
                        <select id="inputStateSearch" class="form-control mx-sm-2 setValue" style="width: 200px;" name="state" value="<?php echo e(Request::get('state')); ?>">
                            <option value="">كل الحالات</option>
                            <option value="0">غير فعال</option>
                            <option value="1">فعال</option>
                        </select>
                    </div>
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
            </div>

        </form>
    </div>
        <!-- End search  -->




    <!--    Start show users   -->
    <div class="card-body p-0">

        <table class="table table-striped text-center">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">الاسم</th>
                    <th scope="col">اسم المستخدم</th>
                    <th scope="col">رقم الهاتف</th>
                    <th scope="col">الدور</th>
                    <th scope="col">الفرع</th>
                    <th scope="col">أضيفه في</th>
                    <th scope="col">أخر وصول</th>
                    <th scope="col">تعديل</th>
                </tr>
            </thead>
            <tbody>

                <!-- Start print users -->
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id='<?php echo e($user->id); ?>' data-active='<?php echo e($user->active); ?>' data-role='<?php echo e($user->role_id); ?>' data-branches='<?php echo e($user->branches_id); ?>'
                        class="<?= ($user->active)? '':'table-danger' ?>">
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td data="name"><?php echo e($user->name); ?></td>
                        <td data="username"><?php echo e($user->username); ?></td>
                        <td data="phone"><?php echo e($user->phone); ?></td>
                        <td><?php echo e($user->role->name); ?></td>
                        <td><?php echo e($user->getBranchCity()); ?></td>
                        <td><bdi><?php echo e($user->created_at->format('Y-m-d g:ia')); ?></bdi></td>
                        <td>
                            <?php if($user->last_access): ?>
                                <bdi><?php echo e($user->last_access->format('Y-m-d g:ia')); ?></bdi>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button type="button" class="btn btn-primary btn-sm btnEdit" data-toggle="modal" data-target="#Modal">
                                <i class="fas fa-pen"></i>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- End print users -->

            </tbody>
        </table>

    </div>
    <!--    End show users   -->


</div>




<!--    Start Modal Modal -->
<div class="modal fade" id="Modal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ModalLabel">تعديل معلومات مستخدم</h5>
                <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class='formSendAjaxRequest was-validated' refresh-seconds='2' action="<?php echo e(url('/cp/users/edit')); ?>" method="post">
                <div class="modal-body px-sm-5">
                    <div class="alert alert-warning text-right" id="alertMsgPassword">لاتكتب كلمة المرور إذا لا تريد تغيرها</div>
                    <div class="formResult text-center"></div>
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="id" />
                    <div class="form-group row">
                        <label for="inputName" class="col-sm-auto w-125px col-form-label text-right">الاسم</label>
                        <div class="col-sm">
                            <input type="text" name="name" class="form-control" id="inputName" placeholder="الاسم" pattern=".{3,32}" required>
                            <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',[ 'attribute'=>'الاسم','min'=> 3,'max'=>32]); ?></div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPhone" class="col-sm-auto w-125px pl-0 col-form-label text-right">رقم الهاتف</label>
                        <div class="col-sm">
                            <input type="text" name="phone" class="form-control" id="inputPhone" placeholder="رقم الهاتف" pattern=".{3,14}" required>
                            <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.digits_between',[ 'attribute'=>'رقم الهاتف','min'=> 3,'max'=>14]); ?></div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputUsername" class="col-sm-auto w-125px pl-0 col-form-label text-right">اسم المستخدم</label>
                        <div class="col-sm">
                            <input type="text" name="username" class="form-control" id="inputUsername" placeholder="اسم المستخدم" pattern=".{3,32}" required>
                            <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',[ 'attribute'=>'اسم المستخدم','min'=> 3,'max'=>32]); ?></div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword" class="col-sm-auto w-125px pl-0 col-form-label text-right">كلمة المرور</label>
                        <div class="col-sm">
                            <input type="text" name="password" class="form-control" id="inputPassword" placeholder="كلمة المرور" pattern=".{6,32}" >
                            <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',[ 'attribute'=>'كلمة المرور','min'=> 6,'max'=>32]); ?></div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputRole" class="col-sm-auto w-125px col-form-label text-right">الفرع</label>
                        <div class="col-sm">
                            <select id="inputbranch" name="branches" class="form-control" required>
                                <option value="" selected>اختر...</option>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branches): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($branches->id); ?>"><?php echo e($branches->city); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputRole" class="col-sm-auto w-125px col-form-label text-right">الدور</label>
                        <div class="col-sm">
                            <select id="inputRole" name="role" class="form-control" required>
                                <option value="" selected>اختر...</option>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputActive" class="col-sm-auto w-125px col-form-label text-right">الحالة</label>
                        <div class="col-sm">
                            <select id="inputActive" name="active" class="form-control" required>
                                <option value="1">تفعيل</option>
                                <option value="0">عدم التفعيل</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">تحديث</button>
                    <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!--    End Modal Modal -->



<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra-js'); ?>
    <script>

            /*  */
            var inputRoleSearch = $('#inputRoleSearch');
            $(inputRoleSearch).html($('#inputRole').html());
            $(inputRoleSearch).val($(inputRoleSearch).attr('value'));
            $(inputRoleSearch).find('option[value=""]').html('كل الأدوار');


            var addAction = "<?php echo e(url('/cp/users')); ?>";
            var editAction = "<?php echo e(url('/cp/users/edit')); ?>";
            var form = $('#Modal form')[0];

            $('.btnAdd').click(function() {
                form.reset();
                $(form).attr('action',addAction);
                $('#ModalLabel').html('إضافة مستخدم');
                $(form).find('.formResult').html('');
                $(form).find('#alertMsgPassword').hide();
                $(form).find('input[name="id"]').val('');
                $(form).find('input[name="password"]').prop('required',true);
            });


            $('.btnEdit').click(function() {
                var tr = $(this).closest('tr');
                $(form).attr('action',editAction);
                $('#ModalLabel').html('تعديل معلومات مستخدم');
                $(form).find('.formResult').html('');
                $(form).find('#alertMsgPassword').show();
                $(form).find('input[name="password"]').prop('required',false);
                $(form).find('input[name="id"]').val(tr.attr('id'));
                $(form).find('input[name="name"]').val(tr.find('td[data="name"]').html());
                $(form).find('input[name="phone"]').val(tr.find('td[data="phone"]').html());
                $(form).find('input[name="username"]').val(tr.find('td[data="username"]').html());
                $(form).find('select[name="branches"]').val(tr.data('branches'));
                $(form).find('select[name="role"]').val(tr.data('role'));
                $(form).find('select[name="active"]').val(tr.data('active'));
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/users.blade.php ENDPATH**/ ?>