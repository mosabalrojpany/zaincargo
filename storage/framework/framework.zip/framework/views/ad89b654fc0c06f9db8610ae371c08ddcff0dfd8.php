<script>


        var form = $('#form-order');
        var stateIsRequired;/* to use it to know if some fields is required or must be hidden */

        /******** Start helper functions ********/

            /**
            *  Add item to list with input fildes to form(form for purchase order)
            * @param  link {string} link value
            * @param  count {integer} count value
            * @param  color {string} color value
            * @param  price {decimal|float} price value
            * @param  tax {decimal|float} tax value
            * @param  shipping {decimal|float} shipping value
            * @param  state {integer} state value
            * @param  desc {string} desc value
            * @param  note {string} note value
            * @param  id {integer} id value
            * @param  row_state {string} state of row , must be (added|updated|default)
            */
            function addItemInput(link = '', count = '', color = '', price = '', tax = '', shipping = '', state = '', desc = '', note = '', id = '', row_state = 'default') {

                row_num = getItemsCount(form) + 1;

                $(form).find('.orders-list').append(
                    '<li class="p-3" item-accepted="'+( state == 1 ? '1' : '0')+'">'
                    +'    <div class="row">'
                    + ((id) ? '<input type="hidden" name="items[id][]" value="' + id + '" />' : '')
                    + '    <input type="hidden" name="items[row_state][]" value="' + row_state + '" />'
                    +'        <b class="col-auto item-order">' + row_num + '</b>'
                    +'        <div class="col">'
                    +'            <div class="row">'
                    +'                <div class="col-4"> '
                    +'                    <div class="form-group">'
                    +'                        <label  class="col-form-label text-right">الرابط</label>'
                    +'                        <input type="url" value="' + link + '" class="form-control" name="items[link][]" placeholder="https://www.example.com/item" required>'
                    +'                        <div class="invalid-feedback text-center"><?php echo app('translator')->get("validation.url",["attribute"=>""]); ?></div>' 
                    +'                    </div>'
                    +'                </div>'
                    +'                <div class="col-4"> '
                    +'                    <div class="form-group">'
                    +'                        <label class="col-form-label text-right">العدد</label>'
                    +'                        <input type="number" min="1" value="' + count + '" name="items[count][]" class="form-control" required>'
                    +'                        <div class="invalid-feedback text-center"><?php echo app('translator')->get("validation.min.numeric",["attribute"=>"العدد","min"=> 1]); ?></div>'  
                    +'                    </div>'
                    +'                </div>'
                    +'                <div class="col-4"> '
                    +'                    <div class="form-group">'
                    +'                        <label class="col-form-label text-right">اللون</label>'
                    +'                        <input type="color" value="' + color + '" class="form-control" name="items[color][]" required>'
                    +'                    </div>'
                    +'                </div>'
                    +'                <div class="col-sm-6 col-lg-3">'
                    +'                    <div class="form-group">'
                    +'                        <label class="col-form-label text-right">السعر</label>'
                    +'                        <input type="number" min="0" step="any" value="' + price + '" name="items[price][]" class="form-control order-items-price" required>'
                    +'                        <div class="invalid-feedback text-center"><?php echo app('translator')->get("validation.min.numeric",["attribute"=>"السعر","min"=> 0]); ?></div>'  
                    +'                    </div>'
                    +'                </div>'
                    +'                <div class="col-sm-6 col-lg-3">'
                    +'                    <div class="form-group">'
                    +'                        <label class="col-form-label text-right">الضريبة</label>'
                    +'                        <input type="number" min="0" step="any" value="' + tax + '" name="items[tax][]" class="form-control order-items-tax" required>'
                    +'                        <div class="invalid-feedback text-center"><?php echo app('translator')->get("validation.min.numeric",["attribute"=>"الضريبة","min"=> 0]); ?></div>'   
                    +'                    </div>'
                    +'                </div>'
                    +'                <div class="col-sm-6 col-lg-3">'
                    +'                    <div class="form-group">'
                    +'                        <label class="col-form-label text-right">الشحن الداخلي</label>'
                    +'                        <input type="number" min="0" step="any" value="' + shipping + '" name="items[shipping][]" class="form-control order-items-shipping" required>'
                    +'                        <div class="invalid-feedback text-center"><?php echo app('translator')->get("validation.min.numeric",["attribute"=>"الشحن الداخلي","min"=> 0]); ?></div>' 
                    +'                    </div>'
                    +'                </div>'
                    +'                <div class="col-sm-6 col-lg-3">'
                    +'                    <div class="form-group">'
                    +'                        <label class="col-form-label text-right">الحالة</label>'
                    +'                        <select name="items[state][]" value="' + state + '" class="form-control order-items-state setValue" required>'
                    +'                            <option value="" selected>...</option>'
                                                    <?php $__currentLoopData = trans('purchaseOrdersStatus.purchase_order_items_status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    +'                                    <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>' 
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    +'                        </select>'
                    +'                    </div>'
                    +'                </div>'
                    +'                <div class="col-md-6"> '
                    +'                    <div class="form-group">'
                    +'                        <label class="col-form-label text-right">وصف</label>'
                    +'                        <textarea name="items[desc][]" minlength="3" maxlength="150" rows="2" class="form-control" placeholder="وصف المنتج" required>' + desc + '</textarea>'
                    +'                        <div class="invalid-feedback text-center"><?php echo app('translator')->get("validation.between.string",["attribute"=>"الوصف","min"=> 3 ,"max"=>150]); ?></div>'   
                    +'                    </div>'
                    +'                </div>'
                    +'                <div class="col-md-6"> '
                    +'                    <div class="form-group">'
                    +'                        <label class="col-form-label text-right">ملاحظة</label>'
                    +'                        <textarea name="items[note][]" maxlength="150" rows="2" class="form-control" placeholder="ملاحظة لزبون">' + note + '</textarea>'
                    +'                        <div class="invalid-feedback text-center"><?php echo app('translator')->get("validation.max.string",["attribute"=>"ملاحظة","max"=>150]); ?></div>' 
                    +'                    </div>'
                    +'                </div>'
                    +'            </div>'
                    +'        </div>'
                    +'        <div class="col-auto item-control-buttons">'
                    +'            <button type="button" class="btn btn-danger btn-sm btnDeleteItem ml-1"><i class="fa fa-trash"></i></button>'
                    +'            <button type="button" class="btn btn-primary btn-sm btnAddItem"><i class="fa fa-plus"></i></button>'
                    +'        </div>'
                    +'    </div>'
                    +'</li>'
                );

                if (state) {
                    /* if user set state , so set selected value */
                    var inputSelect = $(form).find('.orders-list li:last .setValue');
                    $(inputSelect).val(inputSelect.attr('value'));
                }
                updateInputItemsState();
            }

            /**
            * add rowInputItemEmptyWithStatusAdded
            * @param  listContainer {object} parent of tbody
            */
            function addItemInputEmptyWithStatusAdded(){
                addItemInput('', '', '', '', '', '', '', '', '', '', 'added');
            }


            /**
            * Get the number of items in the list
            * @param  listContainer {object} parent of items
            */
            function getItemsCount(listContainer) {
                return $(listContainer).find('li').length;
            }

            /**
             * Numbering List
            * @param  listContainer {object} parent of items
            */
            function listNumbering(listContainer) {
                var number = 1;
                $(listContainer).find('li .item-order').each(function () {
                    $(this).html(number++);
                });
            }


            /***** Start function for SUM *****/

            /**
             * Get sum of item input(inputs like : tax - price - shipping )
            */
            function getSum(input) {
                var sum = 0;
                $(form).find('.orders-list li[item-accepted="1"] ' + input).each(function () {
                    sum += Number($(this).val());
                });
                return sum;
            }

            /**
             * Get sum of prices
            */
            function getSumOfPrice() {
                return getSum('.order-items-price');
            }

            /**
             * Get sum of taxs
            */
            function getSumOfTax() {
                return getSum('.order-items-tax');
            }

            /**
             * Get sum of shipping
            */
            function getSumOfShipping() {
                return getSum('.order-items-shipping');
            }

            /***** End function for SUM *****/


            /**
             * Change input state to be compatible with order state
            * @param  input {string} selector for target element
            * @param  active {boolean} state of input , default value depends on state of order
            */
            function changeInputState(input, active = stateIsRequired) {
                var inputElement = $(form).find(input);
                $(inputElement).prop('required', active).prop('disabled', !active);
                $(inputElement).closest('.form-group').parent().css({ display: active ? '' : 'none' });
            }

            var main_currency = <?php echo e(app_settings()->currency_type_id); ?>


            
            $('#inputCurrency').change(function(){
                var selected_currency = $(this).find('option:selected');
                var exchange_rate_input =  $('#inputExchangeRate');
                if(main_currency == selected_currency.val()){
                    exchange_rate_input.val(1).prop("readonly", true);
                }
                else
                {
                    exchange_rate_input.val(selected_currency.data('value')).prop("readonly", false);
                }
                exchange_rate_input.change()
            })

            
            $('#inputPaymentCurrency').change(function(){
                var selected_currency = $(this).find('option:selected');
                var exchange_rate_input =  $('#inputPaidExchangeRate');
                if(main_currency == selected_currency.val()){
                    exchange_rate_input.val(1).prop("readonly", true);
                }
                else
                {
                    exchange_rate_input.val(selected_currency.data('value')).prop("readonly", false);
                }
            })

            /**
             *  Update input fileds state in order-list items to be compatible with order state
             */
             function updateInputItemsState(){
                changeInputState('.order-items-price');
                changeInputState('.order-items-tax');
                changeInputState('.order-items-shipping');
                changeInputState('.order-items-state');
            }



            /******** End helper functions ********/


            /********   Start events    ********/


            
            $('#inputState').change(function () {
                stateIsRequired = this.value >= 4 && this.value <= 7;
                $('#orderedAtPlacer').css({ display: this.value < 6 ? '' : 'none' });
                changeInputState('#inputOrderedAt', this.value >= 6);
                changeInputState('#inputPaidAt ,#inputPaymentCurrency ,#inputPaidExchangeRate ,#inputPaidUp ,#inputbranch_id', this.value >= 5);
                changeInputState('#inputCurrency ,#inputExchangeRate ,input[readonly] ,#inputFee ,#inputDiscount');
                updateInputItemsState();
            });
            $('#inputState').change();/* to config inputs when loadding page */

            
            $('#inputSumPrice ,#inputSumTax ,#inputSumShipping ,#inputFee ,#inputDiscount ,#inputExchangeRate').change(function () {
                try {
                    var sum = Number($('#inputSumPrice').val());
                    sum += Number($('#inputSumTax').val());
                    sum += Number($('#inputSumShipping').val());
                    sum += Number($('#inputFee').val());
                    sum -= Number($('#inputDiscount').val());
                    $('#inputSumTotalCost').val(sum + $('#inputCurrency option:selected').data('sign'));
                } catch{
                    $('#inputSumTotalCost').val('');
                }
            });


            
            $(form).on('change', '.order-items-price', function () {
                $('#inputSumPrice').val(getSumOfPrice()).change();
            });

            
            $(form).on('change', '.order-items-tax', function () {
                $('#inputSumTax').val(getSumOfTax()).change();
            });

            
            $(form).on('change', '.order-items-shipping', function () {
                $('#inputSumShipping').val(getSumOfShipping()).change();
            });

            
            $(form).on('change', '.order-items-state', function () {
                $(this).closest('li').attr('item-accepted',this.value == 1 ? '1' :'0');
                $(this).closest('li').find('.order-items-price , .order-items-tax , .order-items-shipping').change();
            });


            
            $(form).on('click', '.btnAddItem', function () {
                addItemInputEmptyWithStatusAdded();
            });

            
            $(form).on('click', '.btnDeleteItem', function () {

                if (getItemsCount($(this).closest('ul')) <= 1) {
                    
                    return false;
                }

                var listItem = $(this).closest('li');
                var id = $(listItem).find('[name="items[id][]"]').val();

                if (id) {
                    
                    $(form).append('<input type="hidden" name="deleted_items[]" value="' + id + '" />');
                }

                listItem.remove();
                listNumbering(form);
            });

            /********   End events    ********/


</script>
<?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/purchase_orders/create-edit-js.blade.php ENDPATH**/ ?>