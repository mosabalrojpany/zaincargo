<?php $__env->startSection('content'); ?>


    <div style="height: calc(100vh - 160px);">
        <img src="<?php echo e(url( 'images/logo-with-title-black.png')); ?>" style="width: 100%; height: 100%; object-fit: scale-down; filter: opacity(0.75);" />
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/welcome.blade.php ENDPATH**/ ?>