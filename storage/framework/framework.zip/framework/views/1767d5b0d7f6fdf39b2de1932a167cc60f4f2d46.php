<?php $__env->startSection('content'); ?>


    
    <div class="d-flex justify-content-between">
        <h4 class="font-weight-bold">طلبات الشراء <?php echo e($orders->total()); ?></h4>

        <?php if(hasRole('purchase_orders_add')): ?>
            <a class="btn btn-primary w-100px" href="<?php echo e(url('cp/purchase-orders/create')); ?>">
                <i class="fas fa-plus mx-1"></i>أضف
            </a>
        <?php endif; ?>
    </div>
    



    
    <div class="card card-shadow my-4 text-center">

        <!-- Start search  -->

        <div class="card-header bg-primary text-white">
            <form class="justify-content-between" action="<?php echo e(Request::url()); ?>" method="get">
                <input type="hidden" name="search" value="1">

                <div class="form-inline">
                    <span class="ml-2"><i class="fa fa-filter"></i></span>
                    <div class="form-group">
                        <label class="d-none" for="inputIdSearch">رقم الطلب</label>
                        <input type="number" name="id" min="1" value="<?php echo e(Request::get('id')); ?>" placeholder="رقم الطلب"
                            id="inputIdSearch" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group">
                        <label class="d-none" for="inputCodeSearch">رقم العضوية</label>
                        <input type="number" min="1" name="code" value="<?php echo e(Request::get('code')); ?>"
                            placeholder="رقم العضوية" id="inputCodeSearch" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group">
                        <label class="d-none" for="inputExtraSearch">معلومات أخرى</label>
                        <input type="search" maxlength="32" name="extra" value="<?php echo e(Request::get('extra')); ?>"
                            placeholder="معلومات أخرى" id="inputExtraSearch" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group">
                        <label class="d-none" for="inputNoteSearch">عضوية التاجر</label>
                        <input type="search" maxlength="32" name="merchant_id" value="<?php echo e(Request::get('merchant_id')); ?>"
                            placeholder="عضوية التاجر" id="inputNoteSearch" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group">
                        <label class="d-none" for="inputStateSearch">الحالة</label>
                        <select id="inputStateSearch" class="form-control mx-sm-2 setValue" style="width: 220px;"
                            name="state" value="<?php echo e(Request::get('state')); ?>">
                            <option value="">كل الحالات</option>
                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                </div>


                
                <div class="form-inline mt-2">
                    <span class="ml-2"><i class="fa fa-filter"></i></span>
                    <div class="form-group">
                        <label for="inputPaidAtFromDate">تاريخ الدفع من</label>
                        <input type="date" name="paid_at_from" value="<?php echo e(Request::get('paid_at_from')); ?>"
                            id="inputPaidAtFromDate" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group">
                        <label for="inputPaidAtToDate">إلى</label>
                        <input type="date" name="paid_at_to" max="<?php echo e(date('Y-m-d')); ?>"
                            value="<?php echo e(Request::get('paid_at_to')); ?>" id="inputPaidAtToDate" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group">
                        <label for="inputOrderedAtFromDate">تاريخ الشراء من</label>
                        <input type="date" name="ordered_at_from" value="<?php echo e(Request::get('ordered_at_from')); ?>"
                            id="inputOrderedAtFromDate" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group">
                        <label for="inputOrderedAtToDate">إلى</label>
                        <input type="date" name="ordered_at_to" max="<?php echo e(date('Y-m-d')); ?>"
                            value="<?php echo e(Request::get('ordered_at_to')); ?>" id="inputOrderedAtToDate"
                            class="form-control mx-sm-2">
                    </div>
                    <button type="submit" class="btn btn-primary d-none"><i class="fa fa-search"></i></button>
                </div>
                
                                
                                <div class="form-inline mt-2">
                                    <span class="ml-2"><i class="fa fa-filter"></i></span>
                                    <div class="form-group">
                                        <label class="d-none" for="inputStateSearch">الحالة</label>
                                        <select id="inputMerchant_idSearch" class="form-control mx-sm-2 setValue" style="width: 220px;"
                                            name="merchant_id2" value="<?php echo e(Request::get('merchant_id2')); ?>">
                                            <option value="">احالة</option>
                                            <option value="1">لم تتم الاحالة</option>
                                            <option value="2">تم الاحالة</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="d-none" for="inputStateSearch">سداد</label>
                                        <select id="inputMerchant_stateSearch" class="form-control mx-sm-2 setValue" style="width: 220px;"
                                            name="merchant_state" value="<?php echo e(Request::get('merchant_state')); ?>">
                                            <option value="">سداد</option>
                                            <option value="1">لم يتم السداد</option>
                                            <option value="2">تم السداد</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="d-none" for="inputbranch_idSearch">سداد</label>
                                        <select id="inputbranch_id" class="form-control mx-sm-2 setValue" style="width: 220px;"
                                            name="branch_id" value="<?php echo e(Request::get('branch_id')); ?>">
                                            <option value="">الفرع</option>
                                            <option value="1">طرابلس</option>
                                            <option value="2">مصراته</option>
                                            <option value="3">بنغازي</option>
                                        </select>
                                    </div>

                                    <button type="submit" class="btn btn-primary d-none"><i class="fa fa-search"></i></button>
                                </div>
                                


            </form>
        </div>

        <!-- End search  -->


        <?php
        $canEdit = hasRole('purchase_orders_edit')
        ?>

        <!--    Start show orders   -->
        <div class="card-body p-0">
            <table class="table table-center table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">رقم الطلب</th>
                        <th scope="col">الزبون</th>
                        <th scope="col">الفرع</th>
                        <th scope="col">الحالة</th>
                        <th scope="col">عمولة الشراء</th>
                        <th scope="col">إجمالي التكلفة</th>
                        <th scope="col">التاجر</th>
                        <th scope="col">تخليص </th>

                        <?php if($canEdit): ?>
                            <th scope="col">تعديل</th>
                        <?php endif; ?>

                    </tr>
                </thead>
                <tbody>

                    <!-- Start print orders -->
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr id='<?php echo e($order->id); ?>'>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><a target="_blank" href="<?php echo e(url('cp/purchase-orders', $order->id)); ?>"><?php echo e($order->id); ?></a>
                            </td>
                            <td>
                                <a href="<?php echo e(url('cp/customers', $order->customer_id)); ?>">
                                    <bdi><?php echo e($order->customer->code); ?></bdi>-<?php echo e($order->customer->name); ?>

                                </a>
                            </td>
                            <td><?php if($order->branch_id > null): ?><?php echo e($order->branche->city); ?> <?php else: ?> لا يوجد <?php endif; ?></td>
                            <td><?php echo e($order->getState()); ?></td>
                            <td><?php echo e($order->getFee()); ?></td>
                            <td><?php echo e($order->getTotalCostByCurrency()); ?></td>
                            <?php if($order->merchant_id > 0): ?>
                                <td>
                                    <a href="<?php echo e(url('cp/customers', $order->merchant_id)); ?>">
                                        <bdi><?php echo e($order->merchant->code); ?></bdi>
                                    </a>
                                </td>
                            <?php else: ?>
                                <td>
                                    لا يوجد
                                </td>
                            <?php endif; ?>
                            <td><bdi><?php echo e($order->machertdone()); ?></bdi></td>

                            <?php if($canEdit || hasRole('merchant')): ?>
                                <td>
                                    <?php if($canEdit): ?>
                                    <?php if($order->state <= 5 || Auth::user()->branches_id == $order->branch_id): ?>
                                        <a href="<?php echo e(url('cp/purchase-orders/edit', $order->id)); ?>"
                                            class="btn btn-primary btn-sm">
                                            <i class="fas fa-pen"></i>
                                        </a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if($order->merchant_state == 1 && $order->state >= 6): ?>
                                        <button id="merchant_state" class="btn btn-success btn-sm donewithpayment" data-toggle="modal" data-active="0" data-target="#donepayment">
                                            <i class="fas">تخليص</i>
                                        </button>
                                    <?php endif; ?>
                                    <?php if($order->merchant_id == 0 && $order->state == 5): ?>
                                        <?php if(hasRole('merchant')): ?>
                                            <button class="btn btn-primary btn-sm marchate" data-toggle="modal" data-active="0" data-target="#Modal">
                                                <i class="fas">احالة</i>
                                            </button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- End print orders -->

                </tbody>
            </table>
        </div>
        <!--    End show orders   -->

    </div>
    



    
    <div class="pagination-center"><?php echo e($orders->links()); ?></div>


    <?php if(hasRole('merchant')): ?>
    <!--    Start Modal Modal احالة الى التاجر-->
    <div class="modal fade" id="Modal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ModalLabel">احالة فاتورة الى تاجر </h5>
                    <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class='formSendAjaxRequest1 was-validated' refresh-seconds='2' action="<?php echo e(url('/cp/Merchant')); ?>"
                    method="post">
                    <div class="modal-body px-sm-5">
                        <div class="alert alert-warning text-right" id="alertMsgPassword">ادخل كود الزبون الدي لديه خاصية
                            التاجر</div>
                        <div class="formResult text-center"></div>
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" />
                        <div class="form-group row">
                            <label for="inputName" class="col-sm-auto w-125px col-form-label text-right">عضوية
                                التاجر</label>
                            <div class="col-sm">
                                <input type="text" name="merchant_id" class="form-control" id="inputmerchant_id"
                                    placeholder="عضوية التاجر" pattern=".{1,64}" required>
                                <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',[
                                    'attribute'=>'العضوية','min'=> 1,'max'=>64]); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">تحديث</button>
                        <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--    End Modal Modal -->
    <?php endif; ?>


    <?php if(hasRole('merchant')): ?>
    <!--    Start Modal Modal تخليص التاجر-->
    <div class="modal fade" id="donepayment" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ModalLabel">احالة فاتورة الى تاجر </h5>
                    <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class='formSendAjaxRequest1 was-validated' refresh-seconds='2' action="<?php echo e(url('cp/donewithMerchant')); ?>"
                    method="post">
                    <div class="modal-body px-sm-5">
                        <div class="alert alert-warning text-right" id="alertMsgPassword">هل تريد حقا تخليص التاجر</div>
                        <div class="formResult text-center"></div>
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" />
                        <div class="form-group row">
                            <label for="inputName" class="col-sm-auto w-125px col-form-label text-right">رقم فاتورة التاجر</label>
                            <div class="col-sm">
                                <input type="text" name="marchent_invoice_id" class="form-control" id="inputmarchent_invoice_id"
                                    placeholder="رقم فاتورة التاجر" pattern=".{1,64}" required>
                                <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',[
                                    'attribute'=>'رقم فاتورة التاجر','min'=> 1,'max'=>64]); ?></div>
                            </div>
                        </div>
                        </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">تحديث</button>
                        <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--    End Modal Modal -->
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
    <script>
        var form = $('#Modal form')[0];
        var form1 = $('#donepayment form')[0];
        $('.marchate').click(function() {
            var tr = $(this).closest('tr');
            $(form).find('input[name="id"]').val(tr.attr('id'));
        });
        $('.donewithpayment').click(function() {
            var tr = $(this).closest('tr');
            $(form1).find('input[name="id"]').val(tr.attr('id'));
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/purchase_orders/index.blade.php ENDPATH**/ ?>