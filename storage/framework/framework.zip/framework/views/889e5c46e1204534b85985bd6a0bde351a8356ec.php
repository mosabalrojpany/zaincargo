<?php $__env->startSection('content'); ?>



<div class="d-flex justify-content-between">
    <h4 class="font-weight-bold">فواتير تخليص التجار</h4>

    <div class="d-flex">
        <?php if(hasRole('marchent_invoice_add')): ?>
            <button class="btn btn-primary w-100px" data-toggle="modal" data-active="0" data-target="#Modal">
                <i class="fas fa-plus mx-1"></i>أضف
            </button>
        <?php endif; ?>
    </div>

</div>


<div class="card card-shadow my-4 text-center">
    <!-- Start search  -->
    <div class="card-header bg-primary text-white">
        <form class="justify-content-between" action="<?php echo e(Request::url()); ?>" method="get">
            <input type="hidden" name="search" value="1">
            <div class="form-inline">
                <span class="ml-2"><i class="fa fa-filter"></i></span>
                <div class="form-group">
                    <label class="d-none" for="inputIdSearch">رقم الفاتورة</label>
                    <input type="number" name="id" min="1" value="<?php echo e(Request::url('id')); ?>" placeholder="رقم الفاتورة" id="inputIdSearch" class="form-control mx-sm-2">
                </div>
                <div class="form-group">
                    <label class="d-none" for="inputCodeSearch">عضوية التاجر</label>
                    <input type="number" min="1" name="marchent_id" value="<?php echo e(Request::url('marchent_id')); ?>" placeholder="عضوية التاجر" id="inputCodeSearch" class="form-control mx-sm-2">
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
            </div>
        </form>
    </div>
    <!-- End search  -->

    <!--    Start show invoices   -->
    <div class="card-body p-0">
        <table class="table table-center table-striped table-hover" id="shipments-table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">عضوية التاجر</th>
                    <th scope="col">اسم الموظف</th>
                    <th scope="col">اجمالي دينار</th>
                    <th scope="col">اجمالي دولار</th>
                    <th scope="col">عدد الفواتير</th>
                    <th scope="col">عمليات</th>
                </tr>
            </thead>
            <tbody>
                <!-- Start print invoices -->
                <?php $__currentLoopData = $marchentinvoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marchentinvoices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($marchentinvoices->id); ?></td>
                        <td>
                            <a href="<?php echo e(url('cp/customers',$marchentinvoices->marchent_id)); ?>">
                                <bdi><?php echo e($marchentinvoices->customer->code); ?></bdi>-<?php echo e($marchentinvoices->customer->name); ?>

                            </a>
                        </td>
                        <td><?php echo e($marchentinvoices->employe_name); ?></td>
                        <td><?php echo e($marchentinvoices->price_dener); ?></td>
                        <td><?php echo e($marchentinvoices->price_dolar); ?></td>
                        <td><?php echo e($marchentinvoices->invoicec->count()); ?></td>
                        <td>
                    <?php if(hasRole('marchent_invoice_show')): ?>
                        <a href="<?php echo e(url('cp/marchentinvoice/show',$marchentinvoices->id)); ?>" class="btn btn-primary w-100px">
                            <i class="fas mx-1"></i>عرض
                        </a>
                        <?php endif; ?>
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- End print invoices -->
            </tbody>
        </table>
    </div>
    <!--    End show invoices   -->
</div>


<div class="pagination-center"><?php echo e($marchentinvoice->links()); ?></div>
<!--    Start add Modal -->
<div class="modal fade" id="Modal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ModalLabel">اضافة فاتورة جديدة</h5>
                <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class='formSendAjaxRequest was-validated' refresh-seconds='2' action="<?php echo e(url('/cp/marchentinvoice/add')); ?>" method="post">
                <div class="modal-body px-sm-5">
                    <div class="formResult text-center"></div>
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group row">
                        <label for="inputmarchent_id" class="col-sm-auto w-125px col-form-label text-right">كود التاجر</label>
                        <div class="col-sm">
                            <input type="text" name="marchent_id" class="form-control" id="inputmarchent_id" placeholder="كود التاجر" pattern=".{1,64}" required>
                            <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',[ 'attribute'=>'كود التاجر','min'=> 1,'max'=>64]); ?></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">تحديث</button>
                    <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                </div>
            </form>
        </div>
    </div>
</div>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/marchentinvoice/index.blade.php ENDPATH**/ ?>