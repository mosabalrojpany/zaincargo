<?php $__env->startSection('content'); ?>
    <!--  Start path  -->
    <div class="d-flex align-items-center bg-white mb-3 d-print-none">

        <nav class="col pr-0" aria-label="breadcrumb" role="navigation">
            <ol class="breadcrumb bg-white mb-0">
                <li class="breadcrumb-item">
                    <a href="">محفظة</a>
                </li>
                <li class="breadcrumb-item active text-truncate col pr-0 text-right" aria-current="page">
                    <span class="mr-1"></span>
                </li>
            </ol>
        </nav>
    </div>
    <!--  End path  -->
    <div class="card card-shadow">
        <?php echo $__env->make('CP.elerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('CP.elerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="card-header text-right bg-white pt-4">
            <div class="row">
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">اسم الزبون</label>
                        <div class="col text-secondary">
                            <a ><?php echo e($data->customer->name); ?></a>
                        </div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">رقم العضوية</label>
                        <div class="col text-secondary"><bdi><?php echo e($data->customer->code); ?></bdi></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">الفرع</label>
                    <div class="col text-secondary"><bdi><label class="col-auto w-125px"><?php echo e($data->customer->branches->city); ?></label></bdi></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>
            </div>
        </div>
        
        
                <div class="card-body">
                    <table class="table table-center table-bordered text-center">
                        <thead>
                            <tr>
                                
                                <th>LY طرابلس</th>
                                <th>$ طرابلس</th>
                                <th>LY بنغازي</th>
                                <th>$ بنغازي</th>
                                <th>LY مصراته</th>
                                <th>$ مصراته</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr> 
                                <td><?php echo e($data->money_denar_t); ?></td>
                                <td><?php echo e($data->money_dolar_t); ?></td>
                                <td><?php echo e($data->money_denar_b); ?></td>
                                <td><?php echo e($data->money_dolar_b); ?></td>
                                <td><?php echo e($data->money_denar_m); ?></td>
                                <td><?php echo e($data->money_dolar_m); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                
                <div class="card-body">
                    <table class="table table-center table-bordered text-center">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>النوع</th>
                                <th>القيمة</th>
                                <th>العملة</th>
                                <th>التاريخ</th>
                                <th>الفرع</th>
                                <th class="">ملاحظة</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data->business; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $change): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($change->depositytypee()); ?></td>
                                <td><?php echo e($change->price); ?></td>
                                <td><?php echo e($change->currencytype->name); ?></td>
                                <td><?php echo e($change->created_at); ?></td>
                                <td><?php echo e($change->branchess->city); ?></td>
                                <td><?php echo e($change->note); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/Client/wallet/show.blade.php ENDPATH**/ ?>