<?php $__env->startSection('content'); ?>


<!--  Start path  -->
<nav aria-label="breadcrumb" role="navigation" class="shadow">
    <ol class="breadcrumb bg-white">
        <li class="breadcrumb-item"> 
            <a href="<?php echo e(url('cp/money-transfers')); ?>">حوالات مالية</a>
        </li>
        <li class="breadcrumb-item active text-truncate col pr-0 text-right" aria-current="page">
            <span class="mr-1"><?php echo e(empty($transfer) ? 'حوالة جديدة' : $transfer->id); ?></span>
        </li>
    </ol>
</nav>
<!--  End path  -->



<!--    Start header of Trip   -->
<form class="formSendAjaxRequest card card-shadow was-validated" id="form-transfer" focus-on="#form-transfer"
    refresh-seconds="1" upload-files="true" action="<?php echo e(url('cp/money-transfers',(empty($transfer) ? '' : 'edit'))); ?>" method="POST">

    <?php echo csrf_field(); ?>

    
    <div class="card-header bg-white text-right">
        
        <div class="formResult my-3 text-center"></div>

        <?php if(isset($transfer->id)): ?>

            <div class="alert alert-warning text-right">الملف اتركه فارغ إذا لاتريد تغيره</div>

            <input type="hidden" name="id" value="<?php echo e($transfer->id); ?>" />

        <?php endif; ?>

        
        <div class="row"> 

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputCode" class="col-auto w-125px col-form-label">رقم العضوية</label>
                    <div class="col pr-md-0">
                        <input id="inputCode" type="text" name="code" pattern="\s*([^\s]\s*){1,12}" class="form-control" required>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'رقم العضوية','min'=> 1 ,'max'=>12]); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputState" class="col-auto w-125px col-form-label">الحالة</label>
                    <div class="col pr-md-0">
                        <select id="inputState" name="state" class="form-control" required>
                            <option value="">...</option>
                            <?php $__currentLoopData = trans('moneyTransfer.status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

        </div>
        

        <hr/>

        
        <div class="row">

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputCountry" class="col-sm-auto w-125px col-form-label">البلد</label>
                    <div class="col-sm pr-md-0">
                        <select id="inputCountry" name="country" class="form-control" required>
                            <option value="" selected>...</option>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputCity" class="col-sm-auto w-125px col-form-label">المدينة</label>
                    <div class="col-sm pr-md-0">
                        <select id="inputCity" name="city" class="form-control" required>
                            <option value="" selected>...</option>
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <option value="<?php echo e($city->id); ?>" data-country="<?php echo e($city->country_id); ?>"><?php echo e($city->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                    </div>
                </div>
            </div>

        </div>
        

        <hr/>

        
        <div class="row">

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputRecipient" class="col-auto w-125px col-form-label">اسم المستلم</label>
                    <div class="col pr-md-0">
                        <input id="inputRecipient" type="text" name="recipient" pattern="\s*([^\s]\s*){9,32}" class="form-control" required>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'الاسم','min'=> 9 ,'max'=>32]); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputPhone" class="col-sm-auto w-125px pl-0 col-form-label">رقم الهاتف</label>
                    <div class="col-sm pr-md-0">
                        <input type="text" name="phone" id="inputPhone" class="form-control text-right" dir='ltr' placeholder="+XXX-XXXXXXXXX" pattern="\s*([0-9\-\+]\s*){3,14}" required>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.digits_between',['attribute'=>'رقم الهاتف','min'=> 3 ,'max'=>14]); ?></div>
                    </div>
                </div> 
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputPhone2" class="col-sm-auto w-125px pl-0 col-form-label">رقم الهاتف2</label>
                    <div class="col-sm pr-md-0">
                        <input type="text" name="phone2" id="inputPhone2" class="form-control text-right" dir='ltr' placeholder="+XXX-XXXXXXXXX" pattern="\s*([0-9\-\+]\s*){3,14}">
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.digits_between',['attribute'=>'رقم الهاتف','min'=> 3 ,'max'=>14]); ?></div>
                    </div>
                </div> 
            </div>

        </div>
        

        <hr/>

        
        <div class="row">

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputRecipientType" class="col-auto w-125px col-form-label">نوع المستلم</label>
                    <div class="col pr-md-0">
                        <select id="inputRecipientType" name="recipient_type" class="form-control" required>
                            <option value="">...</option>
                            <?php $__currentLoopData = trans('moneyTransfer.recipient_types'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputCustomFile" class="col-auto pl-0 w-125px col-form-label">إرفاق ملف</label>
                    <div class="col pr-md-0">
                        <div class="custom-file">
                            <input type="file" name="file" class="custom-file-input" id="inputCustomFile" accept=".png,.jpg,.jpeg,.gif,.pdf,.xls" />
                            <label class="custom-file-label" for="inputCustomFile">اختر ملف</label>
                        </div>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get("validation.mimes",[ "attribute"=>"","values" => "png,jpg,jpeg,gif,pdf,xls"]); ?></div>        
                    </div>
                </div>
            </div>

        </div>
        

        <hr/>

        
        <div class="row">

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputFeeOnRecipient" class="col-sm-auto w-125px col-form-label">العمولة على</label>
                    <div class="col-sm pr-md-0">
                        <select id="inputFeeOnRecipient" name="fee_on_recipient" class="form-control" required>
                            <option value="" selected>...</option>
                            <?php $__currentLoopData = trans('moneyTransfer.fee_on'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputReceivingMethod" class="col-auto pl-0 w-125px col-form-label">طريقة الاستلام</label>
                    <div class="col pr-md-0">
                        <select id="inputReceivingMethod" name="receiving_method" class="form-control" required>
                            <option value="">...</option>
                            <?php $__currentLoopData = trans('moneyTransfer.receiving_methods'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputCurrency" class="col-sm-auto w-125px col-form-label">العملة</label>
                    <div class="col-sm pr-md-0">
                        <select id="inputCurrency" name="currency" class="form-control" required>
                            <option value="" selected>...</option>
                            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <option value="<?php echo e($currency->id); ?>" data-sign="<?php echo e($currency->sign); ?>"><?php echo e($currency->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputAmount" class="col-auto w-125px col-form-label">المبلغ</label>
                    <div class="col pr-md-0">
                        <input type="number" min="1" step="any" name="amount" id="inputAmount" class="form-control" required>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.min.numeric',['attribute'=>'المبلغ','min'=> 1]); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputFee" class="col-auto w-125px col-form-label">عمولة الحوالة</label>
                    <div class="col pr-md-0">
                        <input type="number" min="0" step="any" name="fee" id="inputFee" class="form-control" required>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.min.numeric',['attribute'=>'العمولة','min'=> 0]); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label class="col-auto w-125px col-form-label">الإجمالي</label>
                    <div class="col pr-md-0">
                        <input type="text" id="inputSumTotal" readonly class="form-control">
                    </div>
                </div>
            </div>

        </div>
        

        <hr/>
        
        
        <div class="row">

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputAccountNumber" class="col-auto w-125px col-form-label">رقم الحساب</label>
                    <div class="col pr-md-0">
                        <input id="inputAccountNumber" name="account_number" type="text" pattern="\s*([^\s]\s*){3,32}" class="form-control" required>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'رقم الحساب','min'=> 3 ,'max'=>32]); ?></div>
                    </div>
                </div>
            </div>
    
            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputAccountNumber2" class="col-auto w-125px col-form-label">رقم الحساب 2</label>
                    <div class="col pr-md-0">
                        <input id="inputAccountNumber2" name="account_number2" type="text" pattern="\s*([^\s]\s*){3,32}" class="form-control" />
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'رقم الحساب','min'=> 3 ,'max'=>32]); ?></div>
                    </div>
                </div>
            </div>
    
            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                        <label for="inputAccountNumber3" class="col-auto pl-0 w-125px col-form-label">رقم الحساب 3</label>
                        <div class="col pr-md-0">
                        <input id="inputAccountNumber3" name="account_number3" type="text" pattern="\s*([^\s]\s*){3,32}" class="form-control" />
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'رقم الحساب','min'=> 3 ,'max'=>32]); ?></div>
                    </div>
                </div>
            </div>

        </div>
        

        <hr/>

        
        <div class="row">
            
            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputConvertedAt" class="col-auto w-125px col-form-label">تاريخ التحويل</label>
                    <div class="col pr-md-0">
                        <input type="date" max="<?php echo e(date('Y-m-d')); ?>" name="converted_at" id="inputConvertedAt" class="form-control checkDate" checkDateTarget="#inputReceivedAt" required>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.before_or_equal',['attribute'=>'تاريخ التحويل','date'=> date('d/m/Y')]); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputReceivedAt" class="col-auto w-125px col-form-label">تاريخ الاستلام</label>
                    <div class="col pr-md-0">
                        <input type="date" max="<?php echo e(date('Y-m-d')); ?>" name="received_at" id="inputReceivedAt" class="form-control">
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.after_or_equal',['attribute'=>'تاريخ الاستلام','date'=> 'التحويل']); ?></div>
                    </div>
                </div>
            </div>

        </div>
        

        <hr/>

        
        <div class="row">

            <div class="col-lg-6">
                <div class="form-group row">
                    <label for="inputNote" class="col-auto w-125px col-form-label">ملاحظة</label>
                    <div class="col pr-md-0">
                        <textarea name="note" id="inputNote" maxlength="150" rows="2" class="form-control" placeholder="ملاحظة لزبون"></textarea>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.max.string',['attribute'=>'ملاحظة','max'=>150]); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="form-group row">
                    <label for="inputExtra" class="col-auto w-125px col-form-label">أخرى</label>
                    <div class="col pr-md-0">
                        <textarea name="extra" id="inputExtra" maxlength="150" rows="2" class="form-control" placeholder="معلومات إضافية خاصة بالنظام"></textarea>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.max.string',['attribute'=>'معلومات أخرى','max'=>150]); ?></div>
                    </div>
                </div>
            </div>

        </div>
        

    </div>
    
 

    <!--    Start footer    -->
    <div class="card-footer d-flex align-items-center justify-content-between">
        <div class="form-group mb-0 pr-4">
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="customControlIamSure" required>
                <label class="custom-control-label" for="customControlIamSure">أنا متأكد</label>
            </div>
        </div> 
        <button type="submit" class="btn btn-primary w-125px">حفظ</button>
    </div>
    <!--    End footer    -->


</form>
<!--    End header of Trip   -->



<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra-js'); ?>

    <script>
        
        
        $('#inputCountry').change(function () {
            /* When user change country show only cities that exist in current country */
            $('#inputCity').val('');
            if ($(this).val()) {
                $('#inputCity').find('option').hide().filter('[data-country="' + $(this).val() + '"] ,[value=""]').show();
            } else {
                $('#inputCity').find('option').hide().filter('[value=""]').show();
            }
        });
        $('#inputCountry').change(); /* to show only related citites for selected country */
        


        
        $('#inputAmount , #inputFee , #inputCurrency').change(function () {
            var amount = $('#inputAmount').val();
            var fee = $('#inputFee').val();
            var currency = $('#inputCurrency :selected').data('sign');
            if (amount && fee && currency) {
                $('#inputSumTotal').val( (Number(amount) + Number(fee)) + currency);
            } else {
                $('#inputSumTotal').val('');
            }
        });
        
        

        
        $('#inputReceivingMethod').change(function () {
            $('input[name^=account_number]').prop('disabled', $(this).val() != 2); 
        });
        


        
        $('#inputState').change(function () {
            var state = Number($(this).val());
            $('#inputFee').prop('disabled', state < 4);
            $('#inputConvertedAt').prop('disabled', state < 5);
            $('#inputReceivedAt').prop('disabled', state !== 6);
        });
        

        
        
        <?php if(isset($transfer)): ?>

            $('#inputCode').val(strip_tags("<?php echo e($transfer->customer->code); ?>"));
            $('#inputState').val("<?php echo e($transfer->state); ?>").change();
            $('#inputCountry').val("<?php echo e($transfer->country_id); ?>").change();
            $('#inputCity').val("<?php echo e($transfer->city_id); ?>");
            $('#inputRecipient').val(strip_tags("<?php echo e($transfer->recipient); ?>"));
            $('#inputPhone').val(strip_tags("<?php echo e($transfer->phone); ?>"));
            $('#inputPhone2').val(strip_tags("<?php echo e($transfer->phone2); ?>"));
            $('#inputRecipientType').val("<?php echo e($transfer->recipient_type); ?>");
            $('#inputFeeOnRecipient').val("<?php echo e($transfer->fee_on_recipient); ?>");
            $('#inputReceivingMethod').val("<?php echo e($transfer->receiving_method); ?>").change();
            $('#inputCurrency').val("<?php echo e($transfer->currency_type_id); ?>");
            $('#inputAmount').val("<?php echo e($transfer->amount); ?>");
            $('#inputFee').val("<?php echo e($transfer->fee); ?>").change();
            $('#inputAccountNumber').val(strip_tags("<?php echo e($transfer->account_number); ?>"));
            $('#inputAccountNumber2').val(strip_tags("<?php echo e($transfer->account_number2); ?>"));
            $('#inputAccountNumber3').val(strip_tags("<?php echo e($transfer->account_number3); ?>"));
            $('#inputConvertedAt').val("<?php echo e($transfer->converted_at()); ?>");
            $('#inputReceivedAt').val("<?php echo e($transfer->received_at()); ?>");
            $('#inputNote').val(<?php echo json_encode($transfer->note); ?>);
            $('#inputExtra').val(<?php echo json_encode($transfer->extra); ?>);

        <?php endif; ?>

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/money_transfers/create-edit.blade.php ENDPATH**/ ?>