<?php $__env->startSection('content'); ?>



<h4 class="font-weight-bold">الشحنات <?php echo e($invoices->total()); ?></h4>





<div class="card shadow border-0 my-4 text-center">

    <!-- Start search  -->
    <div class="card-header bg-primary text-white">
        <form class="row justify-content-between" action="<?php echo e(Request::url()); ?>" method="get">

            <input type="hidden" name="search" value="1">

            <div class="form-inline col-auto d-none d-xl-flex">
                <div class="form-group">
                    <label for="inputShowSearch">عرض</label>
                    <input type="number" id="inputShowSearch" name="show" min="10" max="500" class="form-control mx-sm-2" value="<?php echo e(Request::has('show') ? Request::get('show') : 25); ?>" />
                </div>
            </div>

            <div class="form-inline">
                <span class="mx-2"><i class="fa fa-filter"></i></span>
                <div class="form-group mb-0">
                    <label class="d-none" for="inputIdSearch">رقم الفاتورة</label>
                    <input type="number" name="id" min="1" value="<?php echo e(Request::get('id')); ?>" placeholder="رقم الفاتورة" id="inputIdSearch" class="form-control mx-sm-2">
                </div>
                <div class="form-group d-none d-lg-flex">
                    <label class="d-none" for="inputTrackingNumberSearch">رقم التتبع</label>
                    <input type="search" maxlength="32" name="tracking_number" value="<?php echo e(Request::get('tracking_number')); ?>" placeholder="رقم التتبع" id="inputTrackingNumberSearch" class="form-control mx-sm-2">
                </div>
                <div class="form-group d-none d-sm-flex">
                    <label class="d-none" for="inputShipmentCodeSearch">رمز الشحنة</label>
                    <input type="search" maxlength="32" name="shipment_code" value="<?php echo e(Request::get('shipment_code')); ?>" placeholder="رمز الشحنة" id="inputShipmentCodeSearch" class="form-control mx-sm-2">
                </div>
                <div class="form-group">
                    <label class="d-none" for="inputStateSearch">الحالة</label>
                    <select id="inputStateSearch" class="form-control mx-sm-2 setValue" style="width: 220px;" name="state" value="<?php echo e(Request::get('state')); ?>">
                        <option value="">كل الحالات</option>
                        <?php $__currentLoopData = __('shipmentStatus.shipment_status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
            </div>

        </form>
    </div>
    <!-- End search  -->

    <!--    Start show invoices   -->
    <div class="card-body p-0">
        <table class="table table-center table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col" class="d-none d-md-table-cell">#</th>
                    <th scope="col">رقم الفاتورة</th>
                    <th scope="col" class="d-none d-md-table-cell">رقم الرحلة</th>
                    <th scope="col" class="d-none d-sm-table-cell">الحالة</th>
                    <th scope="col" class="d-none d-lg-table-cell">رقم التتبع</th>
                    <th scope="col">رمز الشحنة</th>
                    <th scope="col" class="d-none d-lg-table-cell">تاريخ الاستلام</th>
                </tr>
            </thead>
            <tbody>

                <!-- Start print invoices -->
                <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row" class="d-none d-md-table-cell"><?php echo e($loop->iteration); ?></th>
                        <td>
                            <a href="<?php echo e(url('client/shipping-invoices',$invoice->id)); ?>"><?php echo e($invoice->id); ?></a>
                        </td>
                        <td class="d-none d-md-table-cell"><?php echo e($invoice->trip_number()); ?></td>
                        <td class="d-none d-sm-table-cell"><?php echo e($invoice->getState()); ?></td>
                        <td class="d-none d-lg-table-cell"><?php echo e($invoice->tracking_number); ?></td>
                        <td><?php echo e($invoice->shipment_code); ?></td>
                        <td class="d-none d-lg-table-cell">
                            <bdi><?php echo e($invoice->arrived_at()); ?></bdi>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- End print invoices -->

            </tbody>
        </table>
    </div>
    <!--    End show invoices   -->

</div>





<div class="pagination-center"><?php echo e($invoices->links()); ?></div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/Client/shipping_invoices/index.blade.php ENDPATH**/ ?>