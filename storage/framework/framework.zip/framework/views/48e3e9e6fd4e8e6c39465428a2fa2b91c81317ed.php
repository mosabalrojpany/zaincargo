

<!--    blog sidebar section start   -->
<div class="sidebar">

    <div class="blog-sidebar-widgets">
        <div class="searchbar-form-section">
            <form action="<?php echo e(url('news')); ?>">
                <div class="searchbar">
                    <input name="search" type="text" value="<?php echo e(Request::get('search')); ?>" placeholder="بحث" maxlength="32" required>
                    <button type="submit"><i class="fa fa-search"></i></button>
                </div>
            </form>
        </div>
    </div>

    <div class="blog-sidebar-widgets category-widget">
        <div class="category-lists">
            <h4>التصنيفات</h4>
            <ul>
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="single-category">
                        <a href="<?php echo e(url("news?tag=$tag->name")); ?>">
                            <?php echo e($tag->name); ?>

                        </a> 
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    
    <div class="blog-sidebar-widgets post-widget">
        <div class="popular-posts-lists">
            <h4>أخر الأخبار</h4>

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="single-popular-post">
                    
                    <div class="popular-post-img-wrapper">
                        <img src="<?php echo e($post->getImageAvatar()); ?>" alt="<?php echo e($post->title); ?>">
                    </div>
                    
                    <div class="popular-post-txt">
                        <h5 class="popular-post-title" title="<?php echo e($post->title); ?>">
                            <a href="<?php echo e(url('news',$post->id)); ?>"><?php echo e($post->getShortTitle()); ?></a>
                        </h5>
                        <small class="time mr-1">
                            <i class="far fa-clock" style="vertical-align: middle"></i>
                            <bdi><?php echo e($post->getDate()); ?></bdi>
                        </small>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

</div>
<!--    blog sidebar section end   -->
<?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/main/posts/sidebar.blade.php ENDPATH**/ ?>