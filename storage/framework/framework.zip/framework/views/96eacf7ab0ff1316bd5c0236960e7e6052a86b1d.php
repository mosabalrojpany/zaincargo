<?php $__env->startSection('subject'); ?>
    <?php echo e($subject); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    
<p>
    تم احالة طلب شراء لك رقم الطلب <b><bdi><?php echo e($PurchaseOrder->id); ?></bdi></b>
</p>
        
    <table style="margin-top: 20px; border: 1px solid #333; width: 100%; text-align: center; border-collapse: collapse;">
        <thead>
            <tr style="background-color: #1f415f; color: #fff; height: 36px;">
                <th style="border: 1px solid #999;">رقم الطلب</th>
            </tr>
        </thead>
        <tbody>
            <tr style="height: 34px;">
                <td style="border: 1px solid #999;"><bdi><?php echo e($PurchaseOrder->id); ?></bdi></td>
            </tr>
        </tbody>
    </table>

    <p>
        للاطلاع على تفاصيل الطلب الرجاء الدخول إلى حسابك أو  
        <b>
            <a target="_blank" href="<?php echo e(url('client/merchant_prchase_order/show',$PurchaseOrder->id)); ?>">اضغط هنا لعرض الطلب</a>.
        </b>
    </p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('emails.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/emails/Purchaseorder/purchaseorder.blade.php ENDPATH**/ ?>