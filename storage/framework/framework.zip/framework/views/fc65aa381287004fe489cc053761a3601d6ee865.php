<?php $__env->startSection('content'); ?>


    <!--  Start path  -->
    <div class="d-flex align-items-center bg-white mb-3 d-print-none">

        <nav class="col pr-0" aria-label="breadcrumb" role="navigation">
            <ol class="breadcrumb bg-white mb-0">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('cp/marchentinvoice/show')); ?>">فاتورة تخليص تاجر</a>
                </li>
            </ol>
        </nav>
        <?php if(hasRole('marchent_invoice_print')): ?>
        <div class="col-auto">
                <a href="<?php echo e(url('cp/marchentinvoice/show/print', $marchentinv->id)); ?>" target="_blank" class="btn btn-secondary btn-sm"><i class="fas fa-print"></i></a>
        </div>
        <?php endif; ?>
    </div>
    <!--  End path  -->
    <div class="card card-shadow">
        
        <div class="card-header text-right bg-white pt-4">

            <div class="row">

                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">رقم الفاتورة</label>
                        <div class="col text-secondary"><bdi><?php echo e($marchentinv->id); ?></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">كود التاجر</label>
                        <div class="col text-secondary"><bdi><?php echo e($marchentinv->customer->code); ?> </bdi></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">اسم الموظف</label>
                        <div class="col text-secondary"><b><?php echo e($marchentinv->employe_name); ?></b></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">عدد الفواتير</label>
                        <div class="col text-secondary"><bdi><?php echo e($marchentinv->invoicec->count()); ?></bdi></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>
            </div>
            <hr />
        </div>
        


        
        <div class="card-body">


            
            <h4 class="p-3 bg-secondary text-white text-right mb-0 rounded-top">إجمالي التكلفة</h4>

            <table class="table table-center table-bordered text-center">
                <thead>
                    <tr>
                        <th>#</th>
                        <th> التكلفة دينار</th>
                        <th>التكلفة دولار</th>
                        <th>عدد الفواتير</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td><?php echo e($marchentinv->price_dener); ?></td>
                        <td><?php echo e($marchentinv->price_dolar); ?></td>
                        <td><?php echo e($marchentinv->invoicec->count()); ?></td>
                    </tr>
                </tbody>
            </table>
            <table class="table table-center table-bordered text-center">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>رقم الفاتورة</th>
                        <th>اجمالي التكلفة</th>
                        <th>الفرع</th>
                        <th>الزبون</th>
                        <th>الحالة</th>
                        <th>التاجر</th>
                        <th>عمليات</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php $__currentLoopData = $marchentinv->invoicec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id='<?php echo e($invoices->id); ?>'>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><a href="<?php echo e(url('cp/purchase-orders', $invoices->id)); ?>"
                                    target="_blank"><?php echo e($invoices->id); ?></a></td>
                            <td><?php echo $invoices->getTotalCostByCurrency(); ?></td>
                            <td><?php if($invoices->branch_id > null): ?><?php echo e($invoices->branche->city); ?> <?php else: ?> لا يوجد <?php endif; ?></td>
                            <td>
                                <a target="_blank" href="<?php echo e(url('cp/customers', $invoices->customer_id)); ?>">
                                    <?php echo e($invoices->customer->code); ?>

                                </a>
                            </td>
                            <td><bdi><?php echo e($invoices->getState()); ?></bdi></td>
                            <td><bdi><?php echo e($invoices->customer2->code); ?></bdi></td>
                            <td>
                                <button class="btn btn-danger btn-sm cancelinvoice" data-toggle="modal" data-active="0"
                                    data-target="#Modal">
                                    <i class="fas">الغاء التخليص</i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
        </div>
        
    </div>
    <!--    Start Modal Modal تخليص التاجر-->
    <div class="modal fade" id="Modal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ModalLabel">الغاء التخليص </h5>
                    <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class='formSendAjaxRequest1 was-validated' refresh-seconds='2'
                    action="<?php echo e(url('cp/marchentinvoice/show/cancel')); ?>" method="post">
                    <div class="modal-body px-sm-5">
                        <div class="alert alert-warning text-right" id="alertMsgPassword">هل تريد حقا الغاء تخليص هده
                            الفاتورة</div>
                        <div class="formResult text-center"></div>
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" />
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">تحديث</button>
                        <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--    End Modal Modal -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
    <script>
        var form = $('#Modal form')[0];
        $('.cancelinvoice').click(function() {
            var tr = $(this).closest('tr');
            $(form).find('input[name="id"]').val(tr.attr('id'));
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/marchentinvoice/show.blade.php ENDPATH**/ ?>