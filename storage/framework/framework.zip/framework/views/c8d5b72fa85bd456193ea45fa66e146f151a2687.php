 
<?php $__env->startSection('content'); ?>


    <h4 class="font-weight-bold text-right">الرسائل <?php echo e($messages->total()); ?></h4>


	<div class="row pt-4 mb-5 text-right">

		<!--    Start search box     -->
		<aside class="col-lg-4 col-xl-3 mb-5">
			<form action="<?php echo e(Request::url()); ?>">
				<input type="hidden" name="search" value="1" />
				<div class="form-group">
					<label>الحالة</label>
					<select name="unread" class="form-control setValue" value="<?php echo e(Request::get('unread')); ?>" >
                        <option value="" selected>الكل</option>
                        <?php $__currentLoopData = trans('messageStatus.status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
                <div class="form-group">
                    <label>الاسم</label>
                    <input type="search" maxlength="32" value="<?php echo e(Request::get('name')); ?>" name="name" class="form-control" />
                </div>
                <div class="form-group">
                    <label>رقم الهاتف</label>
                    <input type="search" maxlength="14" value="<?php echo e(Request::get('phone')); ?>" name="phone" class="form-control" />
                </div>
                <div class="form-group">
                    <label>البريد الإلكتروني</label>
                    <input type="search" maxlength="64" value="<?php echo e(Request::get('email')); ?>" name="email" class="form-control" />
                </div>
				<div class="form-group">
					<label>العنوان</label>
					<input type="search" maxlength="32" value="<?php echo e(Request::get('title')); ?>" name="title" class="form-control" />
				</div>
				<div class="form-group">
					<label>من</label>
				<input type="date" value="<?php echo e(Request::get('from')); ?>" max="<?php echo e(date('Y-m-d')); ?>" name="from" class="form-control" />
				</div>
				<div class="form-group">
					<label>إلى</label>
					<input type="date" value="<?php echo e(Request::get('to')); ?>" max="<?php echo e(date('Y-m-d')); ?>" name="to" class="form-control" />
				</div>
				<button type="submit" class="btn btn-primary btn-block mt-2">بحث</button>
			</form>
		</aside>
		<!--    End search box     -->


		<section class="col-lg-8 col-xl-9">

			<div id="messagesCollapsible" class="d-flex flex-column" role="tablist">

				<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="bg-white box-list mb-1">

                        
                        <div class="px-4 border-bottom-0 py-3" role="tab" id="heading<?php echo e($message->id); ?>">
                            <h5 class="mb-1 d-flex f-18px align-items-start">
                                <?php if($message->unread): ?>
                                    <span class="label-state col-auto ml-1 text-white d-inline-block bg-danger"><?php echo e($message->getState()); ?></span> 
                                <?php endif; ?>
                                <a data-toggle="collapse" class="text-dark collapsed" href="#collapse<?php echo e($message->id); ?>"
                                    aria-expanded="false" aria-controls="collapse<?php echo e($message->id); ?>"><?php echo e($message->title); ?></a>
                            </h5>
                            <span class="text-muted f-15px d-inline-block">
                                <i class="fa fa-user mx-1"></i>
                                <bdi><?php echo e($message->name); ?></bdi>
                                <i class="far fa-clock ml-1 mr-3"></i>
                                <bdi><?php echo e($message->created_at->diffForHumans()); ?></bdi>
                            </span>
                        </div>
                        
                        
                        
                        <div id="collapse<?php echo e($message->id); ?>" class="collapse border-top text-right" role="tabpanel" aria-labelledby="heading<?php echo e($message->id); ?>" data-parent="#messagesCollapsible">
                            <div class="px-4 pt-3 text-secondary">

                                <div class="row justify-content-between">

                                    
                                    <ul class="col-auto message-info list-unstyled mb-0">
                                        <li>
                                            <span class="info-icon"><i class="fa fa-envelope ml-1"></i></span>
                                            <?php echo e($message->email); ?>

                                        </li>
                                        <li>
                                            <span class="info-icon"><i class="fa fa-phone ml-1"></i></span>
                                            <bdi><?php echo e($message->phone); ?></bdi>
                                        </li>
                                        <li title="<?php echo e($message->ip); ?>">
                                            <span class="info-icon"><i class="fa fa-map-marker-alt ml-1"></i></span>
                                            <?php echo e($message->country.' - '.$message->city); ?>

                                        </li>
                                        <li>
                                            <span class="info-icon"><i class="far fa-clock ml-1"></i></span>
                                            <bdi><?php echo e($message->created_at()); ?></bdi>
                                        </li>
                                    </ul>
                                    

                                    
                                    <div class="col-auto">

                                        <?php if(hasRole('messages_edit')): ?>
                                            <?php if($message->unread): ?>
                                                <a href="<?php echo e(url('cp/messages/update/state',$message->id)); ?>" class="btn btn-dark btn-sm ml-1 text-white">
                                                    <i class="fas fa-check fa-fx"></i>
                                                </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(url('cp/messages/update/state',$message->id)); ?>" class="btn btn-secondary btn-sm ml-1 text-white">
                                                    <i class="fas fa-times fa-fx"></i>
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        
                                        <?php if(hasRole('messages_delete')): ?>
                                            <button type="button" class="btn btn-danger btn-sm btnDelete" data-toggle="modal" data-target="#deleteModel" data-id="<?php echo e($message->id); ?>">
                                                <i class="fas fa-trash fa-fx"></i>
                                            </button>
                                        <?php endif; ?>
                                        
                                    </div>
                                    

                                </div>
                                
                                <hr class="align-self-center w-75"/>

                                <p class="pre-wrap mt-3 pb-4"><?php echo e($message->content); ?></p>

                            </div>
                        </div>
                        
                        
                    </div>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>

			<div class="pagination-center mt-4"> <?php echo e($messages->links()); ?></div>

		</section>

	</div>

   
   
   
    
    <div class="modal fade" id="deleteModel" tabindex="-1" role="dialog" aria-labelledby="deleteModelLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
    
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModelLabel">حذف رسالة</h5>
                    <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
               
                <form class='formSendAjaxRequest' redirect-to="<?php echo e(Request::url()); ?>" refresh-seconds='2' action="<?php echo e(url('cp/messages')); ?>" method="post">
                    
                    <div class="modal-body text-right">
                        <div class="formResult text-center"></div>
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" />
                        هل أنت متأكد أنك تريد حذف الرسالة ؟
                    </div>
    
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-danger">حذف</button>
                        <button type="button" class="btn btn-secondary mr-2" data-dismiss="modal">إلغاء</button>
                    </div>
    
                </form>
    
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra-js'); ?>
    <script>
    
        
        $('.btnDelete').click(function () {
            $('#deleteModel form input[name="id"]').val($(this).data('id'));
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/messages.blade.php ENDPATH**/ ?>