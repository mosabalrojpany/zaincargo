<?php $__env->startSection('content'); ?>



    <!--    Start header    -->
    <div class="d-flex justify-content-between">
        <h4 class="font-weight-bold">حركات التجار على فواتير الشراء</h4>
    </div>
    <!--    End header    -->




    <!--    Start show Roles   -->
    <table class="table text-center mt-4 bg-white">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">اسم التاجر</th>
                <th scope="col">كود التاجر</th>
                <th scope="col">رقم الفاتورة</th>
                <th scope="col">الملاحظة</th>
                <th scope="col">التاريخ</th>
            </tr>
        </thead>
        <tbody>

            <!-- Start print Roles -->
            <?php $__currentLoopData = $trnsaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trnsactions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><a href="<?php echo e(url('cp/customers',$trnsactions->merchant_id)); ?>"><?php echo e($trnsactions->merchant_name); ?></a></td>
                    <td><a href="<?php echo e(url('cp/customers',$trnsactions->merchant_id)); ?>"><?php echo e($trnsactions->merchant_code); ?></a></td>
                    <td><a  href="<?php echo e(url('cp/purchase-orders', $trnsactions->order_id)); ?>" ><?php echo e($trnsactions->order_id); ?></a></td>
                    <td><?php echo e($trnsactions->note); ?></td>
                    <td><?php echo e($trnsactions->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End print Roles -->
        </tbody>
    </table>
    <!--    End show Roles   -->
    <div class="pagination-center mt-2"> <?php echo e($trnsaction->links()); ?></div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/merchanttransaction.blade.php ENDPATH**/ ?>