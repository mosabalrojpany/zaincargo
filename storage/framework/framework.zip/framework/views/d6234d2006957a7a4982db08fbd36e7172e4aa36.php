<?php $__env->startSection('content'); ?>


    <?php
    $showExtraFields = $order->state > 3 ? '' : 'd-none';
    ?>


    <!--  Start path  -->
    <div class="d-flex align-items-center bg-white mb-3 d-print-none">

        <nav class="col pr-0" aria-label="breadcrumb" role="navigation">
            <ol class="breadcrumb bg-white mb-0">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('cp/purchase-orders')); ?>">طلبات الشراء</a>
                </li>
                <li class="breadcrumb-item active text-truncate col pr-0 text-right" aria-current="page">
                    <span class="mr-1"><?php echo e($order->id); ?></span>
                </li>
            </ol>
        </nav>

        <div class="col-auto">

            <?php if($order->state == 5 || $order->state == 7): ?>
                <a href="<?php echo e(url('cp/purchase-orders/print', $order->id)); ?>" target="_blank"
                    class="btn btn-secondary btn-sm"><i class="fas fa-print"></i></a>
            <?php endif; ?>

            <?php if(hasRole('purchase_orders_edit')): ?>
            <?php if($order->state <= 5 || Auth::user()->branches_id == $order->branch_id): ?>
                <a href="<?php echo e(url('cp/purchase-orders/edit', $order->id)); ?>" class="btn btn-primary btn-sm">
                    <i class="fas fa-pen"></i>
                </a>
                <?php endif; ?>
            <?php endif; ?>

            <?php if(hasRole('purchase_orders_delete')): ?>
                <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteModal">
                    <i class="fas fa-trash"></i>
                </button>
            <?php endif; ?>
            <?php if($order->merchant_id == 0 && $order->state == 5): ?>
                <?php if(hasRole('merchant')): ?>
                    <button class="btn btn-primary btn-sm marchate" data-toggle="modal" data-active="0"
                        data-target="#Modal">
                        <i class="fas">احالة</i>
                    </button>
                <?php endif; ?>
            <?php endif; ?>

        </div>

    </div>
    <!--  End path  -->



    <div class="card card-shadow">

        
        <div class="card-header text-right bg-white pt-4">

            <div class="row">

                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">رقم الطلب</label>
                        <div class="col text-secondary"><?php echo e($order->id); ?></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">رقم العضوية</label>
                        <div class="col text-secondary"><bdi><?php echo e($order->customer->code); ?></bdi></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">اسم الزبون</label>
                        <div class="col text-secondary">
                            <a href="<?php echo e(url('cp/customers', $order->customer_id)); ?>"><?php echo e($order->customer->name); ?></a>
                        </div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">الحالة</label>
                        <div class="col text-secondary"><?php echo e($order->getState()); ?></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">تاريخ الإضافة</label>
                        <div class="col text-secondary"><bdi><?php echo e($order->created_at()); ?></bdi></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

                <?php if($order->isOrderDone()): ?>
                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px">تاريخ الشراء</label>
                            <div class="col text-secondary"><bdi><?php echo e($order->ordered_at()); ?></bdi></div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>
                <?php endif; ?>

                <?php if($order->isUserPaid()): ?>
                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px">تاريخ الدفع</label>
                            <div class="col text-secondary"><bdi><?php echo e($order->paid_at()); ?></bdi></div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>
                <?php endif; ?>

                <?php if($order->isOrderAccepted()): ?>

                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px">العملة</label>
                            <div class="col text-secondary"><b><?php echo e($order->currency->name); ?></b></div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>

                    <?php if (! ($order->isCurrencyEqualsMain())): ?>
                        <div class="col-md-6 col-lg-4 mb-3">
                            <div class="row">
                                <label class="col-auto w-125px">سعر الصرف</label>
                                <div class="col text-secondary"><b><?php echo e($order->exchange_rate); ?></b></div>
                            </div>
                            <div class="border-b mb-1"></div>
                        </div>
                    <?php endif; ?>

                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px">الإجمالي</label>
                            <div class="col text-secondary"><b><?php echo e($order->getCost()); ?></b></div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>

                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px">الضرائب</label>
                            <div class="col text-secondary"><b><?php echo e($order->tax); ?></b></div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>

                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px pl-0">الشحن الداخلي</label>
                            <div class="col text-secondary"><b><?php echo e($order->shipping); ?></b></div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>

                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px pl-0">عمولة الشراء</label>
                            <div class="col text-secondary"><b><?php echo e($order->fee); ?></b></div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>

                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px">التخفيض</label>
                            <div class="col text-secondary"><b><?php echo e($order->discount); ?></b></div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>

                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px pl-0">الصافي</label>
                            <div class="col"><b><?php echo e($order->getTotalCostByCurrency()); ?></b></div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>

                <?php endif; ?>

                <?php if($order->isUserPaid()): ?>

                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px">عملة الدفع</label>
                            <div class="col text-secondary"><b><?php echo e($order->paidCurrency->name); ?></b></div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>

                    <?php if (! ($order->isPaidCurrencyEqualsMain())): ?>
                        <div class="col-md-6 col-lg-4 mb-3">
                            <div class="row">
                                <label class="col-auto w-125px">سعر الصرف</label>
                                <div class="col text-secondary"><b><?php echo e($order->paid_exchange_rate); ?></b></div>
                            </div>
                            <div class="border-b mb-1"></div>
                        </div>
                    <?php endif; ?>

                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px">المدفوع</label>
                            <div class="col"><b><?php echo e($order->getPaidByCurrency()); ?></b></div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>

                <?php endif; ?>
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">التاجر</label>
                        <?php if($order->merchant_id > 0): ?>
                            <div class="col text-secondary">
                                <a
                                    href="<?php echo e(url('cp/customers', $order->customer2->id)); ?>"><?php echo e($order->customer2->name); ?>-<?php echo e($order->customer2->code); ?></a>
                            </div>
                        <?php else: ?>
                            <td>
                                لا يوجد
                            </td>
                        <?php endif; ?>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>


                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px pl-0">أضيفة بواسطة</label>
                        <div class="col text-secondary"><?php echo e($order->addedBy()); ?></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

            </div>

            <div class="row">
                <?php if($order->state >= 5): ?>
                    <div class="col-md-6 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px">سبب الرفض </label>
                            <div class="col text-secondary"><?php echo e($order->merchant_note); ?></div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>

                    <div class="col-md-6 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px">الفرع </label>
                            <div class="col text-secondary">
                                <?php if($order->branch_id != null): ?><?php echo e($order->branche->city); ?>

                                <?php else: ?> لا يوجد <?php endif; ?>
                            </div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>
                <?php endif; ?>

                <div class="col-md-6 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">ملاحظة</label>
                        <div class="col text-secondary"><?php echo e($order->note); ?></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

                <div class="col-md-6 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px pl-0">معلومات أخرى</label>
                        <div class="col text-secondary"><?php echo e($order->extra); ?></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>

            </div>

        </div>
        


        
        <div class="card-body">


            <table class="table table-center table-bordered text-center">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>الوصف</th>
                        <th>العدد</th>
                        <th class="<?php echo e($showExtraFields); ?>">السعر</th>
                        <th class="<?php echo e($showExtraFields); ?>">الضريبة</th>
                        <th class="<?php echo e($showExtraFields); ?>">الشحن</th>
                        <th>اللون</th>
                        <th>ملاحظة</th>
                        <th>الحالة</th>
                    </tr>
                </thead>
                <tbody>


                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <a target="_blank" href="<?php echo e($item->link); ?>"><?php echo e($item->desc); ?></a>
                            </td>
                            <td><?php echo e($item->count); ?></td>
                            <td class="<?php echo e($showExtraFields); ?>"><?php echo e($item->price); ?></td>
                            <td class="<?php echo e($showExtraFields); ?>"><?php echo e($item->tax); ?></td>
                            <td class="<?php echo e($showExtraFields); ?>"><?php echo e($item->shipping); ?></td>
                            <td style="background-color: <?php echo e($item->color); ?>;" title="<?php echo e($item->color); ?>">
                                <bdi class="order-item-color"><?php echo e($item->color); ?></bdi>
                            </td>
                            <td><?php echo e($item->note); ?></td>
                            <td>
                                <?php if($order->state == 3): ?>
                                    <span
                                        class="text-white no-wrap py-1 px-2 rounded bg-danger"><?php echo e($order->getState()); ?></span>
                                <?php else: ?>
                                    <span
                                        class="text-white no-wrap py-1 px-2 rounded bg-<?php echo e($item->getStateColor()); ?>"><?php echo e($item->getState()); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>


        </div>
        



    </div>




    
    <?php if(hasRole(['purchase_order_comments_show', 'purchase_order_comments_add'])): ?>

        <div class="card shadow border-0 mt-4 text-right">
            <div class="card-header bg-white py-3">
                <h4 class="mb-0">التعليقات</h4>
            </div>
            <div class="comments">

                <?php if(hasRole('purchase_order_comments_show')): ?>

                    <ul class="list-unstyled pr-0">

                        <?php $__currentLoopData = $order->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li id="<?php echo e($comment->id); ?>"
                                class="media p-4 <?php echo e($comment->customer_id ? 'customer' : ''); ?> <?php echo e(!$comment->userCanEditComment() && $comment->unread ? 'bg-light' : ''); ?>">

                                <img src="<?php echo e($comment->getImage()); ?>" class="ml-3 w-50px rounded-circle" alt="...">

                                <div class="media-body">

                                    <div class="row justify-content-between">
                                        <div class="col">
                                            <h5 class="my-0 f-18px font-weight-bold"><?php echo e($comment->getCommenter()); ?></h5>
                                            <span class="text-muted d-inline-block f-15px">
                                                <i class="far fa-clock ml-1"></i><bdi><?php echo e($comment->created_at()); ?></bdi>
                                            </span>
                                        </div>
                                        <div class="col-auto">

                                            <?php if(hasRole('purchase_order_comments_edit')): ?>

                                                <?php if($comment->userCanEditComment()): ?>
                                                    <button type="button" class="btn btn-primary btn-sm btnEditComment"
                                                        data-toggle="modal" data-target="#editCommentModal">
                                                        <i class="fas fa-pen fa-fx"></i>
                                                    </button>
                                                <?php elseif($comment->unread): ?>
                                                    <a href="<?php echo e(url('/cp/purchase-order-comments/update/state', $comment->id)); ?>"
                                                        class="btn btn-dark btn-sm text-white">
                                                        <i class="fas fa-check fa-fx"></i>
                                                    </a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(url('/cp/purchase-order-comments/update/state', $comment->id)); ?>"
                                                        class="btn btn-secondary btn-sm text-white">
                                                        <i class="fas fa-times fa-fx"></i>
                                                    </a>
                                                <?php endif; ?>

                                            <?php endif; ?>

                                            <?php if(hasRole('purchase_order_comments_delete')): ?>

                                                <button type="button" class="btn btn-danger btn-sm btnDeleteComment"
                                                    data-toggle="modal" data-target="#deleteCommentModal">
                                                    <i class="fas fa-trash fa-fx"></i>
                                                </button>

                                            <?php endif; ?>

                                        </div>
                                    </div>

                                    <p class="mt-1 mb-0 pre-wrap comment-content"><?php echo e($comment->comment); ?></p>
                                </div>

                            </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>

                <?php endif; ?>

                <?php if(hasRole('purchase_order_comments_add')): ?>

                    <form class="formSendAjaxRequest validate-on-click px-4 pb-4 pt-2"
                        action="<?php echo e(url('cp/purchase-order-comments')); ?>" method="POST" id="formAddComment"
                        focus-on="#formAddComment" refresh-seconds="1">

                        <div class="formResult my-3 text-center"></div>

                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>" />

                        <div class="form-group">
                            <h5 class="mb-3">إضافة تعليق</h5>
                            <textarea placeholder="محتوى التعليق ..." class="form-control" minlength="9" maxlength="500"
                                name="comment" rows="3" required></textarea>
                            <div class="invalid-feedback text-center">
                                <?php echo app('translator')->get('validation.between.string',['attribute'=>'التعليق','min'=> 9 ,'max'=>500]); ?></div>
                        </div>

                        <button type="submit" class="btn btn-primary w-100px">تعليق</button>
                    </form>

                <?php endif; ?>

            </div>
        </div>

    <?php endif; ?>
    




    <?php if(hasRole('purchase_order_comments_delete')): ?>

        <!--    Start Modal deleteCommentModal -->
        <div class="modal fade" id="deleteCommentModal" tabindex="-1" role="dialog"
            aria-labelledby="deleteCommentModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteCommentModalLabel">حذف تعليق</h5>
                        <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    </div>
                    <form class='formSendAjaxRequest' refresh-seconds='2' action="<?php echo e(url('/cp/purchase-order-comments')); ?>"
                        method="post">
                        <div class="modal-body text-right">
                            <div class="formResult text-center"></div>
                            <?php echo method_field('DELETE'); ?>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" />
                            هل أنت متأكد أنك تريد حذف التعليق ؟
                            <hr />
                            <p></p>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger">حذف</button>
                            <button type="button" class="btn btn-secondary mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--    End Modal deleteCommentModal -->

    <?php endif; ?>






    <?php if(hasRole('purchase_order_comments_edit')): ?>

        <!--    Start Modal editCommentModal -->
        <div class="modal fade" id="editCommentModal" tabindex="-1" role="dialog" aria-labelledby="editCommentModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editCommentModalLabel">تعديل تعليق</h5>
                        <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    </div>
                    <form class='formSendAjaxRequest validate-on-click' refresh-seconds='1'
                        action="<?php echo e(url('/cp/purchase-order-comments/edit')); ?>" method="post">
                        <div class="modal-body text-right">
                            <div class="formResult text-center"></div>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" />

                            <div class="form-group">
                                <textarea placeholder="محتوى التعليق ..." class="form-control" minlength="9" maxlength="500"
                                    name="comment" rows="8" required></textarea>
                                <div class="invalid-feedback text-center">
                                    <?php echo app('translator')->get('validation.between.string',['attribute'=>'التعليق','min'=> 9 ,'max'=>500]); ?></div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">تعديل</button>
                            <button type="button" class="btn btn-secondary mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--    End Modal editCommentModal -->

    <?php endif; ?>




    <?php if(hasRole('purchase_orders_delete')): ?>

        <!--    Start Modal deleteModal -->
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">حذف الطلب</h5>
                        <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    </div>
                    <form class='formSendAjaxRequest' redirect-to='<?php echo e(url('/cp/purchase-orders')); ?>' refresh-seconds='2'
                        action="<?php echo e(url('/cp/purchase-orders')); ?>" method="post">
                        <div class="modal-body text-right">
                            <div class="formResult text-center"></div>
                            <?php echo method_field('DELETE'); ?>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($order->id); ?>" />
                            هل أنت متأكد أنك تريد حذف الطلب ؟
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger">حذف</button>
                            <button type="button" class="btn btn-secondary mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--    End Modal deleteModal -->

    <?php endif; ?>

    <?php if(hasRole('merchant')): ?>
        <!--    Start Modal Modal احالة الى التاجر-->
        <div class="modal fade" id="Modal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalLabel">احالة فاتورة الى تاجر </h5>
                        <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form class='formSendAjaxRequest was-validated' refresh-seconds='2' action="<?php echo e(url('/cp/Merchant')); ?>"
                        method="post">
                        <div class="modal-body px-sm-5">
                            <div class="alert alert-warning text-right" id="alertMsgPassword">ادخل كود الزبون الدي لديه
                                خاصية
                                التاجر</div>
                            <div class="formResult text-center"></div>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($order->id); ?>" />
                            <div class="form-group row">
                                <label for="inputName" class="col-sm-auto w-125px col-form-label text-right">عضوية
                                    التاجر</label>
                                <div class="col-sm">
                                    <input type="text" name="merchant_id" class="form-control" id="inputmerchant_id"
                                        placeholder="عضوية التاجر" pattern=".{1,64}" required>
                                    <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',[
                                        'attribute'=>'العضوية','min'=> 1,'max'=>64]); ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">تحديث</button>
                            <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--    End Modal Modal -->
    <?php endif; ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra-js'); ?>

    <script>
        // #######################################################
                $('.paymentdone').click(function(e) {
                    $(".paymentdone").attr("disabled", true);
                    $(".removeorder").attr("disabled", true);
                    var form = $('#Modal form')[0];
                    var tr = $(this).closest('tr');
                    e.preventDefault();
                    $.ajax({
                        method: 'get',
                        url: "<?php echo e(url('client/merchant_prchase_order')); ?>",
                        data: {
                            '_token': "<?php echo e(csrf_token()); ?>",
                            state: 1,
                            id: $(form).find('input[name="id"]').val(),
                        },
                        success: function(result) {

                            setInterval(function() {
                                $(".paymentdone").attr("disabled", false);
                                $(".removeorder").attr("disabled", true);
                                location.reload();
                            }, 1500);
                        },
                        error: function(reject) {
                            $(".paymentdone").attr("disabled", false);
                            $(".removeorder").attr("disabled", true);
                            var response = $.parseJSON(reject.responseText);
                            $("#error4_error2").text(response.error1);
                            if (reject.status == 403) {
                                var response = $.parseJSON(reject.responseText);
                                $("#errors_error").text(response.errors);
                            }

                        }


                    });
                });
        // ########################################################
        $('.btnDeleteComment').click(function(){
            var commentBox = $(this).closest('.media');
            $('#deleteCommentModal form input[name="id"]').val($(commentBox).attr('id'));
            $('#deleteCommentModal form p').html($(commentBox).find('.comment-content').html());
        });

        $('.btnEditComment').click(function(){
            var commentBox = $(this).closest('.media');
            $('#editCommentModal form input[name="id"]').val($(commentBox).attr('id'));
            $('#editCommentModal form textarea').val($(commentBox).find('.comment-content').html());
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/purchase_orders/show.blade.php ENDPATH**/ ?>