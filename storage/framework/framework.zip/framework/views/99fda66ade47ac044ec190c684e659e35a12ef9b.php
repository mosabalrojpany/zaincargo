<?php $__env->startSection('content'); ?>



    <!--    Start header    -->
    <div class="d-flex justify-content-between">
        <h4 class="font-weight-bold">حركات خزينة الحوالات الداخلية للفروع</h4>
    </div>

    <!--    End header    -->




    <!--    Start show Roles   -->
    <table class="table text-center mt-4 bg-white">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">اسم الموظف</th>
                <th scope="col">الفرع</th>
                <th scope="col">القيمة</th>
                <th scope="col">نوع العملة</th>
                <th scope="col">ملاحظة</th>
                <th scope="col">التاريخ</th>
            </tr>
        </thead>
        <tbody>

            <!-- Start print Roles -->
            <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transactions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($transactions->employe_name); ?></td>
                    <td><?php echo e($transactions->branche->city); ?></td>
                    <td><?php echo e($transactions->price); ?></td>
                    <td><?php echo e($transactions->curancy_type); ?></td>
                    <td><?php echo e($transactions->note); ?></td>
                    <td><?php echo e($transactions->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End print Roles -->

        </tbody>
    </table>
    <!--    End show Roles   -->
        
        <div class="pagination-center"><?php echo e($transaction->links()); ?></div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/internal_transfaremoneybank_trnsaction.blade.php ENDPATH**/ ?>