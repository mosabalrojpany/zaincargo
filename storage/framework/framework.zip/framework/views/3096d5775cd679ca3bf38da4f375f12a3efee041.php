<?php $__env->startSection('content'); ?>


<!--  Start path  -->
<nav aria-label="breadcrumb" role="navigation">
    <ol class="breadcrumb bg-white">
        <li class="breadcrumb-item">
            <a href="<?php echo e(url('cp/purchase-orders')); ?>">طلبات الشراء</a>
        </li>
        <li class="breadcrumb-item active text-truncate col pr-0 text-right" aria-current="page">
            <span class="mr-1">طلب جديد</span>
        </li>
    </ol>
</nav>
<!--  End path  -->



<!--    Start header of Order   -->
<form class="formSendAjaxRequest card card-shadow was-validated" id="form-order" focus-on="#form-order"
     refresh-seconds="1"  action="<?php echo e(url('cp/purchase-orders')); ?>" method="POST">

    <?php echo csrf_field(); ?>

    
    <div class="card-header bg-white">

        <div class="formResult my-3 text-center"></div>


        <div class="row">

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputCode" class="col-auto w-125px col-form-label text-right">رقم العضوية</label>
                    <div class="col pr-md-0">
                        <input id="inputCode" type="text" pattern="\s*([^\s]\s*){1,12}" class="form-control" name="code" required>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'رقم العضوية','min'=> 1 ,'max'=>12]); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputState" class="col-auto w-125px col-form-label text-right">الحالة</label>
                    <div class="col pr-md-0">
                        <select id="inputState" name="state" class="form-control" required>
                            <option value="" selected>...</option>
                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            
            <div class="col-md-6 col-lg-4" id="orderedAtPlacer"></div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputOrderedAt" class="col-auto w-125px col-form-label text-right">تاريخ الشراء</label>
                    <div class="col pr-md-0">
                        <input type="date" max="<?php echo e(date('Y-m-d')); ?>" name="ordered_at" id="inputOrderedAt" class="form-control" >
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.before_or_equal',['attribute'=>'تاريخ الشراء','date'=> date('d/m/Y')]); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputPaidAt" class="col-auto w-125px col-form-label text-right">تاريخ الدفع</label>
                    <div class="col pr-md-0">
                        <input type="date" max="<?php echo e(date('Y-m-d')); ?>" name="paid_at" id="inputPaidAt" class="form-control" >
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.before_or_equal',['attribute'=>'تاريخ الدفع','date'=> date('d/m/Y')]); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputCurrency" class="col-auto w-125px col-form-label text-right">العملة</label>
                    <div class="col pr-md-0">
                        <select id="inputCurrency" name="currency" class="form-control" required>
                            <option value="" selected disabled>...</option>
                            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($currency->id); ?>" data-value="<?php echo e($currency->value); ?>" data-sign="<?php echo e($currency->sign); ?>"><?php echo e($currency->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputExchangeRate" class="col-auto w-125px pl-0 col-form-label text-right">سعر الصرف</label>
                    <div class="col pr-md-0">
                        <input type="number" min="0.000001" max="999999.00" step="any" name="exchange_rate" id="inputExchangeRate" class="form-control" required>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.min.numeric',['attribute'=>'سعر الصرف','min'=> 0.0001]); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label class="col-auto w-125px pl-0 col-form-label text-right">إجمالي الفاتورة</label>
                    <div class="col pr-md-0">
                        <input type="number" id="inputSumPrice" readonly class="form-control">
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label class="col-auto w-125px col-form-label text-right">الضرائب</label>
                    <div class="col pr-md-0">
                        <input type="number" id="inputSumTax" readonly class="form-control">
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label class="col-auto w-125px pl-0 col-form-label text-right">الشحن الداخلي</label>
                    <div class="col pr-md-0">
                        <input type="number" id="inputSumShipping" readonly class="form-control">
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputFee" class="col-auto w-125px col-form-label text-right">عمولة الشراء</label>
                    <div class="col pr-md-0">
                        <input type="number" min="0" step="any" name="fee" id="inputFee" class="form-control" required>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.min.numeric',['attribute'=>'العمولة','min'=> 0]); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputDiscount" class="col-auto w-125px col-form-label text-right">التخفيض</label>
                    <div class="col pr-md-0">
                        <input type="number" min="0" step="any" name="discount" id="inputDiscount" class="form-control" required>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.min.numeric',['attribute'=>'التخفيض','min'=> 0]); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label class="col-auto w-125px col-form-label text-right">الصافي</label>
                    <div class="col pr-md-0">
                        <input type="text" id="inputSumTotalCost" readonly class="form-control">
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputPaymentCurrency" class="col-auto w-125px col-form-label text-right">عملة الدفع</label>
                    <div class="col pr-md-0">
                        <select id="inputPaymentCurrency" name="payment_currency" class="form-control" required>
                            <option value="" selected disabled>...</option>
                            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($currency->id); ?>" data-value="<?php echo e($currency->value); ?>"><?php echo e($currency->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputPaidExchangeRate" class="col-auto w-125px pl-0 col-form-label text-right">سعر الصرف</label>
                    <div class="col pr-md-0">
                        <input type="number" min="0.000001" max="999999.00" step="any" name="paid_exchange_rate" id="inputPaidExchangeRate" class="form-control" required>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.min.numeric',['attribute'=>'سعر الصرف','min'=> 0.0001]); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="form-group row">
                    <label for="inputPaidUp" class="col-auto w-125px pl-0 col-form-label text-right">المدفوع</label>
                    <div class="col pr-md-0">
                        <input type="number" min="0" step="any" name="paid_up" id="inputPaidUp" class="form-control" required>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.min.numeric',['attribute'=>'المدفوع','min'=> 0]); ?></div>
                    </div>
                </div>
            </div>


            <div class="col-6">
                <div class="form-group row">
                    <label for="inputNote" class="col-auto w-125px col-form-label text-right">ملاحظة</label>
                    <div class="col pr-md-0">
                        <textarea name="note" id="inputNote" maxlength="150" rows="4" class="form-control" placeholder="ملاحظة لزبون"></textarea>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.max.string',['attribute'=>'ملاحظة','max'=>150]); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-6">
                <div class="form-group row">
                    <label for="inputExtra" class="col-auto w-125px col-form-label text-right">أخرى</label>
                    <div class="col pr-md-0">
                        <textarea name="extra" id="inputExtra" maxlength="150" rows="4" class="form-control" placeholder="معلومات إضافية خاصة بالنظام"></textarea>
                        <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.max.string',['attribute'=>'معلومات أخرى','max'=>150]); ?></div>
                    </div>
                </div>
            </div>

        </div>

    </div>
    



    
    <div class="card-body px-0">

        <h4 class="text-center bg-dark text-white p-2 mt-0 mb-4">محتويات الطلب</h4>

        <ul class="list-unstyled orders-list pr-0 text-right">

            

        </ul>

    </div>
    



    <!--    Start footer    -->
    <div class="card-footer d-flex align-items-center justify-content-between">
        <div class="form-group mb-0 pr-5">
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="customControlIamSure" required>
                <label class="custom-control-label" for="customControlIamSure">أنا متأكد</label>
            </div>
        </div>
        <button type="submit" class="btn btn-primary w-125px">حفظ</button>
    </div>
    <!--    End footer    -->


</form>
<!--    End header of Order   -->



<?php $__env->stopSection(); ?>



<?php $__env->startSection('extra-js'); ?>

    <?php echo $__env->make('CP.purchase_orders.create-edit-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>

            
            addItemInputEmptyWithStatusAdded();

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/purchase_orders/create.blade.php ENDPATH**/ ?>