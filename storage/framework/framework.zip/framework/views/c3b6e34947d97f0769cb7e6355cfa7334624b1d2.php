<?php $__env->startSection('content'); ?>



    <!--    Start header    -->
    <div class="d-flex justify-content-between">
        <h4 class="font-weight-bold">الحوالات الداخلية</h4>
    </div>
    <!--    End header    -->


        <!-- Start search  -->

        <div class="card-header bg-primary text-white">
            <form class="justify-content-between" action="<?php echo e(Request::url()); ?>" method="get">
                <input type="hidden" name="search" value="1">

                <div class="form-inline">
                    <span class="ml-2"><i class="fa fa-filter"></i></span>
                    <div class="form-group">
                        <label class="d-none" for="inputIdSearch">رقم الحوالة</label>
                        <input type="number" name="id" min="1" value="<?php echo e(Request::get('id')); ?>" placeholder="رقم الحوالة"
                            id="inputIdSearch" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group">
                        <label class="d-none" for="inputfrom_customer_idSearch">مرسلة من</label>
                        <input type="number" min="1" name="from_customer_id" value="<?php echo e(Request::get('from_customer_id')); ?>"
                            placeholder="مرسلة من" id="inputfrom_customer_idSearch" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group">
                        <label class="d-none" for="inputto_customer_idSearch">مرسلة الى</label>
                        <input type="search" maxlength="32" name="to_customer_id" value="<?php echo e(Request::get('to_customer_id')); ?>"
                            placeholder="مرسلة الى" id="inputto_customer_idSearch" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group">
                        <label class="d-none" for="inputStateSearch">مرسلة من فرع</label>
                        <select id="inputfrom_branchSearch" class="form-control mx-sm-2 setValue" style="width: 200px;"
                            name="from_branch" value="<?php echo e(Request::get('from_branch')); ?>">
                            <option value="">مرسلة من فرع</option>
                            <option value="1">طرابلس</option>
                            <option value="2">مصراته</option>
                            <option value="3">بنغازي</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="d-none" for="inputto_branchSearch">الى</label>
                        <select id="inputto_branchSearch" class="form-control mx-sm-2 setValue" style="width: 200px;"
                            name="to_branch" value="<?php echo e(Request::get('to_branch')); ?>">
                            <option value="">الى فرع</option>
                            <option value="1">طرابلس</option>
                            <option value="2">مصراته</option>
                            <option value="3">بنغازي</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                </div>


                
                <div class="form-inline mt-2">
                    <span class="ml-2"><i class="fa fa-filter"></i></span>
                    <div class="form-group">
                        <label class="d-none" for="inputcurancy_typeSearch">نوع العملة</label>
                        <select id="inputcurancy_typeSearch" class="form-control mx-sm-2 setValue" style="width: 220px;"
                            name="curancy_type" value="<?php echo e(Request::get('curancy_type')); ?>">
                            <option value="">نوع العملة</option>
                            <option value="1">دولار</option>
                            <option value="2">دينار</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="d-none" for="inputstateSearch">الحالة</label>
                        <select id="inputstateSearch" class="form-control mx-sm-2 setValue" style="width: 220px;"
                            name="state" value="<?php echo e(Request::get('state')); ?>">
                            <option value="">احالة</option>
                            <option value="2">تم التحويل</option>
                            <option value="3">تم الرفض</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="inputcreated_at_from"> تمت الاضافة من</label>
                        <input type="date" name="created_at_from" value="<?php echo e(Request::get('created_at')); ?>"
                            id="inputcreated_at_from" class="form-control mx-sm-2">
                    </div>
                    <div class="form-group">
                        <label for="inputcreated_at_to">إلى</label>
                        <input type="date" name="inputcreated_at_to" max="<?php echo e(date('Y-m-d')); ?>"
                            value="<?php echo e(Request::get('inputcreated_at_to')); ?>" id="inputcreated_at_to" class="form-control mx-sm-2">
                    </div>

                </div>
                
            </form>
        </div>

        <!-- End search  -->

    <!--    Start show Roles   -->
    <table class="table text-center mt-4 bg-white">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">رقم الحوالة</th>
                <th scope="col">من الزبون</th>
                <th scope="col">الى الزبون</th>
                <th scope="col">من فرع</th>
                <th scope="col">الى فرع</th>
                <th scope="col">القيمة</th>
                <th scope="col">نوع العملة</th>
                <th scope="col">الحالة</th>
                <th scope="col">ملاحظة</th>
                <th scope="col">التاريخ</th>
                <th scope="col">عمليات</th>
            </tr>
        </thead>
        <tbody>
            <!-- Start print Roles -->

            <?php $__currentLoopData = $trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfaremoney): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id='<?php echo e($transfaremoney->id); ?>'>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($transfaremoney->id); ?></td>
                    <td><?php echo e($transfaremoney->from_customer); ?></td>
                    <td><?php echo e($transfaremoney->to_customer); ?></td>
                    <td><?php echo e($transfaremoney->branche->city); ?></td>
                    <td><?php echo e($transfaremoney->branche2->city); ?></td>
                    <td><?php echo e($transfaremoney->price); ?></td>
                    <td><?php echo e($transfaremoney->currencytype->name); ?></td>
                    <td><?php echo e($transfaremoney->state()); ?></td>
                    <td><?php echo e($transfaremoney->note); ?></td>
                    <td><?php echo e($transfaremoney->created_at); ?></td>
                    <?php if($transfaremoney->state == 1): ?>
                    <td>
                        <button type="button" class="btn btn-primary btn-sm donewithtransfare" data-toggle="modal" data-target="#transfaremoneydone">
                            <i class="fas">اتمام التحويل</i>
                        </button>
                        <button type="button" class="btn btn-danger btn-sm cancelwithtransfare" data-toggle="modal" data-target="#transfaremoneycancel">
                            <i class="fas">رفض الحوالة</i>
                        </button>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End print Roles -->

        </tbody>
    </table>
    <!--    End show Roles   -->

    <!--    Start Modal Modal -->

 <div class="modal fade" id="transfaremoneydone" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ModalLabel">اتمام التحويل</h5>
                <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="formSendAjaxRequest" action="<?php echo e(url('/cp/donetrnsfare')); ?>" method="POST" refresh-seconds='2'>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" />
                <div class="alert-danger">
                    <small class="text-danger" id="wallet_id_error"></small>
                    <small id="errors_error" style="display: block;font-size: 16px;font-family: 'PhpDebugbarFontAwesome';text-align:center;"> هل تريد حقا اتمام التحويل</small>
                    </div>
                <div class="modal-body px-sm-5">
                        <div class="formResult text-center"></div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">تحديث</button>
                        <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!--    End Modal Modal -->


    <!--    Start Modal transfaremoneycancel -->

    <div class="modal fade" id="transfaremoneycancel" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ModalLabel">رفض التحويل</h5>
                    <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class="formSendAjaxRequest" action="<?php echo e(url('/cp/canceltrnsfare')); ?>" method="POST" refresh-seconds='2'>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" />
                    <div class="alert-danger">
                        <small class="text-danger" id="wallet_id_error"></small>
                        <small id="errors_error" style="display: block;font-size: 16px;font-family: 'PhpDebugbarFontAwesome';text-align:center;"> هل تريد حقا رفض هده الحوالة</small>

                        </div>


                    <div class="modal-body px-sm-5">
                            <div class="formResult text-center">
                            </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">نعم</button>
                            <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--    End Modal transfaremoneycancel -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>

            $('.donewithtransfare').click(function() {
                var form = $('#transfaremoneydone form')[0];
                var tr = $(this).closest('tr');
                $(form).find('input[name="id"]').val(tr.attr('id'));
            });
            $('.cancelwithtransfare').click(function() {
                var form = $('#transfaremoneycancel form')[0];
                var tr = $(this).closest('tr');
                $(form).find('input[name="id"]').val(tr.attr('id'));
            });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/internal_transfaremoney.blade.php ENDPATH**/ ?>