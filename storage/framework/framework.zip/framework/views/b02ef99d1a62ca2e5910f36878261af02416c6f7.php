<?php if(Session::has('success')): ?>
<div class="alert alert-primary" role="alert" style="margin-top: 10PX;text-align: center;">
  <?php echo e((Session::get('success'))); ?>  
  </div>
<?php endif; ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/elerts/success.blade.php ENDPATH**/ ?>