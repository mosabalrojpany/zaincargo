<?php $__env->startSection('content'); ?>

    <!--    Start path   -->
    <nav aria-label="breadcrumb" role="navigation" class="shadow">
        <ol class="breadcrumb bg-white">
            <li class="breadcrumb-item">
                <a href="<?php echo e(url('/cp/faqs')); ?>">الأسئلة الشائعة</a>
            </li>
            <li class="breadcrumb-item active text-truncate col pr-0 text-right" aria-current="page">نعديل سؤال</li>
        </ol>
    </nav>
    <!--    End path    -->


    <div class="card border-0 shadow">

        <div class="card-body">
                
            <!--    Start section insert data    -->
            <form id="form-post" class="text-right was-validated formSendAjaxRequest" redirect-to="<?php echo e(url('cp/faqs')); ?>" action="<?php echo e(url('cp/faqs/edit')); ?>" focus-on=".breadcrumb" refresh-seconds="1" method="POST">

                <div class="formResult text-center"></div>
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="id" value="<?php echo e($faq->id); ?>">


                <!--    Start main-inputs   -->
                <div class="form-group row mb-3 text-right">
                    <label class="col-sm-auto w-75px pl-0 col-form-label">السؤال</label>
                    <div class="col-sm">
                        <input type="text" class="form-control" value="<?php echo e($faq->question); ?>" name="question" placeholder="السؤال" pattern="\s*([\S]\s*){10,150}" required>
                        <div class="invalid-feedback text-center">
                            <?php echo app('translator')->get('messages.between.string',['attribute' =>'السؤال','min'=>10,'max'=>150]); ?>
                        </div> 
                    </div>
                </div>

                <div class="form-group row my-3">
                    <label class="col-sm-auto w-75px pl-0 col-form-label">الإجابة</label>
                    <div class="col-sm">
                        <textarea id="editor" name="answer" placeholder="الإجابة" minlength="12" class="form-control mt-3" required>
                            <?php echo $faq->answer; ?>

                        </textarea>
                    </div>
                </div>

                <div class="row justify-content-between mt-3">
                    <div class="col-md-4">
                        <div class="form-group row">
                            <label class="col-sm-auto w-75px pl-0 col-form-label">نشر</label>
                            <div class="col-sm">
                                <select name="state" class="form-control setValue" value="<?php echo e($faq->active); ?>" required>
                                    <option value="0">لا</option>
                                    <option value="1">نعم</option>
                                </select>
                            </div> 
                        </div>
                    </div>
                    <div class="col-md-auto">
                        <button type="submit" class="btn btn-primary w-200px">حفظ</button>
                    </div>
                </div>
                <!--    End main-inputs   -->

            </form>
            <!--    End section insert data    -->

        </div>

    </div>

            
<?php $__env->stopSection(); ?>

<?php echo $__env->make('CP.faqs.create-edit-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/faqs/edit.blade.php ENDPATH**/ ?>