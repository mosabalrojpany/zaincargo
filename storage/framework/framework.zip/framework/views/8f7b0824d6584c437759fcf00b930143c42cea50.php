<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between">
    <h4 class="font-weight-bold">المحفظة</h4>
</div>


<div class="card card-shadow my-4 text-center">
    <!-- Start search  -->
    <div class="card-header bg-primary text-white">
        <form class="justify-content-between" action="<?php echo e(Request::url()); ?> " method="get">
            <input type="hidden" name="search" value="1">
            <div class="form-inline">
                <span class="ml-2"><i class="fa fa-filter"></i></span>
                <div class="form-group">
                    <label class="d-none" for="inputCodeSearch">رقم العضوية</label>
                    <input type="number" min="1" name="code" value="<?php echo e(Request::get('code')); ?>" placeholder="رقم العضوية" id="inputCodeSearch" class="form-control mx-sm-2">
                </div>

                <div class="form-group">
                    <label class="d-none" for="inputgretherthanSearch">قيمة مالية</label>
                    <select id="inputgretherthanSearch" class="form-control mx-sm-2 setValue" style="width: 220px;"
                        name="gretherthan" value="<?php echo e(Request::get('gretherthan')); ?>">
                        <option value="" selected>لا شي</option>
                        <option value="1">طرابلس LY</option>
                        <option value="2">طرابلس $</option>
                        <option value="3">مصراته LY</option>
                        <option value="4">مصراته $</option>
                        <option value="5">بنغازي LY</option>
                        <option value="6">بنغازي $</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
            </div>


        </form>
    </div>
    <!-- End search  -->
    <?php echo $__env->make('CP.elerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('CP.elerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--    Start show orders   -->
    <form method="post" class="justify-content-between" action="<?php echo e(Request::url()); ?>" >
    <div class="card-body p-0" >
        <table class="table table-center table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">الزبون</th>
                    <th scope="col">طرابلس LY</th>
                    <th scope="col">طرابلس $</th>
                    <th scope="col">بنغازي LY</th>
                    <th scope="col">بنغازي $</th>
                    <th scope="col">مصراته LY</th>
                    <th scope="col">مصراته $</th>
                    <th scope="col">ملاحظة</th>
                </tr>
            </thead>
            <tbody>
                        <!-- Start print orders -->
                        <?php $__currentLoopData = $allwallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allwallett): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr id='<?php echo e($allwallett->id); ?>'>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td>
                                    <a href="<?php echo e(url('cp/customers',$allwallett->customer_id)); ?>">
                                        <bdi><?php echo e($allwallett->customer->name); ?>-<?php echo e($allwallett->customer->code); ?></bdi>
                                    </a>
                                </td>
                            <td><?php echo e($allwallett->money_denar_t); ?></td>
                            <td><?php echo e($allwallett->money_dolar_t); ?></td>
                            <td><?php echo e($allwallett->money_denar_b); ?></td>
                            <td><?php echo e($allwallett->money_dolar_b); ?></td>
                            <td><?php echo e($allwallett->money_denar_m); ?></td>
                            <td><?php echo e($allwallett->money_dolar_m); ?></td>
                            <td><?php echo e($allwallett->note); ?><bdi></bdi></td>
                            <?php if(hasRole('user_wallet_show','user_wallet_index')): ?>
                                    <td>
                                        <a href="<?php echo e(url('cp/wallet/show',$allwallett->id)); ?>" class="btn btn-primary btn-sm">
                                            <i class="fas">دخول</i>
                                        </a>
                                    </td>
                            <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- End print orders -->
            </tbody>
        </table>
    </div>
</form>
    <!--    End show orders   -->
</div>


<div class="pagination-center"><?php echo e($allwallet->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/customer_wallet/index.blade.php ENDPATH**/ ?>