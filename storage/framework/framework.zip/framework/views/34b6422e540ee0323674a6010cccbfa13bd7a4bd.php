<?php $__env->startSection('content'); ?>



    <!--    Start header    -->
    <div class="d-flex justify-content-between">
        <h4 class="font-weight-bold">خزينة الحوالات الداخلية للفروع</h4>
    </div>
    <div class="d-flex justify-content-between">
        <?php if(hasRole('internal_transfaremoney_bank_depo')): ?>
        <button class="btn btn-primary btnAdd w-200px" data-toggle="modal" data-active="0" data-target="#AddmoneeytobankbranchModal">
            <i class="fas fa-plus mx-1"></i>اضافة رأس مال
        </button>
        <?php endif; ?>

        <?php if(hasRole('internal_transfaremoney_bank_wather')): ?>
        <button class="btn btn-primary btnAdd w-200px" data-toggle="modal" data-active="0" data-target="#WithdrawalfrombankbranchModal">
            <i class="fas fa-plus mx-1"></i>سحب من رأس المال
        </button>
        <?php endif; ?>

        <?php if(hasRole('internal_transfaremoney_bank_watherearning')): ?>
        <button class="btn btn-primary btnAdd w-200px" data-toggle="modal" data-active="0" data-target="#WithdrawalfromerningModal">
            <i class="fas fa-plus mx-1"></i>سحب من الارباح
        </button>
        <?php endif; ?>
    </div>
    <!--    End header    -->




    <!--    Start show Roles   -->
    <table class="table text-center mt-4 bg-white">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">الفرع</th>
                <th scope="col">الخزينة دينار</th>
                <th scope="col">الخزينة دولار</th>
                <th scope="col"> الارباح دينار</th>
                <th scope="col"> الارباح دولار</th>
            </tr>
        </thead>
        <tbody>

            <!-- Start print Roles -->
            <?php $__currentLoopData = $branchbank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branchbanks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($branchbanks->branche->city); ?></td>
                    <td><?php echo e($branchbanks->cost_dener); ?></td>
                    <td><?php echo e($branchbanks->cost_dolar); ?></td>
                    <td><?php echo e($branchbanks->erning_denar); ?></td>
                    <td><?php echo e($branchbanks->erning_dolar); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End print Roles -->

        </tbody>
    </table>
    <!--    End show Roles   -->

    <!--    Start Modal Modal -->
    <?php if(hasRole('internal_transfaremoney_bank_depo')): ?>

<div class="modal fade" id="AddmoneeytobankbranchModal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ModalLabel">اضافة رأس مال</h5>
                <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="formSendAjaxRequest" action="<?php echo e(url('/cp/transbranchbank')); ?>" method="POST" refresh-seconds='2'>
                <?php echo csrf_field(); ?>
                <div class="alert-danger">
                    <small class="text-danger" id="wallet_id_error"></small>
                    <small  id="errors_error" style="display: block;font-size: 16px;font-family: 'PhpDebugbarFontAwesome';text-align:center;"></small>
                    </div>
                <div class="modal-body px-sm-5">
                        <div class="formResult text-center"></div>
                        <div class="form-group row">
                            <label for="branche_id" class="col-sm-auto w-125px col-form-label text-right">الفرع</label>
                            <div class="col-sm">
                                <select id="branche_id" name="branche_id" class="form-control" >
                                    <option value="" selected>اختر...</option>
                                <?php $__currentLoopData = $branchbank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branches): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($branches->branche->id); ?>"><?php echo e($branches->branche->city); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <small class="text-danger" id="branche_id_error" style="display: flex;"></small>
                            </div>
                            <small class="text-danger" id="branche_id_error"></small>
                        </div>
                        <div class="form-group row">
                            <label for="curance_type_id" class="col-sm-auto w-125px col-form-label text-right">نوع العملة</label>
                            <div class="col-sm">
                                <select id="curance_type_id" name="curance_type_id" class="form-control" >
                                    <option value="" selected>اختر...</option>
                                <option value="1">دينار</option>
                                <option value="2">دولار</option>
                                </select>
                                <small class="text-danger" id="curance_type_id_error" style="display: flex;"></small>
                            </div>
                            <small class="text-danger" id="carancytype_error"></small>
                        </div>
                        <div class="form-group row">
                            <label for="price" class="col-sm-auto w-125px col-form-label text-right">القيمة</label>
                            <div class="col-sm">
                                <input type="text" name="price" class="form-control" id="price" placeholder="القيمة">
                                <small class="text-danger" id="price_error" style="display: flex;" ></small>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="note" class="col-sm-auto w-125px pl-0 col-form-label text-right">ملاحظة</label>
                            <div class="col-sm">
                                <input type="text" name="note" class="form-control" id="note" placeholder="ملاحظة">
                                <small class="text-danger" id="note_error" style="display: flex;"></small>
                            </div>
                        </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">تحديث</button>
                        <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!--    End Modal Modal -->

    <!--    Start Modal Modal -->
    <?php if(hasRole('internal_transfaremoney_bank_wather')): ?>

    <div class="modal fade" id="WithdrawalfrombankbranchModal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ModalLabel">سحب من رأس المال</h5>
                    <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class="formSendAjaxRequest" action="<?php echo e(url('/cp/transbranchbank/Withdrawal')); ?>" method="POST" refresh-seconds='2'>
                    <?php echo csrf_field(); ?>
                    <div class="alert-danger">
                        <small class="text-danger" id="wallet_id_error"></small>
                        <small  id="errors_error" style="display: block;font-size: 16px;font-family: 'PhpDebugbarFontAwesome';text-align:center;"></small>
                        </div>
                    <div class="modal-body px-sm-5">
                            <div class="formResult text-center"></div>
                            <div class="form-group row">
                                <label for="branche_id" class="col-sm-auto w-125px col-form-label text-right">الفرع</label>
                                <div class="col-sm">
                                    <select id="branche_id1" name="branche_id" class="form-control" >
                                        <option value="" selected>اختر...</option>
                                    <?php $__currentLoopData = $branchbank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branches): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($branches->branche->id); ?>"><?php echo e($branches->branche->city); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <small class="text-danger" id="branche_id_error" style="display: flex;"></small>
                                </div>
                                <small class="text-danger" id="branche_id_error"></small>
                            </div>
                            <div class="form-group row">
                                <label for="curance_type_id" class="col-sm-auto w-125px col-form-label text-right">نوع العملة</label>
                                <div class="col-sm">
                                    <select id="curance_type_id1" name="curance_type_id" class="form-control" >
                                        <option value="" selected>اختر...</option>
                                    <option value="1">دينار</option>
                                    <option value="2">دولار</option>
                                    </select>
                                    <small class="text-danger" id="curance_type_id_error" style="display: flex;"></small>
                                </div>
                                <small class="text-danger" id="carancytype_error"></small>
                            </div>
                            <div class="form-group row">
                                <label for="price" class="col-sm-auto w-125px col-form-label text-right">القيمة</label>
                                <div class="col-sm">
                                    <input type="text" name="price" class="form-control" id="price1" placeholder="القيمة">
                                    <small class="text-danger" id="price_error" style="display: flex;" ></small>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="note" class="col-sm-auto w-125px pl-0 col-form-label text-right">ملاحظة</label>
                                <div class="col-sm">
                                    <input type="text" name="note" class="form-control" id="note1" placeholder="ملاحظة">
                                    <small class="text-danger" id="note_error" style="display: flex;"></small>
                                </div>
                            </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">تحديث</button>
                            <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!--    End Modal Modal -->

        <!--    Start Modal Modal -->
        <?php if(hasRole('internal_transfaremoney_bank_watherearning')): ?>

        <div class="modal fade" id="WithdrawalfromerningModal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true" style="display: none;">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalLabel">سحب من الارباح</h5>
                        <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form class="formSendAjaxRequest" action="<?php echo e(url('/cp/transbranchbank/Withdrawalfromearning')); ?>" method="POST" refresh-seconds='2'>
                        <?php echo csrf_field(); ?>
                        <div class="alert-danger">
                            <small class="text-danger" id="wallet_id_error"></small>
                            <small  id="errors_error" style="display: block;font-size: 16px;font-family: 'PhpDebugbarFontAwesome';text-align:center;"></small>
                            </div>
                        <div class="modal-body px-sm-5">
                                <div class="formResult text-center"></div>
                                <div class="form-group row">
                                    <label for="branche_id" class="col-sm-auto w-125px col-form-label text-right">الفرع</label>
                                    <div class="col-sm">
                                        <select id="branche_id2" name="branche_id" class="form-control" >
                                            <option value="" selected>اختر...</option>
                                        <?php $__currentLoopData = $branchbank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branches): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($branches->branche->id); ?>"><?php echo e($branches->branche->city); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <small class="text-danger" id="branche_id_error" style="display: flex;"></small>
                                    </div>
                                    <small class="text-danger" id="branche_id_error"></small>
                                </div>
                                <div class="form-group row">
                                    <label for="curance_type_id" class="col-sm-auto w-125px col-form-label text-right">نوع العملة</label>
                                    <div class="col-sm">
                                        <select id="curance_type_id2" name="curance_type_id" class="form-control" >
                                            <option value="" selected>اختر...</option>
                                        <option value="1">دينار</option>
                                        <option value="2">دولار</option>
                                        </select>
                                        <small class="text-danger" id="curance_type_id_error" style="display: flex;"></small>
                                    </div>
                                    <small class="text-danger" id="carancytype_error"></small>
                                </div>
                                <div class="form-group row">
                                    <label for="price" class="col-sm-auto w-125px col-form-label text-right">القيمة</label>
                                    <div class="col-sm">
                                        <input type="text" name="price" class="form-control" id="price2" placeholder="القيمة">
                                        <small class="text-danger" id="price_error" style="display: flex;" ></small>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="note" class="col-sm-auto w-125px pl-0 col-form-label text-right">ملاحظة</label>
                                    <div class="col-sm">
                                        <input type="text" name="note" class="form-control" id="note2" placeholder="ملاحظة">
                                        <small class="text-danger" id="note_error" style="display: flex;"></small>
                                    </div>
                                </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">تحديث</button>
                                <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <!--    End Modal Modal -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/internal_transfaremoneybank.blade.php ENDPATH**/ ?>