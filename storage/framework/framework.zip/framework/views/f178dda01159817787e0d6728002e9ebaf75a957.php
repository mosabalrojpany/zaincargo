<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel="icon" type="image/png"   href="<?php echo e(url('images/logo.png')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/sheets-of-paper.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;400;900&display=swap" rel="stylesheet">
</head>

<body class="document" style="font-family: Cairo">

    <style>

        /* arabic */

        @font-face {
            font-family: 'Tajawal';
            font-style: normal;
            font-weight: 400;
            src: url( <?php echo e(url('fonts/Tajawal/Tajawal-Medium.ttf')); ?> );
        }

        body {
            direction: rtl;
            font-family: Tajawal;
        }

        .header {
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            padding-bottom: 20px;
            border-bottom: 1px solid #000;
            margin-bottom: 20px;
        }

        .header img {
            height: 80px;
        }
        .header .title {
            font-size: 24px;
            text-align: right;
            padding-right: 10px;
            margin: 0;
        }
        .page-title {
            text-align: center;
            font-size: 18px;
            text-decoration: underline;
            text-underline-position: under;
        }
        .info {
            display: flex;
            justify-content: space-between;
        }
        .info ul {
            padding: 0;
            list-style: none;
            max-width: 50%;
        }
        .info ul li {
            line-height: 1.5;
        }
        .table {
            width: 100%;
            text-align: center;
            border-collapse: collapse;
        }
        .table th , .table td {
            padding: 7px;
            border: 1px solid #ddd;
        }
        .footer ul {
            padding: 0;
            list-style: none;
        }
        .footer ul li {
            line-height: 1.5;
        }
        .footer{
            margin-top: 450px;
        }
    </style>
    <div class="page">
        <div class="header">
            <img src="<?php echo e(url('images/logo-with-title-black.png')); ?>" />
        </div>
    <h2 class="page-title"> كشف حساب </h2>
        <div class="info">
            <ul>
                <li><b>رقم العضوية / <?php echo e($customerr->customer->code); ?> </b><bdi></bdi></li>
                <li><b>اسم الزبون /<?php echo e($customerr->customer->name); ?> </b></li>
            </ul>
        </div>
                        
                        <div class="card-body" style="margin-bottom: 50px; margin-top: 50px;">


                            <table class="table table-center table-bordered text-center">
                                <thead>
                                    <tr>
                                        
                                        <th>LY طرابلس</th>
                                        <th>$ طرابلس</th>
                                        <th>LY بنغازي</th>
                                        <th>$ بنغازي</th>
                                        <th>LY مصراته</th>
                                        <th>$ مصراته</th>
                                    </tr>
                                </thead>
                                <tbody>
                  
                                
                
                                   
                                    <tr> 
                                        <td><?php echo e($customerr->money_denar_t); ?></td>
                                        <td><?php echo e($customerr->money_dolar_t); ?></td>
                                        <td><?php echo e($customerr->money_denar_b); ?></td>
                                        <td><?php echo e($customerr->money_dolar_b); ?></td>
                                        <td><?php echo e($customerr->money_denar_m); ?></td>
                                        <td><?php echo e($customerr->money_dolar_m); ?></td>
                                    </tr>
        
                                </tbody>
                            </table>
        
                        </div>
                        
        
                        
        <div class="card-body" style="margin-top: 50px">
        <div class="details">
            <table class="table">
                <thead>
                    <tr>
                        <th>الرقم</th>
                        <th>النوع</th>
                        <th>الفرع</th>
                        <th>القيمة</th>
                        <th>نوع العملة</th>
                        <th>التاريخ</th>
                        <th>ملاحظة</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                        <tr>
                        <td><?php echo e($item->id); ?> </td>
                        <td><?php echo e($item->depositytypee()); ?></td>
                        <td><?php echo e($item->branchess->city); ?></td>
                        <td><?php echo e($item->price); ?></td>
                        <td><?php echo e($item->currencytype->name); ?></td>
                        <td><?php echo e($item->created_at); ?></td>
                            <td style="background-color: ;">
                            <bdi style="background-color: #fff;padding:2px;"><?php echo e($item->note); ?></bdi>
                            </td>
                        </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        </div>


    <script>
        print();
    </script>

</body>

</html>
<?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/customer_wallet/print2.blade.php ENDPATH**/ ?>