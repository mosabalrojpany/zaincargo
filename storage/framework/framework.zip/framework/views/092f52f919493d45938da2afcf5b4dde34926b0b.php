<?php $__env->startSection('content'); ?>
 

    <!--    Start header    -->
    <div class="d-flex justify-content-between">
        <h4 class="font-weight-bold">حركات الدخول <?php echo e(number_format($logins->total())); ?></h4> 
    </div>
    <!--    End header    -->
    
     
    <!--    show errors if they exist   -->
    <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <!--    Start show Logins   -->
    <div class="card mt-3">

        
        <!-- Start search  -->
        <div class="card-header bg-primary text-white"> 
            <form class="row justify-content-between" action="<?php echo e(Request::url()); ?>"  method="get">
                <input type="hidden" name="search" value="1" />
                <div class="form-inline col-auto">
                    <div class="form-group">
                        <label for="inputShowSearch">عرض</label>
                        <select id="inputShowSearch" name="show" class="form-control mx-sm-2 setValue" value="<?php echo e(Request::get('show')); ?>">
                            <option value="25"selected>25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                            <option value="250" >250</option>
                            <option value="500">500</option>
                            <option value="750">750</option>
                            <option value="1000">1000</option>
                        </select>
                    </div>
                </div>
                <div class="form-inline col-auto">
                    <span class="ml-4"><i class="fa fa-filter"></i></span>
                    <div class="form-group">
                        <label for="inputFromSearch">من</label>
                        <input type="date" id="inputFromSearch" name='from' value="<?php echo e(Request::get('from')); ?>" style="min-width: 195px;" max="<?php echo e(date('Y-m-d')); ?>" class="form-control mx-sm-2">
                    </div> 
                    <div class="form-group">
                        <label for="inputToSearch">إلى</label>
                        <input type="date" id="inputToSearch" name='to' value="<?php echo e(Request::get('to')); ?>" style="min-width: 195px;" max="<?php echo e(date('Y-m-d')); ?>" class="form-control mx-sm-2">
                    </div>  
                    <div class="form-group">
                        <label for="inputExtraSearch">المستخدم</label>
                        
                        <select class="form-control mx-sm-2 setValue" value="<?php echo e(Request::get('user')); ?>" name='user' required>
                            <option value="0" selected>الكل</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($u->id); ?>"><?php echo e($u->name); ?></option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                     </div>  
                    
                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                </div>
            </form> 
        </div>
        <!-- End search  -->
    
 
        <!--    Start table data    -->
        <div class="card-body">

            <table class="table table-striped text-center">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">المستخدم</th>
                        <th scope="col">نظام التشغيل</th>
                        <th scope="col">المتصفح</th>
                        <th scope="col">البلد</th>
                        <th scope="col">المدينة</th>
                        <th scope="col">ip</th>
                        <th scope="col">الدخول</th>
                        <th scope="col">أخر وصول</th>
                    </tr>
                </thead>
                <tbody>

                    <!-- start print items -->
                    <?php $__currentLoopData = $logins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $login): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e(1+$loop->index); ?></th>
                        <td><a href="<?php echo e(url('/cp/users#'.$login->user->id)); ?>"><?php echo e($login->user->name); ?></a></td>
                        <td><?php echo e($login->os); ?></td>
                        <td><?php echo e($login->browser); ?></td>
                        <td><?php echo e($login->country); ?></td>
                        <td><?php echo e($login->city); ?></td>
                        <td><?php echo e($login->ip); ?></td>
                        <td><bdi><?php echo e($login->log_in->format('Y-m-d g:ia')); ?></bdi></td>
                        <td><bdi><?php echo e($login->log_out->format('Y-m-d g:ia')); ?></bdi></td> 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <!-- End print items -->

                </tbody>
            </table>

        </div>
        <!--    Start table data    -->

        
    </div>
    <!--    End show Logins   -->


    <!--    pagination    -->
    <div class="pagination-center mt-4"><?php echo e($logins->links()); ?></div>

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/logins.blade.php ENDPATH**/ ?>