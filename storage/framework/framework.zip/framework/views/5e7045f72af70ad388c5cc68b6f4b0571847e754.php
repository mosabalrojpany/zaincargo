<?php $__env->startSection('subject'); ?>
    <?php echo e($subject); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    
    <p>
        تم استلام شحنة لك على العنوان <b><bdi><?php echo e($shipment->address->name); ?></bdi></b>
        من <b><bdi><?php echo e($shipment->address->country->name); ?></bdi></b>
    </p>
        
    <table style="margin-top: 20px; border: 1px solid #333; width: 100%; text-align: center; border-collapse: collapse;">
        <thead>
            <tr style="background-color: #1f415f; color: #fff; height: 36px;">
                <th style="border: 1px solid #999;">رمز الشحنة</th>
                <th style="border: 1px solid #999;">رقم التتبع</th>
                <th style="border: 1px solid #999;">الوزن</th>
                <th style="border: 1px solid #999;">الأبعاد</th>
            </tr>
        </thead>
        <tbody>
            <tr style="height: 34px;">
                <td style="border: 1px solid #999;"><bdi><?php echo e($shipment->shipment_code); ?></bdi></td>
                <td style="border: 1px solid #999;"><bdi><?php echo e($shipment->tracking_number); ?></bdi></td>
                <td style="border: 1px solid #999;">kg<bdi><?php echo e($shipment->weight); ?></bdi></td>
                <td style="border: 1px solid #999;"><bdi><?php echo e($shipment->length.'x'.$shipment->width.'x'.$shipment->height); ?></bdi></td>
            </tr>
        </tbody>
    </table>

    <p>
        للاطلاع على تفاصيل الشحنة الرجاء الدخول إلى حسابك أو  
        <b>
            <a target="_blank" href="<?php echo e(url('client/shipping-invoices',$shipment->id)); ?>">اضغط هنا لعرض الشحنة</a>.
        </b>
    </p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('emails.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/emails/shipment/receive.blade.php ENDPATH**/ ?>