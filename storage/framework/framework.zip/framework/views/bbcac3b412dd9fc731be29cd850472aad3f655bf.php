<?php $__env->startSection('subject'); ?>
    <?php echo e($subject); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <p>
        تم استلام طلب انضمامك إلينا , سيتم مراجعة بياناتك وسنرد عليك في أقرب فرصة ممكنة
    </p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('emails.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/emails/customers/register.blade.php ENDPATH**/ ?>