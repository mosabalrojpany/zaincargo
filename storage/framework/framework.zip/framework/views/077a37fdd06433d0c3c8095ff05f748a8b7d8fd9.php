<?php $__env->startSection('content'); ?>


    
    <div class="d-flex align-items-center justify-content-between mb-3">

        <nav aria-label="breadcrumb" role="navigation">
            <ol class="breadcrumb mb-0" style="background-color: transparent">
                <li class="breadcrumb-item"> 
                    <h4 class="mb-0">
                        <a class="text-decoration-none" href="<?php echo e(url('client/money-transfers')); ?>">حوالات مالية</a> 
                    </h4>
                </li>
                <li class="breadcrumb-item active text-truncate col pr-0 text-right" aria-current="page">
                    <h4 class="mr-1 mb-0 d-inline-block"><?php echo e($transfer->id); ?></h4>
                </li>
            </ol>
        </nav>

        
        <?php if($transfer->state == 1): ?>
            <div class="col-auto">
                <a href="<?php echo e(url('client/money-transfers/edit',$transfer->id)); ?>" class="btn btn-primary"><i class="fas fa-pen ml-1"></i>تعديل</a>        
            </div>
        <?php endif; ?>

    </div>
    



<div class="card card-shadow">

    
    <div class="card-header bg-white pt-4 text-right">

        
        <div class="row">

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">رقم الحوالة</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->id); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">الحالة</label>
                    <div class="col text-secondary"><?php echo e($transfer->getState()); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">البلد</label>
                    <div class="col text-secondary"><?php echo e($transfer->country->name); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">المدينة</label>
                    <div class="col text-secondary"><?php echo e($transfer->city->name); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

        </div>
        

        <hr/>

        
        <div class="row">
            
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">اسم المستلم</label>
                    <div class="col text-secondary"><?php echo e($transfer->recipient); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">رقم الهاتف</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->phone); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">رقم الهاتف 2</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->phone2); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
        
        </div>
        

        <hr/>

        
        <div class="row">

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">نوع المستلم</label>
                    <div class="col text-secondary"><?php echo e($transfer->getRecipientType()); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">ملف</label>
                    <div class="col text-secondary">
                        <?php if($transfer->file): ?>
                            <a href="<?php echo e($transfer->getFile()); ?>" target="_blank">عرض الملف</a>
                        <?php else: ?>
                            لا يوجد ملف
                        <?php endif; ?>
                    </div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

        </div>
        

        <hr/>
        
        
        <div class="row">
            
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">العمولة على</label>
                    <div class="col text-secondary"><b><?php echo e($transfer->getFeeOn()); ?></b></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
            
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px pl-0">طريقة الاستلام</label>
                    <div class="col text-secondary"><?php echo e($transfer->getRecevingMethod()); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">العملة</label>
                    <div class="col text-secondary"><?php echo e($transfer->currency->name); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">المبلغ</label>
                    <div class="col text-secondary"><b><?php echo e($transfer->amount); ?></b></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">العمولة</label>
                    <div class="col text-secondary"><b><?php echo e($transfer->fee); ?></b></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">الإجمالي</label>
                    <div class="col text-secondary"><b><?php echo e($transfer->getTotalByCurrency()); ?></b></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
            
        </div>
        


        <?php if($transfer->account_number): ?>

            <hr/>

            
            <div class="row">
                    
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="row">
                        <label class="col-auto w-125px">رقم الحساب</label>
                        <div class="col text-secondary"><bdi><?php echo e($transfer->account_number); ?></bdi></div>
                    </div>
                    <div class="border-b mb-1"></div>
                </div>
                
                <?php if($transfer->account_number2): ?>
                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px pl-0">رقم الحساب 2</label>
                            <div class="col text-secondary"><bdi><?php echo e($transfer->account_number2); ?></bdi></div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>
                <?php endif; ?>

                <?php if($transfer->account_number3): ?>
                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="row">
                            <label class="col-auto w-125px pl-0">رقم الحساب 3</label>
                            <div class="col text-secondary"><bdi><?php echo e($transfer->account_number3); ?></bdi></div>
                        </div>
                        <div class="border-b mb-1"></div>
                    </div>
                <?php endif; ?>

            </div>
            

        <?php endif; ?>

        <hr/>

        
        <div class="row">
            
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">تاريخ الطلب</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->created_at()); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>

            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">تاريخ التحويل</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->converted_at()); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
            
            <div class="col-md-6 col-lg-4 mb-3">
                <div class="row">
                    <label class="col-auto w-125px">تاريخ الاستلام</label>
                    <div class="col text-secondary"><bdi><?php echo e($transfer->received_at()); ?></bdi></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
    
        </div>
        

        
        
        <?php if($transfer->note): ?>
            
            <hr/>
            
            <div class="mb-3">
                <div class="row">
                    <label class="col-auto w-125px">ملاحظة</label>
                    <div class="col text-secondary"><?php echo e($transfer->note); ?></div>
                </div>
                <div class="border-b mb-1"></div>
            </div>
        
        <?php endif; ?>
        
    
    </div>
    

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/Client/money_transfers/show.blade.php ENDPATH**/ ?>