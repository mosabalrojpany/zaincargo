<?php $__env->startSection('content'); ?>



<div class="container my-5">

    <!--    Start header    -->
    <div class="d-flex justify-content-between">
        <h4 class="font-weight-bold">العناوين <?php echo e($addresses->total()); ?></h4>

        <?php if(hasRole('addresses_add')): ?>
            <button class="btn btn-primary btnAdd w-100px" data-toggle="modal" data-active="0" data-target="#Modal">
                <i class="fas fa-plus mx-1"></i>أضف
            </button>
        <?php endif; ?>

    </div>
    <!--    End header    -->

    

    <div class="row mt-5">

        

        <!--    Start search box     -->
        <aside class="col-lg-4 col-xl-3 mb-5 text-right">
            <form action="<?php echo e(Request::url()); ?>">
                <input type="hidden" name="search" value="1" />   
                <div class="form-group">
                    <label>الاسم بالكامل</label>
                    <input type="search" value="<?php echo e(Request::get('fullname')); ?>" name="fullname" maxlength="32" class="form-control" />
                </div> 
                <div class="form-group">
                    <label>البلد</label>
                    <select name="country" id="inputCountrySearch" class="form-control setValue" value="<?php echo e(Request::get('country')); ?>">
                        <option value="" selected>الكل</option>
                        
                    </select>
                </div> 
                <div class="form-group">
                    <label>المدينة</label>
                    <select name="city" id="inputCitySearch" class="form-control setValue" value="<?php echo e(Request::get('city')); ?>">
                        <option value="" selected>الكل</option>
                        
                    </select>
                </div> 
                <div class="form-group">
                    <label>النوع</label>
                    <select name="type" class="form-control setValue" value="<?php echo e(Request::get('type')); ?>">
                        <option value="" selected>الكل</option>  
                        <option value="1">جوي</option>  
                        <option value="2">بحري</option>  
                    </select>
                </div> 
                <div class="form-group">
                    <label>الحالة</label>
                    <select name="state" class="form-control setValue" value="<?php echo e(Request::get('state')); ?>">
                        <option value="" selected>الكل</option>  
                        <option value="1">فعال</option>  
                        <option value="0">غير فعال</option>  
                    </select>
                </div>   
                <div class="form-group">
                    <label>ملاحظة</label>
                    <input type="search" value="<?php echo e(Request::get('note')); ?>" name="note" maxlength="32" class="form-control" />
                </div>    
                <div class="form-group">
                    <label>معلومات أخرى</label>
                    <input type="search" value="<?php echo e(Request::get('extra')); ?>" name="extra" maxlength="32" class="form-control" />
                </div> 
                <div class="form-group">
                    <label>أضيف من</label>
                    <input type="date" value="<?php echo e(Request::get('from')); ?>" max="<?php echo e(date('Y-m-d')); ?>" name="from" class="form-control" />
                </div>
                <div class="form-group">
                    <label>أضيف إلى</label>
                    <input type="date" value="<?php echo e(Request::get('to')); ?>" max="<?php echo e(date('Y-m-d')); ?>" name="to" class="form-control" />
                </div> 
                <button type="submit" class="btn btn-primary btn-block mt-2">بحث</button>
            </form>
        </aside>
        <!--    End search box     -->


        
        <?php
            $canEdit =  hasRole('addresses_edit')        
        ?>

        <!--    Start show data  -->
        <section class="col-lg-8 col-xl-9">

            <!-- Start print addresses -->
            <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="mb-3">
    
                    <div class="card border-0 <?php echo e($address->active ? 'border-state-active' : 'border-state-disable'); ?>">
                        
                        
                        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center" role="tab" id="heading<?php echo e($address->id); ?>">
                            <h5 class="mb-0">
                                <span class="address-type-icon">
                                    <img src="<?php echo e($address->getTypeIcon()); ?>" style="height: 40px" class="ml-1">
                                </span>
                                <img src="<?php echo e($address->country->getAvatarLogo()); ?>" class="ml-1">
                                <bdi><?php echo e($address->country->name); ?></bdi> / <bdi><?php echo e($address->city->name); ?></bdi>
                            </h5>
                            <a data-toggle="collapse" class="text-dark" href="#collapse<?php echo e($address->id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($address->id); ?>">
                                <i class="fa fa-chevron-down"></i>
                            </a>
                        </div>
                        

                        
                        <div id="collapse<?php echo e($address->id); ?>" class="collapsing" role="tabpanel" aria-labelledby="heading<?php echo e($address->id); ?>">

                            <div class="card-body text-right">

                                <div class="d-flex justify-content-between pb-3">
                                    <ul class="nav nav-pills nav-fill pr-0" id="myTab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" id="addressInfo<?php echo e($address->id); ?>-tab" data-toggle="tab" href="#addressInfo<?php echo e($address->id); ?>" role="tab" aria-controls="addressInfo<?php echo e($address->id); ?>" aria-selected="true">العنوان</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="prices<?php echo e($address->id); ?>-tab" data-toggle="tab" href="#prices<?php echo e($address->id); ?>" role="tab" aria-controls="prices<?php echo e($address->id); ?>" aria-selected="false">الأسعار</a>
                                        </li>
                                    </ul>

                                    <?php if(hasRole('addresses_edit')): ?>
                                        <button type="button" class="btn btn-primary btnEdit" data-toggle="modal" data-target="#Modal">
                                            <i class="fas fa-pen"></i>
                                        </button>
                                    <?php endif; ?>

                                </div>


                                <div class="tab-content">
                                    
                                    
                                    <div class="tab-pane fade show active" id="addressInfo<?php echo e($address->id); ?>" role="tabpanel" aria-labelledby="addressInfo<?php echo e($address->id); ?>-tab">
                                        <table class="table table-address-info table-info-data">
                                            <tbody data-id="<?php echo e($address->id); ?>" data-country="<?php echo e($address->country_id); ?>" data-city="<?php echo e($address->city_id); ?>" data-active="<?php echo e($address->active); ?>" data-type="<?php echo e($address->type); ?>">
                                                <tr>
                                                    <td>البلد</td>
                                                    <td><bdi><?php echo e($address->country->name); ?></bdi></td>
                                                    <td>Country</td>
                                                </tr>
                                                <tr>
                                                    <td>اسم العنوان</td>
                                                    <td><bdi data="name"><?php echo e($address->name); ?></bdi></td>
                                                    <td>Address Name</td>
                                                </tr>
                                                <tr>
                                                    <td>الاسم بالكامل</td>
                                                    <td><bdi data="fullname"><?php echo e($address->fullname); ?></bdi></td>
                                                    <td>FullName</td>
                                                </tr>
                                                <tr>
                                                    <td>العنوان</td>
                                                    <td><bdi data="address1"><?php echo e($address->address1); ?></bdi></td>
                                                    <td>Address Line 1</td>
                                                </tr>
                                                <tr>
                                                    <td>العنوان 2</td>
                                                    <td><bdi data="address2"><?php echo e($address->address2); ?></bdi></td>
                                                    <td>Address Line 2</td>
                                                </tr>
                                                <tr>
                                                    <td>المدينة</td>
                                                    <td><bdi><?php echo e($address->city->name); ?></bdi></td>
                                                    <td>City</td>
                                                </tr>
                                                <tr>
                                                    <td>الولاية</td>
                                                    <td data="state"><?php echo e($address->state); ?></td>
                                                    <td>State/Region</td>
                                                </tr>
                                                <tr>
                                                    <td>الرمز البريدي</td> 
                                                    <td><bdi data="zip"><?php echo e($address->zip); ?></bdi></td>
                                                    <td>PostCode/Zip</td>
                                                </tr>
                                                <tr>
                                                    <td>رقم الهاتف</td>
                                                    <td><bdi data="phone"><?php echo e($address->phone); ?></bdi></td>
                                                    <td>Phone 1</td>
                                                </tr>
                                                <tr>
                                                    <td>رقم الهاتف 2</td> 
                                                    <td><bdi data="phone2"><?php echo e($address->phone2); ?></bdi></td>
                                                    <td>Phone 2</td>
                                                </tr>
                                                <tr>
                                                    <td>رقم الهاتف 3</td> 
                                                    <td><bdi data="phone3"><?php echo e($address->phone3); ?></bdi></td>
                                                    <td>Phone 3</td>
                                                </tr>
                                                <tr>
                                                    <td>ملاحظة</td> 
                                                    <td colspan="2" data="note"><?php echo e($address->note); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>معلومات أخرى</td> 
                                                    <td colspan="2" data="extra"><?php echo e($address->extra); ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    

                                    
                                    <div class="tab-pane fade" id="prices<?php echo e($address->id); ?>" role="tabpanel" aria-labelledby="prices<?php echo e($address->id); ?>-tab">
                                        <table class="table table-bordered table-prices-data text-center">
                                            <thead>
                                                <tr>
                                                    <th>من</th>
                                                    <th>إلى</th>
                                                    <th>السعر</th>
                                                    <th>الوصف</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $address->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr data-id="<?php echo e($price->id); ?>">
                                                        <td data="from"><?php echo e($price->from); ?></td>
                                                        <td data="to"><?php echo e($price->to); ?></td>
                                                        <td data="price"><?php echo e($price->price); ?></td>
                                                        <td data="desc"><?php echo e($price->description); ?></td>
                                                    </tr> 
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    

                                </div>
                            </div>
                        </div>
                        

                        
                    </div>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End print addresses -->

             <div class="pagination-center mt-2"><?php echo e($addresses->links()); ?></div>  

        </section>
        <!--    End show data  -->


    </div>
    

</div>


<?php if(hasRole(['addresses_add','addresses_edit'])): ?>
    
    <!--    Start Modal  -->
    <div class="modal fade" id="Modal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ModalLabel">تعديل عنوان</h5>
                    <button type="button" class="close ml-0" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class='formSendAjaxRequest was-validated' id="addressForm" refresh-seconds='2' action="<?php echo e(url('/cp/addresses')); ?>" method="post">
                    
                    
                    <div class="modal-body px-sm-5">

                        <div class="formResult text-center"></div>
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" />

                        <nav class="pb-3">
                            <div class="nav nav-tabs nav-fill" role="tablist">
                                <a class="nav-item nav-link active" id="nav-inputAddress-tab" data-toggle="tab" href="#nav-inputAddress" role="tab" aria-controls="nav-inputAddress" aria-selected="true">العنوان</a>
                                <a class="nav-item nav-link" id="nav-inputPrices-tab" data-toggle="tab" href="#nav-inputPrices" role="tab" aria-controls="nav-inputPrices" aria-selected="false">الأسعار</a>
                            </div>
                        </nav>

                        <div class="tab-content">
                        
                            
                            <div class="tab-pane fade show active" id="nav-inputAddress" role="tabpanel" aria-labelledby="nav-inputAddress-tab">
                                <div class="row">

                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputName" class="col-sm-auto w-125px col-form-label text-right">الاسم</label>
                                            <div class="col-sm">
                                                <input type="text" name="name" class="form-control" id="inputName" placeholder="اسم فريد لتميز العنوان" pattern="\s*([^\s]\s*){3,32}" required>
                                                <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'الاسم','min'=> 3 ,'max'=>32]); ?></div>
                                            </div>
                                        </div> 
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputFullName" class="col-sm-auto w-125px col-form-label text-right">الاسم بالكامل</label>
                                            <div class="col-sm">
                                                <input type="text" name="fullname" class="form-control" id="inputFullName" placeholder="رقم عضويتكم ليتم بعدها إضافة عضوية الزبون" pattern="\s*([^\s]\s*){3,32}" required>
                                                <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'الاسم','min'=> 3 ,'max'=>32]); ?></div>
                                            </div>
                                        </div> 
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputCountry" class="col-sm-auto w-125px col-form-label text-right">البلد</label>
                                            <div class="col-sm">
                                                <select id="inputCountry" name="country" class="form-control" required>
                                                    <option value="" selected>...</option>
                                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                        <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputCity" class="col-sm-auto w-125px col-form-label text-right">المدينة</label>
                                            <div class="col-sm">
                                                <select id="inputCity" name="city" class="form-control" required>
                                                    <option value="" selected>...</option>
                                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                        <option value="<?php echo e($city->id); ?>" data-country="<?php echo e($city->country_id); ?>"><?php echo e($city->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputState" class="col-sm-auto w-125px col-form-label text-right">الولاية</label>
                                            <div class="col-sm">
                                                <input type="text" name="state" class="form-control" id="inputState" placeholder="State" pattern="\s*([^\s]\s*){3,32}">
                                                <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'الولاية','min'=> 3 ,'max'=>32]); ?></div>
                                            </div>
                                        </div> 
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputAddress1" class="col-sm-auto w-125px pl-0 col-form-label text-right">العنوان1</label>
                                            <div class="col-sm">
                                                <input type="text" name="address1" class="form-control" id="inputAddress1" placeholder="Address Line 1" pattern="\s*([^\s]\s*){3,32}">
                                                <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'العنوان','min'=> 3 ,'max'=>32]); ?></div>
                                            </div>
                                        </div> 
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputAddress2" class="col-sm-auto w-125px pl-0 col-form-label text-right">العنوان2</label>
                                            <div class="col-sm">
                                                <input type="text" name="address2" class="form-control" id="inputAddress2" placeholder="Address Line 2" pattern="\s*([^\s]\s*){3,32}">
                                                <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'العنوان','min'=> 3 ,'max'=>32]); ?></div>
                                            </div>
                                        </div> 
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputPhone" class="col-sm-auto w-125px pl-0 col-form-label text-right">رقم الهاتف1</label>
                                            <div class="col-sm">
                                                <input type="text" name="phone" id="inputPhone" class="form-control text-right" dir='ltr' placeholder="Phone Number" pattern="\s*([0-9\-\+]\s*){3,14}">
                                                <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.digits_between',['attribute'=>'رقم الهاتف','min'=> 3 ,'max'=>14]); ?></div>
                                            </div>
                                        </div> 
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputPhone2" class="col-sm-auto w-125px pl-0 col-form-label text-right">رقم الهاتف2</label>
                                            <div class="col-sm">
                                                <input type="text" name="phone2" id="inputPhone2" class="form-control text-right" dir='ltr' placeholder="Phone Number" pattern="\s*([0-9\-\+]\s*){3,14}">
                                                <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.digits_between',['attribute'=>'رقم الهاتف','min'=> 3 ,'max'=>14]); ?></div>
                                            </div>
                                        </div> 
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputPhone3" class="col-sm-auto w-125px pl-0 col-form-label text-right">رقم الهاتف3</label>
                                            <div class="col-sm">
                                                <input type="text" name="phone3" id="inputPhone3" class="form-control text-right" dir='ltr' placeholder="Phone Number" pattern="\s*([0-9\-\+]\s*){3,14}">
                                                <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.digits_between',['attribute'=>'رقم الهاتف','min'=> 3 ,'max'=>14]); ?></div>
                                            </div>
                                        </div> 
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputZip" class="col-sm-auto w-125px pl-0 col-form-label text-right">الرمز البريدي</label>
                                            <div class="col-sm">
                                                <input type="text" name="zip" class="form-control" id="inputZip" placeholder="PostCode/Zip" pattern="\s*([^\s]\s*){3,10}">
                                                <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.between.string',['attribute'=>'الرمز البريدي','min'=> 3 ,'max'=>10]); ?></div>
                                            </div>
                                        </div> 
                                    </div>
                                    
                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputActive" class="col-sm-auto w-125px col-form-label text-right">الحالة</label>
                                            <div class="col-sm">
                                                <select id="inputActive" name="active" class="form-control" required>
                                                    <option value="1" selected>تفعيل</option> 
                                                    <option value="0">عدم التفعيل</option> 
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputType" class="col-sm-auto w-125px col-form-label text-right">النوع</label>
                                            <div class="col-sm">
                                                <select id="inputType" name="type" class="form-control" required>
                                                    <option value="" selected>...</option> 
                                                    <option value="1">جوي</option> 
                                                    <option value="2">بحري</option> 
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6"></div>

                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputNote" class="col-sm-auto w-125px col-form-label text-right">ملاحظة</label>
                                            <div class="col-sm">
                                                <textarea name="note" rows="3" class="form-control" id="inputNote" placeholder="ملاحظة للزبائن" maxlength="150"></textarea>
                                                <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.max.string',['attribute'=>'الملاحظة','max'=>150]); ?></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label for="inputExtra" class="col-sm-auto w-125px col-form-label text-right">أخرى</label>
                                            <div class="col-sm">
                                                <textarea name="extra" rows="3" class="form-control" id="inputExtra" placeholder="معلومات أخرى خاصة" maxlength="150"></textarea>
                                                <div class="invalid-feedback text-center"><?php echo app('translator')->get('validation.max.string',['attribute'=>'المعلومات الأخرى','max'=>150]); ?></div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            

                                                
                            <div class="tab-pane fade" id="nav-inputPrices" role="tabpanel" aria-labelledby="nav-inputPrices-tab">
                            
                                <table class="table text-center">
                                    <thead>
                                        <tr>
                                            <th>من</th>
                                            <th>إلى</th>
                                            <th>السعر</th>
                                            <th>الوصف</th>
                                        </tr>
                                    </thead>
                                    <tbody> 
                                     
                                    </tbody>
                                </table>

                            </div>
                                                

                        </div>

                    

                    </div>
                    

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">تحديث</button>
                        <button type="button" class="btn btn-danger mr-2" data-dismiss="modal">إلغاء</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--    End Modal  -->

<?php endif; ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra-js'); ?>
    <script> 

            /*  */
            var inputCitySearch = $('#inputCitySearch');
            $(inputCitySearch).html($('#inputCity').html());
            $(inputCitySearch).val($(inputCitySearch).attr('value'));
            $(inputCitySearch).find('option[value=""]').html('الكل');

            var inputCountrySearch = $('#inputCountrySearch');
            $(inputCountrySearch).html($('#inputCountry').html());
            $(inputCountrySearch).val($(inputCountrySearch).attr('value'))
            $(inputCountrySearch).find('option[value=""]').html('الكل');;

            $(inputCountrySearch).change(function () {
                /* When user change country show only cities that exsit in current country */
                $(inputCitySearch).val('');
                if ($(this).val()) {
                    $(inputCitySearch).find('option').hide().filter('[data-country="' + $(this).val() + '"] ,[value=""]').show();
                } else {
                    $(inputCitySearch).find('option').show();
                }
            });
            $(inputCountrySearch).change(); /* to show only related citites for selected country */
            /*  End config select(country and city) */


            var addAction = "<?php echo e(url('/cp/addresses')); ?>";
            var editAction = "<?php echo e(url('/cp/addresses/edit')); ?>";
            var form = $('#Modal form')[0];
            
            /* Start event for click add new address  */
            $('.btnAdd').click(function() {
                form.reset();
                $(form).find('input[name="id"]').val('');

                removeAllRowsInputPrice();
                addRowInputPrice();

                $(form).attr('action',addAction);
                $('#ModalLabel').html('إضافة عنوان');
                $(form).find('.formResult').html('');
            });
            /* End event for click add new address  */

            /* Start event for click edit address  */
            $('.btnEdit').click(function() {
                var addressData = $(this).closest('.card-body').find('.table-info-data tbody');
                var pricesData = $(this).closest('.card-body').find('.table-prices-data tbody');

                removeAllRowsInputPrice();
                
                $(form).attr('action',editAction);
                $('#ModalLabel').html('تعديل عنوان');
                $(form).find('.formResult').html('');
                $(form).find('input[name="id"]').val(addressData.data('id'));
                $(form).find('select[name="country"]').val(addressData.data('country')).change();/* to trigger event change , then will show only related cities */
                $(form).find('select[name="city"]').val(addressData.data('city'));
                $(form).find('select[name="active"]').val(addressData.data('active'));
                $(form).find('select[name="type"]').val(addressData.data('type'));
                $(form).find('input[name="name"]').val(addressData.find('*[data="name"]').html());
                $(form).find('input[name="fullname"]').val(addressData.find('*[data="fullname"]').html());
                $(form).find('input[name="address1"]').val(addressData.find('*[data="address1"]').html());
                $(form).find('input[name="address2"]').val(addressData.find('*[data="address2"]').html());
                $(form).find('input[name="phone"]').val(addressData.find('*[data="phone"]').html());
                $(form).find('input[name="phone2"]').val(addressData.find('*[data="phone2"]').html());
                $(form).find('input[name="phone3"]').val(addressData.find('*[data="phone3"]').html());
                $(form).find('input[name="state"]').val(addressData.find('*[data="state"]').html());
                $(form).find('input[name="zip"]').val(addressData.find('*[data="zip"]').html());
                $(form).find('textarea[name="note"]').val(addressData.find('td[data="note"]').html());
                $(form).find('textarea[name="extra"]').val(addressData.find('td[data="extra"]').html());

                var pricesRows = pricesData.find('tr');
                if(pricesRows.length > 0){
                    $.each(pricesRows, function () {
                        addRowInputPrice(
                            $(this).find('td[data="from"]').html(),
                            $(this).find('td[data="to"]').html(),
                            $(this).find('td[data="price"]').html(),
                            $(this).find('td[data="desc"]').html(),
                            $(this).data('id')
                            );
                    });
                }
                else
                {/* if address doesn't have prices , so add new row to allow to user add new prices */
                    addRowInputPrice('','','','','','added');
                }
            });
            /* End event for click edit address  */


            /******** Start helper functions ********/

            /**
             *  Add row with input fildes to form(form for Add/Edit Addresses) 
             * @param  from {float} from value
             * @param  to {float} to value
             * @param  price {float} price value
             * @param  desc {string} desc value
             * @param  id {integer} id value
             * @param  state {string} state of row , must be (added|updated|default)
             */
            function addRowInputPrice(from = '', to = '', price = '', desc = '', id = '',state= 'default') {

                $('#nav-inputPrices tbody').append(   
                                  '<tr>'
                                + ((id)? '<input type="hidden" name="prices[id][]" value="'+id+'" />' : '')
                                + '    <input type="hidden" name="prices[row_state][]" value="'+state+'" />'
                                + '    <td><input type="number" name="prices[from][]" value="' + from + '" class="form-control" step="any" min="0.001" required /></td>'
                                + '    <td><input type="number" name="prices[to][]" value="' + to + '" class="form-control" step="any" min="'+(from? from : 0.001)+'" required /></td>'
                                + '    <td><input type="number" name="prices[price][]" value="' + price + '" class="form-control" step="any" min="0" required /></td>'
                                + '    <td>'
                                + '        <input type="text" name="prices[desc][]" value="' + desc + '" class="form-control w-300px" placeholder="الوصف" pattern="\s*([^\s]\s*){3,32}" required>'
                                + '        <div class="invalid-feedback text-center"><?php echo app('translator')->get("validation.between.string",["attribute"=>"الوصف","min"=> 3 ,"max"=>32]); ?></div>' /*  this line will get value using laravl */
                                + '    </td>'
                                + '    <td>'
                                + '        <div class="d-flex mt-1">'
                                + '            <button type="button" class="btn btn-danger btn-sm btnDeleteRow ml-1"><i class="fa fa-trash"></i></button>'
                                + '            <button type="button" class="btn btn-primary btn-sm btnAddRow"><i class="fa fa-plus"></i></button>'
                                + '        </div>'
                                + '    </td>'
                                + '</tr>'
                            );
            }
            

            /**
             * Remove all input rows (input prices) from form and set it empty  
             */
            function removeAllRowsInputPrice(){
                $('#nav-inputPrices tbody tr').remove();
                $(form).find('[name="deleted_prices[]"]').remove();
            }

            /******** End helper functions ********/


            /*  Start events to control in add/delete rows from form    */

            /* on user click on add button , add new row in form */
            $('#nav-inputPrices').on('click', '.btnAddRow', function () {
                addRowInputPrice('', '', '', '', '', 'added');
            });

            /* on user click on delete button , delete current row from form */
            $('#nav-inputPrices').on('click', '.btnDeleteRow', function () {
                var tr = $(this).closest('tr');
                var id = $(tr).find('[name="prices[id][]"]').val();
                if (id) {/* if id exsits that means user edit data and remove current row, so I have to save it as deleted valued */
                    $(form).append('<input type="hidden" name="deleted_prices[]" value="' + id + '" />');
                }
                tr.remove();
            });

            /*  End events to control in add/delete rows from form    */


            $('#nav-inputPrices').on('change', 'input:not([type=hidden])', function () {
                var tr = $(this).closest('tr');
                var state = $(tr).find('[name="prices[row_state][]"]');
                if (state.val() === 'default') {/* if state of row is default ,so it means old data from Database and I have to change state to updated */
                    $(state).val('updated');
                }
                if ($(this).attr('name') == 'prices[from][]') {/* to make validate that (to) must be greater than or eqult (From) filde */
                    $(tr).find('[name="prices[to][]"]').attr('min', $(this).val());
                }
            });

            /* When user change country show only cities that exsit in current country */
            $('#inputCountry').change(function () {
                $('#inputCity').val('');
                if ($(this).val()) {
                    $('#inputCity option').hide().filter('[data-country="' + $(this).val() + '"] ,[value=""]').show();
                } else {
                    $('#inputCity option').hide();
                }
            });


            /**
            * when user click on submit , check if inputAddress-tab have invalid fild(input) then focue on this tab
            * if inputAddress-tab inputs valid , then check inputPrices-tab inputs
            */
            $('#addressForm :submit').click(function () {

                var continueCheckPrices = true;

                $('#nav-inputAddress input:not([type=hidden]),#nav-inputAddress select,#nav-inputAddress textarea').each(function () {
                    if (!$(this)[0].checkValidity()) {
                        $('#nav-inputAddress-tab').tab('show');
                        continueCheckPrices = false;
                        return false;
                    }
                });

                if (continueCheckPrices) {
                    $('#nav-inputPrices input:not([type=hidden])').each(function () {
                        if (!$(this)[0].checkValidity()) {
                            $('#nav-inputPrices-tab').tab('show');
                            return false;
                        }
                    });
                }
            });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/addresses.blade.php ENDPATH**/ ?>