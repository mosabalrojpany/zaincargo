<?php $__env->startSection('content'); ?>



<div class="d-flex justify-content-between">
    <h4 class="font-weight-bold">الرحلات <?php echo e($trips->total()); ?></h4>
    
    <?php if(hasRole('trips_add')): ?>
        <a class="btn btn-primary w-100px" href="<?php echo e(url('cp/trips/create')); ?>">
            <i class="fas fa-plus mx-1"></i>أضف
        </a>
    <?php endif; ?>

</div>





<div class="card card-shadow my-4 text-center">
        
    <!-- Start search  -->
    <div class="card-header bg-primary text-white"> 
        <form class="justify-content-between" action="<?php echo e(Request::url()); ?>" method="get">
            <input type="hidden" name="search" value="1">

            <div class="form-inline">
                <span class="ml-2"><i class="fa fa-filter"></i></span>
                <div class="form-group">
                    <label class="d-none" for="inputTripNumberSearch">رقم الرحلة</label>
                    <input type="search" maxlength="32" name="trip_number" value="<?php echo e(Request::get('trip_number')); ?>" placeholder="رقم الرحلة" id="inputTripNumberSearch" class="form-control mx-sm-2">
                </div>
                <div class="form-group">
                    <label class="d-none" for="inputTrackingNumberSearch">رقم التتبع</label>
                    <input type="search" maxlength="32" name="tracking_number" value="<?php echo e(Request::get('tracking_number')); ?>" placeholder="رقم التتبع" id="inputTrackingNumberSearch" class="form-control mx-sm-2">
                </div>
                <div class="form-group">
                    <label class="d-none" for="inputStateSearch">الحالة</label>
                    <select id="inputStateSearch" class="form-control mx-sm-2 setValue" style="width: 140px;" name="state" value="<?php echo e(Request::get('state')); ?>">
                        <option value="">كل الحالات</option>
                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="d-none" for="inputAddressSearch">العنوان</label>
                    <select id="inputAddressSearch" class="form-control mx-sm-2 setValue" style="width: 220px;" name="address" value="<?php echo e(Request::get('address')); ?>">
                        <option value="">كل العناوين</option>
                        <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($address->id); ?>"><?php echo e($address->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="d-none" for="inputCompanySearch">الشركة</label>
                    <select id="inputCompanySearch" class="form-control mx-sm-2 setValue" style="width: 220px;" name="company" value="<?php echo e(Request::get('company')); ?>">
                        <option value="">كل الشركات</option>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
            </div>

        </form>  
    </div>  
    <!-- End search  -->


    <?php
        $canEdit =  hasRole('trips_edit')        
    ?>

    <!--    Start show trips   -->
    <div class="card-body p-0">
        <table class="table table-center table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">رقم الرحلة</th>
                    <th scope="col">رقم التتبع</th>
                    <th scope="col">الحالة</th>
                    <th scope="col">الشركة</th>
                    <th scope="col">تاريخ الخروج</th>
                    
                    <?php if($canEdit): ?>
                        <th scope="col">تعديل</th>
                    <?php endif; ?>

                </tr>
            </thead>
            <tbody>

                <!-- Start print trips -->
                <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><a target="_blank" href="<?php echo e(url('cp/trips',$trip->id)); ?>"><?php echo e($trip->trip_number); ?></a></td> 
                        <td><?php echo e($trip->tracking_number); ?></td> 
                        <td><?php echo e($trip->getState()); ?></td> 
                        <td><?php echo e($trip->company->name); ?></td> 
                        <td><bdi><?php echo e($trip->exit_at()); ?></bdi></td>
                        
                        <?php if($canEdit): ?>
                            <td>
                                <a href="<?php echo e(url('cp/trips/edit',$trip->id)); ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-pen"></i>
                                </a>
                            </td>
                        <?php endif; ?>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- End print trips -->

            </tbody>
        </table>
    </div>
    <!--    End show trips   -->

</div>





<div class="pagination-center"><?php echo e($trips->links()); ?></div>  



<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/trips/index.blade.php ENDPATH**/ ?>