<?php $__env->startSection('content'); ?>



    <!--  Start path  -->
    <div class="d-flex align-items-center bg-white mb-3 d-print-none">

        <nav class="col pr-0" aria-label="breadcrumb" role="navigation">
            <ol class="breadcrumb bg-white mb-0">
                <li class="breadcrumb-item">
                    <a href="">عمليات الايداع</a>
                </li>
                <li class="breadcrumb-item active text-truncate col pr-0 text-right" aria-current="page">
                    <span class="mr-1"></span>
                </li>
            </ol>
        </nav>

    </div>
    <!--  End path  -->
    <div class="card-header bg-primary text-white">
        <form class="justify-content-between" action="<?php echo e(Request::url()); ?>" method="get">
            <input type="hidden" name="search" value="1">
            <div class="form-inline">
                <span class="ml-2"><i class="fa fa-filter"></i></span>
                <div class="form-group">
                    <label class="d-none" for="inputIdSearch">رقم واصل الايداع</label>
                    <input type="number" name="prob_id" min="1" value="<?php echo e(Request::get('prob_id')); ?>" placeholder="رقم واصل الايداع" id="inputIdSearch" class="form-control mx-sm-2">
                </div>

                            
            <div class="form-inline mt-2">
                <span class="ml-2"><i class="fa fa-filter"></i></span>

                <div class="form-group">
                    <label for="inputReceivedAtFromDate">تاريخ الايداع من</label>
                    <input type="date" name="created_at" value="<?php echo e(Request::get('created_at')); ?>" id="inputReceivedAtFromDate" class="form-control mx-sm-2">
                </div>
                <div class="form-group">
                    <label for="inputReceivedAtToDate">إلى</label>
                    <input type="date" name="created_at2" value="<?php echo e(Request::get('created_at2')); ?>" id="inputReceivedAtToDate" class="form-control mx-sm-2">
                </div>
            </div>
            
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
            </div>
        </form>
    </div>


    <div class="card card-shadow">
        <?php echo $__env->make('CP.elerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('CP.elerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                
                <div class="card-body">


                    <table class="table table-center table-bordered text-center">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>اسم الموظف</th>
                                <th>قبل</th>
                                <th>بعد</th>
                                
                                <th>رقم المعالمة</th>
                                <th>النوع</th>
                                <th>قام بي</th>
                                <th class="">ملاحظة</th>

                            </tr>
                        </thead>
                        <tbody>
        
                        

                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $change): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($change->employe_name); ?></td>
                                <td><?php echo e($change->before); ?></td>
                                <td><?php echo e($change->after); ?></td>
                                
                                <td><?php echo e($change->prob_id); ?></td>
                                <td><?php echo e($change->type()); ?></td>
                                <td><?php echo e($change->whatdo); ?></td>
                                <td><?php echo e($change->note); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        

                        

                        </tbody>
                    </table>
                    

                </div>
                

<div class="pagination-center"><?php echo e($data->links()); ?></div>


    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/customer_wallet/transaction.blade.php ENDPATH**/ ?>