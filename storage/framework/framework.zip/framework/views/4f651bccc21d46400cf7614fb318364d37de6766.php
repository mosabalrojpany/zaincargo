 
<?php $__env->startSection('content'); ?>


    <h4 class="font-weight-bold text-right">الإشعارات <?php echo e($notifications->total()); ?></h4>

    
	<div class="notifications-page pt-4 mb-5 text-right">

        <?php if($notifications->count()): ?>
        
            <div class="list-group shadow">

                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <a href="<?php echo e(get_url_for_notifications($notification)); ?>" 
                        class="list-group-item list-group-item-action <?php echo e($notification->unRead()? 'list-group-item-primary' : ''); ?> d-flex align-items-center border-0 mb-1">
                    
                        <span class="notification-icon ml-3">
                            <i class="<?php echo e(get_icon_for_notifications($notification)); ?> fa-fw fa-2x"></i>
                        </span>
                        
                        <div>
                            <?php echo $notification->data['title']; ?>

                            <label class="text-muted f-15px d-block mb-0">
                                <span title="<?php echo e($notification->created_at->format('Y-m-d g:ia')); ?>">
                                    <i class="far fa-clock ml-1"></i>
                                    <bdi><?php echo e($notification->created_at->diffForHumans()); ?></bdi>
                                </span>

                                <?php if($notification->Read()): ?>
                                    <span title="<?php echo e($notification->read_at->format('Y-m-d g:ia')); ?>">
                                        <i class="fa fa-check-double ml-1 mr-3"></i>
                                        <bdi><?php echo e($notification->read_at->diffForHumans()); ?></bdi>
                                    </span>
                                <?php endif; ?>

                            </span>
                        </div>
                    
                    </a>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <div class="pagination-center mt-4"> <?php echo e($notifications->links()); ?></div>

        <?php else: ?>
        
            <h2 class="p-5 text-muted text-center">لايوجد إشعارات</h2>

        <?php endif; ?>

	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/Client/notifications.blade.php ENDPATH**/ ?>