<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel="icon" type="image/png"   href="<?php echo e(url('images/logo.png')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/sheets-of-paper.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;400;900&display=swap" rel="stylesheet">
</head>

<body class="document" style="font-family: Cairo">

    <style>

        /* arabic */

        @font-face {
            font-family: 'Tajawal';
            font-style: normal;
            font-weight: 400;
            src: url( <?php echo e(url('fonts/Tajawal/Tajawal-Medium.ttf')); ?> );
        }

        body {
            direction: rtl;
            font-family: Tajawal;
        }

        .header {
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            padding-bottom: 20px;
            border-bottom: 1px solid #000;
            margin-bottom: 20px;
        }

        .header img {
            height: 80px;
        }
        .header .title {
            font-size: 24px;
            text-align: right;
            padding-right: 10px;
            margin: 0;
        }
        .page-title {
            text-align: center;
            font-size: 18px;
            text-decoration: underline;
            text-underline-position: under;
        }
        .info {
            display: flex;
            justify-content: space-between;
        }
        .info ul {
            padding: 0;
            list-style: none;
            max-width: 50%;
        }
        .info ul li {
            line-height: 1.5;
        }
        .table {
            width: 100%;
            text-align: center;
            border-collapse: collapse;
        }
        .table th , .table td {
            padding: 7px;
            border: 1px solid #ddd;
        }
        .footer ul {
            padding: 0;
            list-style: none;
        }
        .footer ul li {
            line-height: 1.5;
        }
        .footer{
            margin-top: 450px
        }
    </style>
    <div class="page">
        <div class="header">
            <img src="<?php echo e(url('images/logo-with-title-black.png')); ?>" />
        </div>
    <h2 class="page-title"> واصل <?php echo e($data->depositytypee()); ?></h2>
        <div class="info">
            <ul>
                <li><b> رقم ال<?php echo e($data->depositytypee()); ?>  / <?php echo e($data->id); ?> </b><bdi></bdi></li>
                <li><b>تاريخ / <?php echo e($data->created_at); ?> </b><bdi></bdi></li>
            </ul>
            <ul>
                <li><b>رقم العضوية / <?php echo e($data->wallet->customer->code); ?> </b><bdi></bdi></li>
                <li><b>اسم الزبون /<?php echo e($data->wallet->customer->name); ?> </b></li>
                    <li><b>ملاحظة / </b></li>
            </ul>
        </div>
        <div class="details">
            <table class="table">
                <thead>
                    <tr>
                        <th>الفرع</th>
                        <th>القيمة</th>
                        <th>نوع العملة</th>
                        <th>ملاحظة</th>
                    </tr>
                </thead>
                <tbody>
                        <tr>
                        <td><?php echo e($data->branchess->city); ?></td>
                        <td><?php echo e($data->price); ?></td>
                        <td><?php echo e($data->currencytype->name); ?></td>
                            <td style="background-color: ;">
                            <bdi style="background-color: #fff;padding:2px;"><?php echo e($data->note); ?></bdi>
                            </td>
                        </tr>
                </tbody>
            </table>
        </div>

        <div class="footer" >
            <hr>
            <div style="text-align: center;">
                <h5 >الكترو ليبيا للشحن وخدمات التسوق</h5>
            </div>
        </div>

    </div>


    <script>
        print();
        window.onafterprint = function() {
        history.go(-1);
        }
    </script>

</body>

</html>
<?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/customer_wallet/print.blade.php ENDPATH**/ ?>