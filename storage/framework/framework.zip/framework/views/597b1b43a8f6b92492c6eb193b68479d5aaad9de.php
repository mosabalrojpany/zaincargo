<?php $__env->startSection('content'); ?>


    <!--    Start path   -->
    <nav aria-label="breadcrumb" role="navigation" class="shadow">
        <ol class="breadcrumb bg-white">
            <li class="breadcrumb-item"> 
                <a href="<?php echo e(url('/cp/posts')); ?>">الأخبار</a>
            </li>
            <li class="breadcrumb-item active text-truncate col pr-0 text-right" aria-current="page"><?php echo e($post->title); ?></li>
        </ol>
    </nav>
    <!--    End path    -->



<!--    Start post info    -->
<div class="row mt-3 mb-5 justify-content-center text-right">
 
    
    <div class="col-xl-8 mb-4">

        <div class="bg-white shadow py-3 px-4">
            
            <div class="row align-items-center">
                <div class="col">
                    <h5 class="mb-0"><?php echo e($post->title); ?></h5>
                </div>

                <?php if(hasRole('posts_edit')): ?>
                    <div class="col-auto">
                        <a href="<?php echo e(url('cp/posts/edit',$post->id)); ?>" class="btn btn-primary"><i class="fa fa-pen"></i></a>
                    </div>
                <?php endif; ?>
                
            </div>
            
            <span class="text-muted d-inline-block mb-2 f-15px"> 
                <i class="fas fa-user mx-1"></i><?php echo e($post->user->name); ?>

                <i class="far fa-clock ml-1 mr-2"></i><bdi><?php echo e($post->created_at()); ?></bdi>
                <i class="fa fa-tags fa-sm mr-2 ml-1"></i><bdi><?php echo e(collect($post->tags->pluck('name'))->implode(' , ')); ?></bdi>  
            </span>
            
            <hr class="mt-2"/>
            
            <img class="img-fluid w-100" src="<?php echo e($post->getImage()); ?>" />
            
            <div class="editor-content mt-4"><?php echo $post->content; ?></div>
        
        </div>

    </div> 
    


    <div class="col-xl-4 last-posts">

        <div class="row">
            <!--    Start last-posts    -->
            <div class="col-md-6 col-xl-12 mb-3">

                <div class="bg-white shadow p-3">
                    
                    <h4 class="">أخر الحملات</h4>
                    
                    <hr/>
                    
                    <?php $__currentLoopData = $last_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <div class="card border-0 mb-3">
                            <div class="row no-gutters">
                                <a href="<?php echo e(url('cp/posts',$p->id)); ?>" class="col-4 box-img">
                                    <img src="<?php echo e($p->getImageAvatar()); ?>" class="card-img rounded-0" >
                                    <div class="overly"></div>
                                </a>
                                <div class="col-8 text-right pr-2">
                                    <h6 class="card-text mb-0">
                                        <a href="<?php echo e(url('cp/posts',$p->id)); ?>"><?php echo e($p->title); ?></a>
                                    </h6>
                                    <span class="text-muted f-15px"><i class="far fa-clock ml-1 mr-2"></i><bdi><?php echo e($p->created_at()); ?></bdi></span>
                                </div>
                            </div>
                        </div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </div>
            
            </div>
            <!--    End last-posts      -->
            
            <!--    Start related posts    -->
            <?php if($related_posts): ?>
                <div class="col-md-6 col-xl-12 mb-3">
                    <div class="bg-white p-3 shadow">
                        <h4 class="">حملات ذات صلة</h4>
                        <hr/>
                        <?php $__currentLoopData = $related_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card border-0 mb-3">
                                <div class="row no-gutters">
                                    <a href="<?php echo e(url('cp/posts',$p->id)); ?>" class="col-4 box-img">
                                        <img src="<?php echo e($p->getImageAvatar()); ?>" class="card-img rounded-0" >
                                        <div class="overly"></div>
                                    </a>
                                    <div class="col-8 text-right pr-2">
                                        <h6 class="card-text mb-0"><a href="<?php echo e(url('cp/posts',$p->id)); ?>"><?php echo e($p->title); ?></a></h6>
                                        <span class="text-muted f-15px"><i class="far fa-clock ml-1 mr-2"></i><bdi><?php echo e($p->created_at->format('Y-m-d g:ia')); ?></bdi></span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
            <!--    End related posts    -->
        </div>

    </div>
</div>
<!--    End post info    -->

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('CP.layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/posts/show.blade.php ENDPATH**/ ?>