<!doctype html>
<html lang="ar">

    <head>
        <title><?php echo $__env->yieldContent('title',config('app.name')); ?></title>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <link rel="icon" type="image/png"   href="<?php echo e(url('images/logo.png')); ?>">
        <!-- Bootstrap And Fontawsome CSS -->
        <link rel="stylesheet" href="<?php echo e(url('/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('/css/all.min.css')); ?>" >
        <link rel="stylesheet" href="<?php echo e(url('/css/style.css')); ?>" />
    </head>

<body>


    <div class="client-wrapper min-vh-100">
        <!--    StartSidebar     -->
        <nav id="client-sidebar" class="text-right text-white bg-primary vh-100">

            <h5 class="mt-3 pr-2 pl-3">
                <img class="mw-100" src="<?php echo e(url('images/logo-with-title.png')); ?>" />
            </h5>

            <hr/>

            <ul class="list-unstyled px-0">
                <li>
                    <a href="<?php echo e(url('/client/index')); ?>">
                        <span class="icon"><i class="fa fa-home"></i></span>
                        الرئيسية
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('/client/shipping-invoices')); ?>">
                        <span class="icon"><i class="fa fa-cubes"></i></span>
                        الشحنات
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('/client/wallet')); ?>">
                        <span class="icon"><i class="fa fa-wallet"></i></span>
                        المحفظة
                    </a>
                </li>
                <?php if(authClient()->user()->merchant_state == 1): ?>
                <li>
                    <a href="<?php echo e(url('/client/merchant_prchase_order')); ?>">
                        <span class="icon"><i class="fa fa-shopping-cart"></i></span>
                        طلبات الشراء للتجار
                    </a>
                </li>
                <?php endif; ?>

                                    <li>
                        <a href="#subMenuwallet" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <span class="icon"><i class="fas fa-concierge-bell"></i></span>
                            طلب خدمة
                        </a>
                        <ul class="collapse list-unstyled" id="subMenuwallet" style="padding: 0;">
                            <li>
                                <a href="<?php echo e(url('/client/purchase-orders')); ?>">
                                    <span class="icon"><i class="fa fa-shopping-cart"></i></span>
                                    طلبات الشراء
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/client/money-transfers')); ?>">
                                    <span class="icon"><i class="fa fa-exchange-alt"></i></span>
                                    الحوالات المالية الخارجية
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/client/internalmoneytransfare')); ?>">
                                    <span class="icon"><i class="fa fa-exchange-alt"></i></span>
                                    الحوالات المالية الداخلية
                                </a>
                            </li>
                        </ul>
                    </li>

                <li>
                    <a href="<?php echo e(url('/client/addresses')); ?>">
                        <span class="icon"><i class="fas fa-map-marked-alt"></i></span>
                        عناوين الشحن
                    </a>
                </li>
            </ul>

        </nav>
        <!--    End Sidebar     -->


        <!--    Start Page Content  -->
        <div id="client-content">


            <nav class="navbar navbar-expand bg-white shadow">

                <div class="container justify-content-between">

                    <ul class="navbar-nav pr-0 flex-row">
                        <li class="nav-item">
                            <button class="navbar-toggler d-block py-0 px-1 mt-1" id="sidebarClientCollapse" type="button">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                        </li>
                    </ul>

                    <ul class="navbar-nav text-right">
                        <li class="nav-item dropdown notifications">

                            <a id="notificationsNavbarDropdown" class="nav-link dropdown-toggle text-secondary h-100 d-flex align-items-center" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="far fa-bell"></i>
                                <?php if($unReadNotifications->count()): ?>
                                    <span id="notifications-count" class="notifications-count"><?php echo e($unReadNotifications->count()); ?></span>
                                <?php endif; ?>
                            </a>

                            <div class="dropdown-menu dropdown-menu-left text-right mt-3 border-0 shadow" aria-labelledby="notificationsNavbarDropdown">

                                <div class="d-flex justify-content-between align-items-center bg-primary text-white p-3">
                                    <h6 class="font-weight-bold mb-0">الاشعارات</h6>
                                    <?php if($unReadNotifications->count()): ?>
                                        <a href="#" id="mark-all-notifications-as-read" class="text-white small">تحديد الكل كمقروء</a>
                                    <?php endif; ?>
                                </div>

                                <?php if($unReadNotifications->count() || ($readNotifications && $readNotifications->count())): ?>

                                    <div id="notifications-list" class="notifications-list">

                                        <?php $__currentLoopData = $unReadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="dropdown-item bg-light" href="<?php echo e(get_url_for_notifications($n)); ?>">
                                                <?php echo $n->data['title']; ?>

                                                <span class="text-muted d-block mt-1" style="font-size: 90%;">
                                                    <i class="far fa-clock mr-2"></i>
                                                    <bdi><?php echo e($n->created_at->diffForHumans()); ?></bdi>
                                                </span>
                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $readNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="dropdown-item" href="<?php echo e(get_url_for_notifications($n)); ?>">
                                                <?php echo $n->data['title']; ?>

                                                <span class="text-muted d-block mt-1" style="font-size: 90%;">
                                                    <i class="far fa-clock mr-2"></i>
                                                    <bdi><?php echo e($n->created_at->diffForHumans()); ?></bdi>
                                                </span>
                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                <?php else: ?>
                                    <h2 class="py-4 px-2 text-muted text-center">لايوجد</h2>
                                <?php endif; ?>

                                <div class="text-center bg-primary text-white p-2">
                                    <a href="<?php echo e(url('client/notifications')); ?>" class="text-white">عرض الكل</a>
                                </div>

                            </div>

                        </li>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle text-secondary d-flex align-items-center" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="<?php echo e(authClient()->user()->name); ?>">
                                <img style="width: 32px" class="border rounded-circle img-profile" src="<?php echo e(authClient()->user()->getImageAvatar()); ?>">
                                <span class="mr-1 text-truncate pl-2 d-none d-sm-inline" style="max-width: 150px;">
                                    <?php echo e(authClient()->user()->name); ?>

                                </span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-left text-right mt-3 border-0 shadow" aria-labelledby="navbarDropdown">
                                
                                <form id="logout-form" action="<?php echo e(url('client/logout')); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <button class="dropdown-item btn" type="submit">خروج</button>
                                </form>
                            </div>
                        </li>
                    </ul>

                </div>

            </nav>


            <main class="text-right">

                <?php if (! empty(trim($__env->yieldContent('content-without-style')))): ?>

                    <?php echo $__env->yieldContent('content-without-style'); ?>

                <?php else: ?>

                    <div class="container py-5">

                        <!--    show errors if they exist   -->
                        <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo $__env->yieldContent('content'); ?>

                    </div>

                <?php endif; ?>

            </main>


        </div>
        <!--    End Page Content  -->


    </div>

    <!--    Button to go top    -->
    <button id="btn-go-top" title="ارجوع للأعلى" class="btn btn-dark">
        <i class="fa fa-chevron-up fa-lg fa-fw"></i>
    </button>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!--<script src="js/jquery-3.3.1.slim.min.js"></script>-->
    <script src="<?php echo e(url('/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(url('/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(url('/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('/js/script.js')); ?>"></script>
    <script>
        let change1;
        let change2;
        let change3;
        let change4;
        let change5;
    $('#mark-all-notifications-as-read').click(function(e){

        e.preventDefault();

        if($('#notifications-list .dropdown-item.bg-light').length == 0){
            return true;
        }

        /* Start send post request to server */
        $.ajax({
                url: "<?php echo e(url('client/notifications/mark-all-as-read')); ?>",
                dataType: 'JSON',
                method: 'POST',
                data : {'_token': '<?php echo e(csrf_token()); ?>'},
            })
            .done(function () { /* Form seneded success without any error */
                $('#notifications-list .dropdown-item').removeClass('bg-light');
                $('#mark-all-notifications-as-read, #notifications-count').hide();
            });
        /* End send post request to server */

    });

    </script>
    <?php echo $__env->yieldContent('extra-js'); ?>
</body>

</html>
<?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/Client/layouts/app.blade.php ENDPATH**/ ?>