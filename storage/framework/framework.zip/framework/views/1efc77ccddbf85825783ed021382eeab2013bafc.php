<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel="icon" type="image/png"   href="<?php echo e(url('images/logo.png')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/sheets-of-paper.css')); ?>">

</head>

<body class="document">

    <style>

        /* arabic */

        @font-face {
            font-family: 'Tajawal';
            font-style: normal;
            font-weight: 400;
            src: url( <?php echo e(url('fonts/Tajawal/Tajawal-Medium.ttf')); ?> );
        }

        body {
            direction: rtl;
            font-family: Tajawal;
        }

        .header {
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            padding-bottom: 20px;
            border-bottom: 1px solid #000;
            margin-bottom: 20px;
        }

        .header img {
            height: 80px;
        }

        .header .title {
            font-size: 24px;
            text-align: right;
            padding-right: 10px;
            margin: 0;
        }

        .page-title {
            text-align: center;
            font-size: 18px;
            text-decoration: underline;
            text-underline-position: under;
        }

        .info {
            display: flex;
            justify-content: space-between;
        }

        .info ul {
            padding: 0;
            list-style: none;
            max-width: 50%;
        }

        .info ul li {
            line-height: 1.5;
        }

        table {
            page-break-inside: auto !important;
        }

        .table {
            width: 100%;
            text-align: center;
            border-collapse: collapse;
        }

        .table th , .table td {
            padding: 7px;
            border: 1px solid #ddd;
          }
        .content ul {
            padding: 0;
            list-style: none;
        }

        .content ul li {
            line-height: 1.5;
        }
    </style>

    <div class="page">

        <div class="header">
            <img src="<?php echo e(url('images/logo-with-title-black.png')); ?>" />
        </div>

        <h2 class="page-title">فاتورة شحن</h2>

        <div class="info">
            <ul>
                <li><b>رقم العضوية / </b><bdi><?php echo e($invoices[0]->customer->code); ?></bdi></li>
                <li><b>اسم الزبون / </b><?php echo e($invoices[0]->customer->name); ?></li>
            </ul>
        </div>

        <div class="content">

            <table class="table" style="margin-top: 20px;">
                <thead>
                    <tr style="background-color: #bbb;">
                        <th>رقم الفاتورة</th>
                        <th>رمز الشحنة</th>
                        <th>الوزن</th>
                        <th>الوزن الحجمي</th>
                        <th>الحجم(CBM)</th>
                        <th>التكلفة</th>
                        <th>المدفوع</th>
                        
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($invoice->id); ?></td>
                            <td><?php echo e($invoice->shipment_code); ?></td>
                            <td>kg<bdi><?php echo e($invoice->weight); ?></bdi></td>
                            <td>kg<bdi><?php echo e($invoice->volumetric_weight); ?></bdi></td>
                            <td>CBM<bdi><?php echo e($invoice->cubic_meter); ?></bdi></td>
                            <td><?php echo $invoice->total_cost(); ?></td>
                            <td><?php echo $invoice->paid(); ?></td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

            
            <table class="table" style="margin-top: 20px;">
                <thead>
                    <tr style="background-color: #bbb;">
                        <th>عدد الشحنات</th>
                        <th>إجمالي الوزن</th>
                        <th>إجمالي الوزن الحجمي</th>
                        <th>إجمالي الحجم</th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td><bdi><?php echo e($invoices->count()); ?></bdi></td>
                        <td>kg<bdi><?php echo e($invoices->sum('weight')); ?></bdi></td>
                        <td>kg<bdi><?php echo e($invoices->sum('volumetric_weight')); ?></bdi></td>
                        <td>cbm<bdi><?php echo e($invoices->sum('size')); ?></bdi></td>
                    </tr>

                </tbody>
            </table>
            


            
            <table class="table" style="margin-top: 20px;">
                <thead>
                    <tr style="background-color: #bbb;">
                        <th>#</th>
                        <th>المدفوع</th>
                        <th>العملة</th>
                        <th>عدد الشحنات</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $total_paid_by_currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($paid['amount']); ?></td>
                        <td><?php echo e($paid['currency']); ?></td>
                        <td><?php echo e($paid['count']); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            

            <table class="table" style="margin-top: 20px;">
                <thead>
                    <tr style="background-color: #bbb;">
                        <th>إجمالي التكلفة</th>
                        <th>المدفوع</th>
                        <th>الموظف</th>
                        <th>التاريخ</th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td><bdi><?php echo e($invoices->sum(function ($shipment) { return $shipment['total_cost'] * $shipment['exchange_rate'];})); ?></bdi><?php echo e(app_settings()->currency->sign); ?></td>
                        <td><bdi><?php echo e($invoices->sum(function ($shipment) { return $shipment['paid_up'] * $shipment['paid_exchange_rate'];})); ?></bdi><?php echo e(app_settings()->currency->sign); ?></td>
                        <td><bdi><?php echo e(Auth::user()->name); ?></bdi></td>
                        <td><bdi><?php echo e(date('Y-m-d g:ia')); ?></bdi></td>
                    </tr>

                </tbody>
            </table>

        </div>

    </div>


    <script>
        print();
    </script>

</body>

</html>
<?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/shipping_invoices/print-multiple.blade.php ENDPATH**/ ?>