<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel="icon" type="image/png"   href="<?php echo e(url('images/logo.png')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/sheets-of-paper.css')); ?>">

</head>

<body class="document">

    <style>

        /* arabic */

        @font-face {
            font-family: 'Tajawal';
            font-style: normal;
            font-weight: 400;
            src: url( <?php echo e(url('fonts/Tajawal/Tajawal-Medium.ttf')); ?> );
        }

        body {
            direction: rtl;
            font-family: Tajawal;
        }

        .header {
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            padding-bottom: 20px;
            border-bottom: 1px solid #000;
            margin-bottom: 20px;
        }

        .header img {
            height: 80px;
        }

        .header .title {
            font-size: 24px;
            text-align: right;
            padding-right: 10px;
            margin: 0;
        }

        .page-title {
            text-align: center;
            font-size: 18px;
            text-decoration: underline;
            text-underline-position: under;
        }

        .info {
            display: flex;
            justify-content: space-between;
        }

        .info ul {
            padding: 0;
            list-style: none;
            max-width: 50%;
        }

        .info ul li {
            line-height: 1.5;
        }

        .table {
            width: 100%;
            text-align: center;
            border-collapse: collapse;
        }

        .table th , .table td {
            padding: 7px;
            border: 1px solid #ddd;
        }
        .footer ul {
            padding: 0;
            list-style: none;
        }

        .footer ul li {
            line-height: 1.5;
        }
    </style>

    <div class="page">

        <div class="header">
            <img src="<?php echo e(url('images/logo-with-title-black.png')); ?>" />
        </div>

        <h2 class="page-title">فاتورة شراء</h2>

        <div class="info">
            <ul>
                <li><b>رقم الطلب / </b><bdi><?php echo e($order->id); ?></bdi></li>
                <li><b>تاريخ الدفع/ </b><bdi><?php echo e($order->paid_at()); ?></bdi></li>
                <li><b>تاريخ الشراء/ </b><bdi><?php echo e($order->ordered_at()); ?></bdi></li>
            </ul>
            <ul>
                <li><b>رقم العضوية / </b><bdi><?php echo e($order->customer->code); ?></bdi></li>
                <li><b>اسم الزبون / </b><?php echo e($order->customer->name); ?></li>
                <?php if($order->note): ?>
                    <li><b>ملاحظة / </b><?php echo e($order->note); ?></li>
                <?php endif; ?>
            </ul>
        </div>

        <div class="details">

            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>الوصف</th>
                        <th>العدد</th>
                        <th>السعر</th>
                        <th>الضريبة</th>
                        <th>الشحن</th>
                        <th>اللون</th>
                        <th>ملاحظة</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->desc); ?></td>
                            <td><?php echo e($item->count); ?></td>
                            <td><?php echo e($item->price); ?></td>
                            <td><?php echo e($item->tax); ?></td>
                            <td><?php echo e($item->shipping); ?></td>
                            <td style="background-color: <?php echo e($item->color); ?>;">
                                <bdi style="background-color: #fff;padding:2px;"><?php echo e($item->color); ?></bdi>
                            </td>
                            <td><?php echo e($item->note); ?></td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>


        </div>

        <div class="footer">
            <table class="table" style="margin-top: 20px;">
                <thead>
                    <tr style="background-color: #bbb;">
                        <th>الإجمالي</th>
                        <th>الضرائب</th>
                        <th>الشحن الداخلي</th>
                        <th>عمولة الشراء</th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td><bdi><?php echo e($order->getCost()); ?></bdi><bdi><?php echo e($order->currency->sign); ?></td>
                        <td><bdi><?php echo e($order->tax); ?></bdi><bdi><?php echo e($order->currency->sign); ?></td>
                        <td><bdi><?php echo e($order->shipping); ?></bdi><bdi><?php echo e($order->currency->sign); ?></td>
                        <td><bdi><?php echo e($order->fee); ?></bdi><bdi><?php echo e($order->currency->sign); ?></td>
                    </tr>

                </tbody>
            </table>

            <table class="table" style="margin-top: 20px;">
                <thead>
                    <tr style="background-color: #bbb;">
                        <th>التكلفة</th>
                        <th>المدفوع</th>
                        <th>الموظف</th>
                        <th>التاريخ</th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td><bdi><?php echo e($order->getTotalCostByCurrency()); ?></bdi></td>
                        <td><bdi><?php echo e($order->getPaidByCurrency()); ?></bdi></td>
                        <td><bdi><?php echo e(Auth::user()->name); ?></bdi></td>
                        <td><bdi><?php echo e(date('Y-m-d g:ia')); ?></bdi></td>
                    </tr>

                </tbody>
            </table>
        </div>

    </div>


    <script>
        print();
    </script>

</body>

</html>
<?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/CP/purchase_orders/print.blade.php ENDPATH**/ ?>