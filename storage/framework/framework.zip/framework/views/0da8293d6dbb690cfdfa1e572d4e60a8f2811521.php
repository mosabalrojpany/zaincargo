<?php $__env->startSection('content'); ?>


    <!--    Start header    -->
    <h4 class="font-weight-bold">عناوين الشحن</h4>
    <!--    End header    -->



    <div class="row mt-4" id="shipping-addresses">

        <!-- Start print addresses -->
        <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-lg-6 mb-3" id="<?php echo e($address->id); ?>">

                <div class="card border-0 border-state-active shadow">

                    
                    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center" role="tab" id="heading<?php echo e($address->id); ?>">
                        <h5 class="mb-0">
                            <span class="address-type-icon">
                                <img src="<?php echo e($address->getTypeIcon()); ?>" style="height: 40px" class="ml-1">
                            </span>
                            <img src="<?php echo e($address->country->getAvatarLogo()); ?>" class="ml-1">
                            <bdi><?php echo e($address->country->name); ?></bdi> / <bdi><?php echo e($address->city->name); ?></bdi>
                        </h5>
                        <a data-toggle="collapse" class="text-dark" href="#collapse<?php echo e($address->id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($address->id); ?>">
                            <i class="fa fa-chevron-down"></i>
                        </a>
                    </div>
                    

                    
                    <div id="collapse<?php echo e($address->id); ?>" class="collapsing" role="tabpanel" aria-labelledby="heading<?php echo e($address->id); ?>">

                        <div class="card-body text-right">

                            
                            <div class="pb-3">
                                <ul class="nav nav-fill nav-tabs pr-0" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="addressInfo<?php echo e($address->id); ?>-tab" data-toggle="tab" href="#addressInfo<?php echo e($address->id); ?>" role="tab" aria-controls="addressInfo<?php echo e($address->id); ?>" aria-selected="true">العنوان</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="prices<?php echo e($address->id); ?>-tab" data-toggle="tab" href="#prices<?php echo e($address->id); ?>" role="tab" aria-controls="prices<?php echo e($address->id); ?>" aria-selected="false">الأسعار</a>
                                    </li>
                                </ul>
                            </div>
                            


                            <div class="tab-content">

                                
                                <div class="tab-pane fade show active" id="addressInfo<?php echo e($address->id); ?>" role="tabpanel" aria-labelledby="addressInfo<?php echo e($address->id); ?>-tab">
                                    <table class="table text-left">
                                        <tbody>
                                            <tr>
                                                <td><bdi><?php echo e($address->country->name); ?></bdi></td>
                                                <td class="font-weight-bold no-wrap">Country</td>
                                            </tr>
                                            <tr>
                                                <td><bdi><?php echo e($address->city->name); ?></bdi></td>
                                                <td class="font-weight-bold no-wrap">City</td>
                                            </tr>
                                            <tr>
                                                <td><bdi><?php echo e($address->fullname); ?> / ELL<?php echo e(substr(authClient()->user()->code, 1)); ?></bdi></td>
                                                <td class="font-weight-bold no-wrap">FullName</td>
                                            </tr>
                                            <?php if($address->address1): ?>
                                                <tr>
                                                    <td><bdi><?php echo e($address->address1); ?></bdi></td>
                                                    <td class="font-weight-bold no-wrap">Address Line 1</td>
                                                </tr>
                                            <?php endif; ?>
                                            <?php if($address->address2): ?>
                                                <tr>
                                                    <td><bdi><?php echo e($address->address2); ?></bdi></td>
                                                    <td class="font-weight-bold no-wrap">Address Line 2</td>
                                                </tr>
                                            <?php endif; ?>
                                            <?php if($address->state): ?>
                                                <tr>
                                                    <td><?php echo e($address->state); ?></td>
                                                    <td class="font-weight-bold no-wrap">State/Region</td>
                                                </tr>
                                            <?php endif; ?>
                                            <?php if($address->zip): ?>
                                                <tr>
                                                    <td><bdi><?php echo e($address->zip); ?></bdi></td>
                                                    <td class="font-weight-bold no-wrap">PostCode/Zip</td>
                                                </tr>
                                            <?php endif; ?>
                                            <?php if($address->phone): ?>
                                                <tr>
                                                    <td><bdi><?php echo e($address->phone); ?></bdi></td>
                                                    <td class="font-weight-bold no-wrap">Phone 1</td>
                                                </tr>
                                            <?php endif; ?>
                                            <?php if($address->phone2): ?>
                                                <tr>
                                                    <td><bdi><?php echo e($address->phone2); ?></bdi></td>
                                                    <td class="font-weight-bold no-wrap">Phone 2</td>
                                                </tr>
                                            <?php endif; ?>
                                            <?php if($address->phone3): ?>
                                                <tr>
                                                    <td><bdi><?php echo e($address->phone3); ?></bdi></td>
                                                    <td class="font-weight-bold no-wrap">Phone 3</td>
                                                </tr>
                                            <?php endif; ?>
                                            <?php if($address->note): ?>
                                                <tr>
                                                    <td><bdi><?php echo e($address->note); ?></bdi></td>
                                                    <td class="font-weight-bold no-wrap"><bdi>Note(ملاحظة)</bdi></td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                

                                
                                <div class="tab-pane fade" id="prices<?php echo e($address->id); ?>" role="tabpanel" aria-labelledby="prices<?php echo e($address->id); ?>-tab">
                                    <table class="table table-bordered text-center">
                                        <tbody>
                                            <?php $__currentLoopData = $address->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($price->description); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                

                            </div>

                        </div>

                    </div>
                    


                </div>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- End print addresses -->

    </div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra-js'); ?>

    <script>

        if(window.location.hash){
            $('#shipping-addresses ' + window.location.hash + ' a[data-toggle="collapse"]').click();
        }

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Client.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/eletroli/projects/shipping_company/resources/views/Client/addresses.blade.php ENDPATH**/ ?>