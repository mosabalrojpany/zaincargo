<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class CountriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /*  DB::table('countries')->insert([
        [
        'name' => 'أمريكا',
        'active' => true,
        ],
        [
        'name' => 'بريطانيا',
        'active' => true,
        ],
        [
        'name' => 'الصين',
        'active' => true,
        ],
        ]); */
        /* factory(App\Models\Country::class, 5)->create(); */
    }
}
