<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class CustomersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /* for ($i = 0; $i < 30; ++$i) {
    factory(App\Models\Customer::class)->create();
    } */
    }
}
