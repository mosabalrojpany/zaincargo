<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class AddressesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /* factory(App\Models\Address::class, 5)->create();
    factory(App\Models\AddressPrice::class, 25)->create(); */
    }
}
