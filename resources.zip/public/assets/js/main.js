(function ($) {
    "use strict";
    jQuery(document).ready(function ($) {
        // wow animation initialization
        new WOW().init();

        // slicknav activate for home 1
        activateSlickNav('#mainMenu', '#mobileMenu');

        // slicknav activate for home 2
        activateSlickNav('#mainMenuHome2', '#mobileMenuHome2');

        // slicknav activate for home 3
        activateSlickNav('#mainMenuHome3', '#mobileMenuHome3');

        // slicknav activate function
        function activateSlickNav(selector, mobileMenu) {
            $(selector).slicknav({
                prependTo: mobileMenu
            });
        }

        // search popup show
        $("li.search-icon a").on('click', function (e) {
            e.preventDefault();
            $(".search-popup").addClass('popup');
        });

        // search popup remove
        $("#searchCloseBtn, .search-popup-overlay").on('click', function () {
            $(".search-popup").removeClass('popup');
        });

        // language dropdown toggle on clicking button
        $('.language a.dropdown-btn').on('click', function (event) {
            event.preventDefault();
            $(this).next('.language-dropdown').toggleClass('open');
        });

        // hero carousel
        $('.hero-carousel').owlCarousel({
            items: 1,
            loop: true,
            autoplay: true,
            autoplayTimeout: 6000,
            autoplaySpeed: 2000,
            dots: true,
            nav: false,
            mouseDrag: true,
            smartSpeed: 2000,
            animateOut: 'fadeOut'
        });

        // service carousel
        $('.service-carousel').owlCarousel({
            items: 3,
            loop: true,
            autoplay: true,
            autoplayTimeout: 4000,
            autoplaySpeed: 1000,
            dots: false,
            nav: true,
            navText: ["<i class='flaticon-left-arrow'></i>", "<i class='flaticon-right-arrow'></i>"],
            margin: 30,
            mouseDrag: true,
            smartSpeed: 1000,
            responsive: {
                // breakpoint from 0 up
                0: {
                    items: 1,
                    nav: false
                },
                576: {
                    items: 1,
                    nav: true
                },
                // breakpoint from 480 up
                768: {
                    items: 2
                },
                // breakpoint from 768 up
                992: {
                    items: 3
                }
            }
        });

        // testimonial carousel
        $('.testimonial-carousel').owlCarousel({
            items: 1,
            loop: true,
            autoplay: true,
            autoplayTimeout: 4000,
            autoplaySpeed: 1000,
            dots: false,
            nav: false,
            mouseDrag: true,
            smartSpeed: 1000
        });

        // Partner carousel
        $('.partner-carousel').owlCarousel({
            loop: true,
            autoplay: true,
            autoplayTimeout: 3000,
            autoplaySpeed: 500,
            autoplayHoverPause: true,
            dots: false,
            margin: 30,
            responsive: {
                0: {
                    items: 2
                },
                576: {
                    items: 3
                },
                992: {
                    items: 5
                },
            }
        });


        // Home 3 testimonial carousel
        $('.testimonial-carousel-3').owlCarousel({
            items: 2,
            loop: true,
            autoplay: true,
            autoplayTimeout: 4000,
            autoplaySpeed: 1000,
            dots: false,
            nav: false,
            mouseDrag: true,
            smartSpeed: 1000,
            margin: 30,
            responsive: {
                0: {
                    items: 1
                },
                768: {
                    items: 2
                }
            }
        });

        // background video initialization for home 7
        if ($("#bgndVideo7").length > 0) {
            $("#bgndVideo7").YTPlayer();
        }

        // background video initialization for home 8
        if ($("#bgndVideo8").length > 0) {
            $("#bgndVideo8").YTPlayer();
        }

        // background video initialization for home 9
        if ($("#bgndVideo9").length > 0) {
            $("#bgndVideo9").YTPlayer();
        }

        // ripple effect initialization for home 13
        if ($("#heroHome13").length > 0) {
            $('#heroHome13').ripples({
                resolution: 500,
                dropRadius: 20,
                perturbance: 0.04
            });
        }

        // ripple effect initialization for home 13
        if ($("#heroHome14").length > 0) {
            $('#heroHome14').ripples({
                resolution: 500,
                dropRadius: 20,
                perturbance: 0.04
            });
        }

        // ripple effect initialization for home 13
        if ($("#heroHome15").length > 0) {
            $('#heroHome15').ripples({
                resolution: 500,
                dropRadius: 20,
                perturbance: 0.04
            });
        }

        // Back to top
        $('.back-to-top').on('click', function () {
            $("html, body").animate({
                scrollTop: 0
            }, 1000);
        });

        // quickview product slider with thumbnail
        $('.quickview-slider').owlCarousel({
            autoplay: true,
            autoplayTimeout: 8000,
            smartSpeed: 1500,
            loop: true,
            autoplayHoverPause: true,
            items: 1,
            center: true,
            dots: false,
            thumbs: true,
            thumbImage: false,
            thumbsPrerendered: true,
            thumbContainerClass: 'owl-thumbs',
            thumbItemClass: 'owl-thumb-item',
        });

        // Product thumbnail sliders
        $('.product-thumb-slider').owlCarousel({
            loop: false,
            dots: false,
            nav: true,
            navText: ["<i class='fas fa-angle-left'></i>", "<i class='fas fa-angle-right'></i>"],
            autoplay: false,
            margin: 5,
            responsive: {
                0: {
                    items: 4
                }
            }
        });

        // product image zoom initialization function
        function initzoom() {
            if ($('.easyzoom').length > 0) {
                var $easyzoom = $('.easyzoom').easyZoom();
            }
        }


        // Product preview
        if ($('.product-details .product-preview').length > 0) {
            let activeSmallSrc = $('.product-details .product-thumb-slider .single-product').eq(0).find('img.small').attr('src');
            let activeBigSrc = $('.product-details .product-thumb-slider .single-product').eq(0).find('img.big').attr('src');
            $('.product-details .product-preview').find('a').attr('href', activeBigSrc);
            $('.product-details .product-preview').find('img').attr('src', activeSmallSrc);

            $('.product-details .product-thumb-slider img.small').on('click', function () {
                let currimg = `<div class="easyzoom easyzoom--overlay">
                                <a href="${$(this).siblings('img.big').attr('src')}">
                                    <img class="single-image" src="${$(this).attr('src')}" alt=""/>
                                </a>
                              </div>`;
                $('.product-details .product-preview').html(currimg);
                initzoom();
            });
        }

        // initialize product image zoom 
        initzoom();

        // Project details carousel
        $('.project-carousel').owlCarousel({
            loop: true,
            dots: false,
            nav: true,
            navText: ["<i class='fas fa-angle-left'></i>", "<i class='fas fa-angle-right'></i>"],
            autoplay: false,
            items: 1
        });

        // show shipping address form if not same as billing address
        if ($('input#sameStatus').length > 0) {
            $('input#sameStatus').on('change', function () {
                if ($('input#sameStatus').prop('checked') == false) {
                    $("#shippingAddress").addClass('d-block');
                } else {
                    $("#shippingAddress").removeClass('d-block');
                }
            });
        }

    });


    $(window).on('scroll', function () {
        // sticky menu activation
        if ($(window).scrollTop() > 180) {
            $('.header-area').addClass('sticky-navbar');
        } else {
            $('.header-area').removeClass('sticky-navbar');
        }
        // back to top button fade in / fade out
        if ($(window).scrollTop() > 1000) {
            $('.back-to-top').addClass('show');
        } else {
            $('.back-to-top').removeClass('show');
        }
    });


    jQuery(window).on('load', function () {
        // preloader fadeout onload
        $(".loader-container").addClass('loader-fadeout');

        // isotope initialize
        $('.grid').isotope({
            // set itemSelector so .grid-sizer is not used in layout
            itemSelector: '.single-pic',
            percentPosition: true,
            masonry: {
                // set to the element
                columnWidth: '.grid-sizer'
            }
        })
    });



    /*
     * Start submit form to server (ajax)
     * send request to server and refresh page after 2seconds(default) if there is no errors
     * @parms .formSendAjaxRequest - class for tag form which will use ajax 
     * @requrments  .formSendAjaxRequest for form tag ( <form calss='formSendAjaxRequest' />)
     *              .formResult inside form tag to show result 
     */
    $('.formSendAjaxRequest').submit(function (event) {

        event.preventDefault(); /* cancel send form */

        /* to use it inside methods (.ajax ..etc)   */
        var form = $(this);

        /*  Disable button submit to stop send many requests in the same time */
        var btnSend = $(this).find(':submit');
        btnSend.attr('disabled', 'disabled');

        var formResult = $(this).find('.formResult');

        var loaderPercent = $(this).attr('loader-percent');
        if (loaderPercent) {
            formResult.html('<div class="loader"><span class="loader-value"></span><label class="loader-shape mb-3"></label></div>');
        } else {
            formResult.html('<div class="loader"><label class="loader-shape mb-3"></label></div>');
        }
        var refresh = $(this).attr('refresh-seconds'); /* refresh page after seconds */

        var msgError = $(this).attr('msgError'); /* this message for errors (to show it if fail request) */

        var msgSuccess = $(this).attr('msgSuccess'); /* this message for success (to show it if done without errors) */

        var msgClasses = $(this).attr('msgClasses'); /*  Extra classes to add to box messages    */
        if (msgClasses == null) {
            msgClasses = 'mb-2';
        }

        var redirectTo = $(this).attr('redirect-to'); /* redirect to page */
        if (redirectTo == null || redirectTo == undefined) {
            //redirectTo = window.location.href;
            redirectTo = location.protocol + '//' + location.host + location.pathname;
        }

        if ($(this).attr('focus-on')) {
            $("html ,body").animate({
                scrollTop: $($(this).attr('focus-on')).offset().top
            }, 'slow');
        }

        var hideOnSuccess = false;
        if ($(this).attr('hideOnSuccess')) {
            hideOnSuccess = true;
        }

        var ajax_info = {
            url: $(this).attr('action'),
            method: $(this).attr('method'),
            xhr: function () {

                function showProgress(e) {
                    if (e.lengthComputable) {
                        var precent = Math.round(100 * e.loaded / e.total) + '%';
                        console.log(precent);
                        //$('.progress .progress-bar').css('width', precent).html(precent);
                        $('.loader .loader-value').html(precent);
                    }
                }
                var xhr = new window.XMLHttpRequest();
                //Upload progress
                xhr.upload.addEventListener("progress", showProgress, false);
                //Download progress
                xhr.addEventListener("progress", showProgress, false);
                return xhr;
            }
        };

        if (!$(this).attr('upload-files')) {
            ajax_info['data'] = $(this).serialize();
        } else {
            ajax_info['data'] = new FormData(this);
            ajax_info['contentType'] = false;
            ajax_info['cache'] = false;
            ajax_info['processData'] = false;
        }

        /* Start send post request to server */
        $.ajax(ajax_info)
            .done(function (result) { /* Form seneded success without any error */

                var msg = '<div class="alert alert-success alert-dismissible text-right fade show ' + msgClasses + '" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><ul class="mb-0">';


                if (msgSuccess != null && msgSuccess != undefined) {
                    msg += msgSuccess;
                } else if (result.msg != null && result.msg != undefined) { /*  msg from server    */
                    msg += '<ul>';
                    $.each(result.msg, function (key, value) {
                        msg += '<li>' + value + '</li>';
                    });
                    msg += '</ul>';
                } else {
                    msg += 'تمت العملية بنجاح';
                }

                msg += '</div>';
                formResult.html(msg);

                /*  Hide butSend if request success     */
                if ($(form).attr('btnSuccess') == 'hide') {
                    btnSend.addClass('d-none');
                }

                /*  Redirect from server    */
                if (result.redirectTo != null && result.redirectTo != undefined) {
                    redirectTo = result.redirectTo;
                }

                if (refresh != null && refresh != 'false') {
                    setTimeout(function () {
                        location.href = redirectTo;
                    }, 1000 * refresh);
                }
                if (hideOnSuccess) {
                    form.html(msg);
                }
            })
            .fail(function (result) { /* There is error in send form or in server-side */
                try {
                    var errorString = '<div class="alert alert-danger alert-dismissible text-right fade show ' + msgClasses + '" role="alert"><ul class="mb-0">';
                    var response = JSON.parse(result.responseText);
                    if (msgError != null && msgError != undefined) {
                        errorString += '<li>' + msgError + '</li>';
                    } else if (response.errors) {
                        $.each(response.errors, function (key, value) {
                            //errorString += '<li>' + value + '</li>';
                            $.each(value, function (k, v) {
                                errorString += '<li>' + v + '</li>';
                            });
                        });
                    }
                    else {
                        errorString += '<li>حدث خطأ</li>';
                        console.error(response.message);
                    }
                } catch (e) {
                    errorString += '<li>حدث خطأ يرجى التأكد من اتصالك بالإنترنت وإعادة المحاولة</li>';
                } finally {
                    errorString += '</ul><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
                    formResult.html(errorString);
                }
            })
            .always(function () {
                btnSend.removeAttr('disabled');
            });
        /* End send post request to server */


    });
    /*  End Form add (ajax)   */



}(jQuery));